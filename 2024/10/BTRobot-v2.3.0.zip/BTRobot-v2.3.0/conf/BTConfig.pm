#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2011-2024 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 13/09/16 | [gResult] Add Column ID to Listener Status             ##
##         | 19/09/16 | [gResult] Add Class for each Item                      ##
##         | 19/09/16 | [gResult] Add SQL Statement for each DB Class          ##
##         | 19/09/16 | [gENV] Add Var [EXTINST_TYPE...SQL_LIST]               ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 28/09/16 | [gALTCapture] Add Alert Keywords Capture               ##
##         | 29/09/16 | [gENV] Add Some Variable for Self-Monitor              ##
##         | 19/10/16 | [gResult] Top Event use lag instead of lead            ##
##         | 20/10/16 | [gResult] Limit Filters in SQL Plan to 3000 Chars      ##
##         | 27/10/16 | [gResult] Add Collection for dict/fixed Stats          ##
##         | 27/10/16 | [gResult] Add Collection for ASM Disks                 ##
##         | 27/10/16 | [gALTCapture] Add Keyword [warn] in Alert Collection   ##
##         | 31/10/16 | [gResult] Add KERNEL_VERSION to RD_OS_INFO             ##
##         | 31/10/16 | [gResult] Add LP_SIZE/LP_COUNT to RD_OS_MEMSTAT        ##
##         | 10/11/16 | [gResult] Remove <br> in RD_DB_TOPSEGS                 ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 17/11/16 | [gFName] Add Monitor Log for Self-Monitor              ##
##         | 18/11/16 | [gResult] Add BitCoin Attact Objects Collection        ##
## 1.1.1   | 21/11/16 | Version [1.1.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 23/11/16 | [gResult] Limit Filters in SQL Plan to 1000 Chars      ##
##         | 24/11/16 | [gResult] Add New SQL in PSU Collection for 12c        ##
## 1.1.2   | 01/12/16 | Version [1.1.2] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 06/12/16 | [gResult] Add Column Name for PSU Collection in 12c    ##
##         | 14/12/16 | [gResult] Add JOB/SCHEDULER Collections                ##
## 1.1.3   | 20/12/16 | Version [1.1.3] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 03/01/17 | [gResult] Limit Filters in SQL Plan to 2000 Chars      ##
##         | 12/01/17 | [gResult] Add Class DG for RD_DB_LOG                   ##
## 1.1.4   | 12/01/17 | Version [1.1.4] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 10/02/17 | [gFName] Add SERVER_CONFIG                             ##
##         | 14/02/17 | [gENV] Add QUIET_MODE Params [Default 0]               ##
##         | 16/02/17 | [gFName] Add MODULE_DIR                                ##
##         | 20/02/17 | [gENV] Add UPLOAD_USER Params [Default '']             ##
##         | 20/02/17 | [gFName] Add UPLOAD_CONFIG                             ##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 20/02/17 | [gResult] Modify Filter Length of SQLPLAN by substrb   ##
## 2.1.0   | 29/03/17 | Version [2.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 14/04/17 | [gResult] Remove Time Model Filter, Collect All        ##
##         | 14/04/17 | [gResult] RD_DB_JOB Add SUBSTRB to limit column length ##
##         | 14/04/17 | [gResult] Add RD_DB_SEGSUMM_SIZE                       ##
##         | 14/04/17 | [gResult] Add RD_DB_LINKS                              ##
##         | 28/04/17 | [gResult] RD_DB_SEGSUMM_SIZE ignore RECYCLEBIN Object  ##
##         | 04/05/17 | [gResult] Add RD_DB_AWR_SEGSTATS/SEGOBJ                ##
##         | 04/05/17 | [gENV] Add TOP_SEGSTATS/SEGOBJ_LIST                    ##
## 2.2.0   | 05/05/17 | Version [2.2.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 10/05/17 | [gResult] RD_DB_JOB set limit to 2000 chars            ##
##         | 11/05/17 | [gResult] Tuning SQL for RD_DB_SEGSUMM_SIZE            ##
##         | 12/05/17 | [gResult] Use Left join and one SQL List in SQLPLAN    ##
## 2.2.1   | 12/05/17 | Version [2.2.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 07/07/17 | [gResult] limit of SQL Plan filter to 1000 in bytes    ##
##         | 22/11/17 | [gResult] RD_DB_JOB set limit to 1000 bytes            ##
## 2.2.3   | 29/11/17 | Version [2.2.3] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 31/07/18 | [gResult] add item [RD_DB_TRIGGER]                     ##
## 2.2.4   | 31/07/18 | Version [2.2.4] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 03/12/18 | Limit OTHER column in SQL Plan to 1000 chars           ##
## 2.2.5   | 03/12/18 | Version [2.2.5] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 19/12/18 | [gResult] add item [RD_DB_SCN_COMPAT]                  ##
## 2.2.6   | 19/12/18 | Version Released                                       ##
##---------|----------|--------------------------------------------------------##
##         | 19/12/18 | [gENV] add item [MAX_RUN_TIME] for monitor             ## 
## 2.2.7   | 19/03/19 | Version Released                                       ##
##---------|----------|--------------------------------------------------------##
##         | 24/09/29 | PDB support                                            ##
##         | 24/09/29 | [gResult] add item [RD_DB_CONTAINER]                   ##
##         | 24/09/29 | [gResult] add item [RD_DB_PROPS]                       ##
##         | 24/09/29 | [gResult] remove item [RD_DB_FREE]                     ##
## 2.3.0   | 24/09/29 | Version Released                                       ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package BTConfig;
require Exporter;

our @ISA = qw(Exporter);
our @EXPORT = qw(%gENV %gFName %gOSCollect %gResult %gStatus %gALTCapture);

################################################################################
##                                                                            ##
## Global Parameters                                                          ##
##                                                                            ##
################################################################################
our %gENV = ( 'SCRIPT_VERSION'      => '2.3.0'                # Version
            , 'DB_NAME'             => ''                     # Var: DB Name
            , 'UNIQUE_NAME'         => ''                     # Var: DB Unique Name
            , 'DB_ROLE'             => ''                     # Var: DB Role
            , 'CLT_TIME'            => ''                     # Var: Package Collection Time
            , 'DB_VERSION'          => ''                     # Var: DB Version
            , 'INST_COUNT'          => 0                      # Var: Instance Count
            , 'REMOTE_LOGIN'        => 'EQUAL'                # Var: Remote Login Method
            , 'LISTEN_NODE'         => 'NONE'                 # Var: Package Lieten Node
            , 'DBID'                => '0'                    # Var: DBID
            , 'OS_TYPE'             => 'linux'                # Var: OS Type
            , 'OS_USER'             => 'oracle'               # Var: OS Login User
            , 'HOSTNAME'            => 'HOSTNAME'             # Var: OS Name
            , 'HOSTIP'              => '127.0.0.1'            # Var: Current Node IP
            , 'ORACLE_SID'          => 'NONE'                 # Var: Oracle SID
            , 'ORACLE_HOME'         => 'NONE'                 # Var: Oracle Home
            , 'ASM_SID'             => 'NONE'                 # Var: ASM SID
            , 'ASM_HOME'            => 'NONE'                 # Var: ASM Home
            , 'ASM_DIAG'            => 'NONE'                 # Var: ASM Diag Dest
            , 'MIN_SNAP'            => 0                      # Var: Min Snapshot in AWR
            , 'DB_CHARSET'          => 'NONE'                 # Var: DB Character
            , 'OS_CHARSET'          => 'NONE'                 # Var: OS Character
            , 'ALT_CHARSET'         => 'NONE'                 # Var: Alert Character
            , 'LSN_CHARSET'         => 'NONE'                 # Var: Listener Character
            , 'TARGET_CHARSET'      => 'UTF8'                 # Var: Target File Character
            , 'TRACE_LIMIT'         => 51200                  # Var: Trace Size Limit (Begin and End Size of Trace)
            , 'SKIP_STEP'           => 0                      # Var: Skip Some Waiting Step
            , 'SQL_BATCH_SIZE'      => 100                    # Var: Batch Size to Collect SQL-Releated Data
            , 'PRINT_PROCESS'       => 1                      # Var: Print All Process in [getProc]
            , 'INSTANCE_LIST'       => ''                     # Var: Instance List for Ext-Instance Collection
            , 'PATH'                => ''                     # Var: OS Path Variable
            , 'EXTINST_TYPE'        => 'DG'                   # Var: Extra-Instance Type [DG/OTHER]
            , 'INST_TYPE'           => 'DB'                   # Var: Instance Type [DB/ASM]
            , 'OBJ_SCHEMA'          => ''                     # Var: Object Schema for Variable Replace in SQL Relation Data Collection
            , 'SQL_LIST'            => ''                     # Var: List for Variable Replace in SQL Relation Data Collection
            , 'MONITOR_PID'         => 1                      # Var: Self-Monitor Process ID
            , 'SM_INTERVAL'         => 5                      # Var: Self-Monitor Interval in Seconds, 0 means off
            , 'CPU_MIN_IDLE'        => 10                     # Var: Self-Monitor Min CPU Idle Percentage
            , 'DIR_MIN_SIZE'        => 100                    # Var: Self-Monitor Min Result Directory Free Size
            , 'MAX_RUN_TIME'        => 21600                  # Var: Self-Monitor Max Running Time (in seconds) for the script
            , 'GLOBAL_ERROR'        => ''                     # Var: Global Error Message
            , 'LSNR_WARNINGS'       => 0                      # Var: Global Error Message
            , 'TOP_SEGSTATS'        => 5                      # Var: AWR Top Segment Stats in AWR
            , 'SEGOBJ_LIST'         => ''                     # Var: AWR Segment Stats Obj List
            , 'DB_USER'             => 'sys'                  # Param: DB Login - User
            , 'DB_PSWD'             => 'oracle'               # Param: DB Login - Password
            , 'DB_SERV'             => ''                     # Param: DB Login - Connect String
            , 'ASM_USER'            => 'sys'                  # Param: ASM Login - User
            , 'ASM_PSWD'            => 'oracle'               # Param: ASM Login - Password
            , 'ASM_SERV'            => ''                     # Param: ASM Login - Connect String
            , 'RESULT_ZIP'          => 1                      # Param: Use Zip File
            , 'OSERR_TIME'          => 30                     # Param: OS Error Log Limit by Day
            , 'ALERT_TIME'          => 30                     # Param: Alert Log Limit by Day
            , 'ALERT_KEEP'          => 50                     # Param: Alert Keep Lines
            , 'LSNR_TIME'           => 30                     # Param: Listener Log Limit by Day
            , 'AWR_TIME'            => 8                      # Param: AWR Limit by Day
          # , 'GAP_IGNORE'          => 3                      # Param: AWR Gap Ignore
            , 'TOP_WAITS'           => 10                     # Param: AWR Top Event Limits
            , 'TOP_SEGMENTS'        => 10                     # Param: AWR Top Segment Limits
            , 'TOP_SQL'             => 32                     # Param: AWR Top SQL Limits
            , 'TOP_AWR'             => 3                      # Param: AWR Top AWR Report
            , 'LOG_LIMIT'           => 30                     # Param: Log History Limit by Day
            , 'LISTEN_PORT'         => 12345                  # Param: Script Listen Port
            , 'COLLECT_DG'          => 1                      # Param: Collect DG Data
            , 'QUIET_MODE'          => 0                      # Param: Quiet Mode
          # , 'UPLOAD_USER'         => ''                     # Param: User Mobile used by Auto Upload
            , 'BUSY_SECTIONS'       => '0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23' # Param: Busy Sections to Collect AWR Report
            , 'ALT_IGNORE'          => 'ORA-12535,TNS-12535,TNS-00505,ORA-12541,TNS-12541,TNS-00511'   # Var: Error Types ignored in Alert Collection
            # oerr tns 12541:  12541, 00000, "TNS:no listener"
            # oerr tns 00511:  00511, 00000, "No listener"
            # oerr tns 00505:  00505, 00000, "Operation timed out"
            # oerr tns 12535:  12535, 00000, "TNS:operation timed out"
            , 'SYSSTAT_FILTER'      => "'redo size','db block gets','physical writes','physical write bytes','physical reads','physical read bytes','parse count (total)','parse count (hard)','consistent gets','db block changes','execute count','user calls','user commits','user rollbacks','sorts (disk)','sorts (memory)','logons cumulative','gc cr blocks served','gc cr blocks received','gc current blocks served','gc current blocks received','gc kbytes sent','gc kbytes saved'"
            # , 'TMOD_FILTER'         => "'hard parse elapsed time','DB time','DB CPU','parse time elapsed','PL/SQL execution elapsed time','sql execute elapsed time'"
            , 'EVENT_FILTER'        => "'log file sync','log file parallel write','db file sequential read','db file scattered read'"
            );


################################################################################
##                                                                            ##
## Global Files                                                               ##
##                                                                            ##
################################################################################
our %gFName = ( 'DATA_DIR'            => 'data'
              , 'CONFIG_DIR'          => 'conf'
              , 'LIB_DIR'             => 'lib'
              , 'RESULT_DIR'          => 'data'
              , 'MODULE_DIR'          => 'module'
              , 'DG_SCRIPT'           => 'DGRobot.pl'
              , 'NODE_SCRIPT'         => 'NodeRobot.pl'
              , 'MAIN_SCRIPT'         => 'BTRobot.pl'
              , 'DISPATCHER_SCRIPT'   => 'Dispatcher.pl'
              , 'LIB_TOOLS'           => 'BTTools.pm'
              , 'LIB_DBTOOL'          => 'DBTools.pm'
              , 'LIB_CONFIG'          => 'BTConfig.pm'
              , 'SERVER_CONFIG'       => 'DBServers.conf'
            # , 'UPLOAD_CONFIG'       => 'uploadConfig.conf'
              , 'NOHUP_LOG'           => 'BTRobot_Nohup.log'
              , 'MONITOR_LOG'         => 'BTRobot_Monitor.log'
              , 'LOGFILE'             => 'BTRobot.log'
              , 'WARN_LOGFILE'        => 'BTRobot_warn.log'
              , 'DBI_TRACE_FILE'      => 'BTRobot_DBI.trc'
              );


################################################################################
##                                                                            ##
## OS Collection Module                                                       ##
##                                                                            ##
################################################################################
our %gOSCollect = ( 'osBasic'      => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osAlert'      => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osCrontab'    => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osListener'   => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osError'      => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osInstance'   => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osFS'         => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osHosts'      => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osMemory'     => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osNIC'        => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osOPatch'     => 'ENABLE'  # Switcher: Enable/Disable
                  , 'osParameter'  => 'ENABLE'  # Switcher: Enable/Disable
                  );


################################################################################
##                                                                            ##
## Result Files                                                               ##
##                                                                            ##
################################################################################
our %gResult = ( 'BX_MD_DB_SYSTEM'     => { 'FILE'   =>  'nirvana_md_database.txt'
                                          , 'CLASS'  =>  'CT'
                                          , 'SQL'    => q{SELECT DBID, NAME DBNAME, PLATFORM_NAME PLATFORM FROM V$DATABASE}
                                          }
               , 'BX_BATCH_CONTROL'    => { 'FILE'   =>  'nirvana_batch_control.txt'
                                          , 'CLASS'  =>  'CT'
                                          , 'DEFINE' =>  'HOST_NAME,TYPE,NAME,VALUE'
                                          }
               , 'BX_BATCH_STATUS'     => { 'FILE'   =>  'nirvana_batch_status.txt'
                                          , 'CLASS'  =>  'CT'
                                          , 'DEFINE' =>  'NAME,LINES,MSG'
                                          }
               , 'RD_OS_INFO'          => { 'FILE'   =>  'nirvana_os_info.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,NAME,OS_TYPE,CPU,CPU_MOD,MEMORY_MB,SWAP_MB,UP_TIME,OS_VERSION,KERNEL_VERSION,CLOCK_SOURCE'
                                          }
               , 'RD_OS_PAR'           => { 'FILE'   =>  'nirvana_os_par.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,NAME,VALUE'
                                          }
               , 'RD_OS_ERR'           => { 'FILE'   =>  'nirvana_os_err.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,ID,TIME,IDENTIFIER,TYPE,CLASS,RESOURCE_NAME,CONTENT,ERR_COUNT'
                                          }
               , 'RD_OS_FS'            => { 'FILE'   =>  'nirvana_os_FS.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,FS_NAME,TOTAL_MB,USED_MB,FREE_MB,USED_PCT,IUSED_PCT,MOUNT'
                                          }
               , 'RD_OS_FILESIZE'      => { 'FILE'   =>  'nirvana_os_fileSize.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,TYPE,FILE_NAME,FILE_SIZE'
                                          }
               , 'RD_OS_MEMSTAT'       => { 'FILE'   =>  'nirvana_os_memStat.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,MEMORY_ALL,MEMORY_USED,MEMORY_FREE,LP_SIZE,LP_COUNT,LP_ADVISE'
                                          }
               , 'RD_OS_CRONTAB'       => { 'FILE'   =>  'nirvana_os_crontab.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,TIME_MINUTE,TIME_HOUR,TIME_DAY,TIME_MONTH,TIME_WEEK,COMMAND'
                                          }
               , 'RD_OS_HOSTS'         => { 'FILE'   =>  'nirvana_os_hosts.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,LINE_ORDER,IP_ADDRESS,HOST_LIST'
                                          }
               , 'RD_OS_NIC'           => { 'FILE'   =>  'nirvana_os_NIC.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,NIC_NAME,RUNNING_INFO'
                                          }
               , 'RD_OS_RAW'           => { 'FILE'   =>  'nirvana_os_raw.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,TYPE,ID,DATA_RAW'
                                          }
               , 'RD_OS_ORANET'        => { 'FILE'   =>  'nirvana_os_oraNet.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,CATAGORY,LINE_ORDER,NAME,CONFIG'
                                          }
               , 'RD_OS_LSN_STATUS'    => { 'FILE'   =>  'nirvana_os_lsnStatus.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INST_ID,NAME,ID,STATUS'
                                          }
               , 'RD_DB_ALERT_TRACE'   => { 'FILE'   =>  'nirvana_db_alert_trace.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'LOG_TIME,INSTANCE_NAME,LOG_TYPE,FILE_TYPE,FILE_NAME'
                                          }
               , 'RD_DB_ALERT'         => { 'FILE'   =>  'nirvana_db_alert.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'INSTANCE_NAME,TIME,LOG_SEQUENCE,LOG_TYPE,LOG_MESSAGE,LOG_COUNT'
                                          }
               , 'RD_DB_LSNR'          => { 'FILE'   =>  'nirvana_db_lsnr.txt'
                                          , 'CLASS'  =>  'OS'
                                          , 'DEFINE' =>  'TIME,NAME,PROGRAM,HOST,HOSTIP,STATUS,CONNECT_COUNT'
                                          }
               , 'RD_DB_EXTINST'       => { 'FILE'   =>  'nirvana_db_extInst.txt'
                                          , 'CLASS'  =>  'OS,DG'
                                          , 'DEFINE' =>  'TYPE,DBID,NAME,DB_UNIQUE_NAME,CREATED,LOG_MODE,OPEN_MODE,REMOTE_ARCHIVE,DATABASE_ROLE,FLASHBACK_ON,INST_ID,INSTANCE_NAME,HOST_NAME,VERSION,STARTUP_TIME,STATUS,PARALLEL,INSTANCE_ROLE,MAX_SGA_SIZE,BUFFER_CACHE_SIZE,SHARED_POOL_SIZE,REDO_BUFFER_SIZE'
                                          , 'SQL'    => q{SELECT '?' TYPE,DBID,NAME,DB_UNIQUE_NAME,CREATED,LOG_MODE,OPEN_MODE,REMOTE_ARCHIVE,DATABASE_ROLE,FLASHBACK_ON,I.INST_ID,INSTANCE_NAME,HOST_NAME,VERSION,STARTUP_TIME,STATUS,PARALLEL,INSTANCE_ROLE,MAX_SGA_SIZE,BUFFER_CACHE_SIZE,SHARED_POOL_SIZE,REDO_BUFFER_SIZE FROM V$DATABASE D,GV$INSTANCE I,(SELECT INST_ID,MAX(DECODE(NAME,'Maximum SGA Size',BYTES,0)) MAX_SGA_SIZE,MAX(DECODE(NAME,'Buffer Cache Size',BYTES,0)) BUFFER_CACHE_SIZE,MAX(DECODE(NAME,'Shared Pool Size',BYTES,0)) SHARED_POOL_SIZE,MAX(DECODE(NAME,'Redo Buffers',BYTES,0)) REDO_BUFFER_SIZE FROM GV$SGAINFO GROUP BY INST_ID) M WHERE I.INST_ID = M.INST_ID}
                                          , 'VALUE'  =>  'EXTINST_TYPE'
                                          }
               , 'RD_DB_INFO'          => { 'FILE'   =>  'nirvana_db_info.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT DBID, NAME, CREATED, RESETLOGS_CHANGE#, RESETLOGS_TIME, PRIOR_RESETLOGS_CHANGE#, PRIOR_RESETLOGS_TIME, LOG_MODE, CHECKPOINT_CHANGE#, ARCHIVE_CHANGE#, CONTROLFILE_TYPE, CONTROLFILE_CREATED, CONTROLFILE_SEQUENCE#, CONTROLFILE_CHANGE#, CONTROLFILE_TIME, OPEN_RESETLOGS, VERSION_TIME, OPEN_MODE, PROTECTION_MODE, PROTECTION_LEVEL, REMOTE_ARCHIVE, ACTIVATION#, SWITCHOVER#, DATABASE_ROLE, ARCHIVELOG_CHANGE#, ARCHIVELOG_COMPRESSION, SWITCHOVER_STATUS, DATAGUARD_BROKER, GUARD_STATUS, SUPPLEMENTAL_LOG_DATA_MIN, SUPPLEMENTAL_LOG_DATA_PK, SUPPLEMENTAL_LOG_DATA_UI, FORCE_LOGGING, PLATFORM_ID, PLATFORM_NAME, RECOVERY_TARGET_INCARNATION#, LAST_OPEN_INCARNATION#, CURRENT_SCN, FLASHBACK_ON, SUPPLEMENTAL_LOG_DATA_FK, SUPPLEMENTAL_LOG_DATA_ALL, DB_UNIQUE_NAME, STANDBY_BECAME_PRIMARY_SCN, FS_FAILOVER_STATUS, FS_FAILOVER_CURRENT_TARGET, FS_FAILOVER_THRESHOLD, FS_FAILOVER_OBSERVER_PRESENT, FS_FAILOVER_OBSERVER_HOST, CDB, CON_ID, CON_DBID FROM V$DATABASE}
                                          , 'SQL_10' => q{SELECT DBID, NAME, CREATED, RESETLOGS_CHANGE#, RESETLOGS_TIME, PRIOR_RESETLOGS_CHANGE#, PRIOR_RESETLOGS_TIME, LOG_MODE, CHECKPOINT_CHANGE#, ARCHIVE_CHANGE#, CONTROLFILE_TYPE, CONTROLFILE_CREATED, CONTROLFILE_SEQUENCE#, CONTROLFILE_CHANGE#, CONTROLFILE_TIME, OPEN_RESETLOGS, VERSION_TIME, OPEN_MODE, PROTECTION_MODE, PROTECTION_LEVEL, REMOTE_ARCHIVE, ACTIVATION#, SWITCHOVER#, DATABASE_ROLE, ARCHIVELOG_CHANGE#, ARCHIVELOG_COMPRESSION, SWITCHOVER_STATUS, DATAGUARD_BROKER, GUARD_STATUS, SUPPLEMENTAL_LOG_DATA_MIN, SUPPLEMENTAL_LOG_DATA_PK, SUPPLEMENTAL_LOG_DATA_UI, FORCE_LOGGING, PLATFORM_ID, PLATFORM_NAME, RECOVERY_TARGET_INCARNATION#, LAST_OPEN_INCARNATION#, CURRENT_SCN, FLASHBACK_ON, SUPPLEMENTAL_LOG_DATA_FK, SUPPLEMENTAL_LOG_DATA_ALL, DB_UNIQUE_NAME, STANDBY_BECAME_PRIMARY_SCN, FS_FAILOVER_STATUS, FS_FAILOVER_CURRENT_TARGET, FS_FAILOVER_THRESHOLD, FS_FAILOVER_OBSERVER_PRESENT, FS_FAILOVER_OBSERVER_HOST, 0 CON_ID FROM V$DATABASE}
                                          , 'SQL_11' => q{SELECT DBID, NAME, CREATED, RESETLOGS_CHANGE#, RESETLOGS_TIME, PRIOR_RESETLOGS_CHANGE#, PRIOR_RESETLOGS_TIME, LOG_MODE, CHECKPOINT_CHANGE#, ARCHIVE_CHANGE#, CONTROLFILE_TYPE, CONTROLFILE_CREATED, CONTROLFILE_SEQUENCE#, CONTROLFILE_CHANGE#, CONTROLFILE_TIME, OPEN_RESETLOGS, VERSION_TIME, OPEN_MODE, PROTECTION_MODE, PROTECTION_LEVEL, REMOTE_ARCHIVE, ACTIVATION#, SWITCHOVER#, DATABASE_ROLE, ARCHIVELOG_CHANGE#, ARCHIVELOG_COMPRESSION, SWITCHOVER_STATUS, DATAGUARD_BROKER, GUARD_STATUS, SUPPLEMENTAL_LOG_DATA_MIN, SUPPLEMENTAL_LOG_DATA_PK, SUPPLEMENTAL_LOG_DATA_UI, FORCE_LOGGING, PLATFORM_ID, PLATFORM_NAME, RECOVERY_TARGET_INCARNATION#, LAST_OPEN_INCARNATION#, CURRENT_SCN, FLASHBACK_ON, SUPPLEMENTAL_LOG_DATA_FK, SUPPLEMENTAL_LOG_DATA_ALL, DB_UNIQUE_NAME, STANDBY_BECAME_PRIMARY_SCN, FS_FAILOVER_STATUS, FS_FAILOVER_CURRENT_TARGET, FS_FAILOVER_THRESHOLD, FS_FAILOVER_OBSERVER_PRESENT, FS_FAILOVER_OBSERVER_HOST, 0 CON_ID FROM V$DATABASE}
                                          }
               , 'RD_DB_INST'          => { 'FILE'   =>  'nirvana_db_inst.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT INST_ID, INSTANCE_NUMBER, INSTANCE_NAME, HOST_NAME, VERSION_FULL VERSION, STARTUP_TIME, STATUS, PARALLEL, THREAD#, ARCHIVER, LOG_SWITCH_WAIT, LOGINS, SHUTDOWN_PENDING, DATABASE_STATUS, INSTANCE_ROLE, ACTIVE_STATE, BLOCKED FROM GV$INSTANCE}
                                          , 'SQL_10' => q{SELECT INST_ID, INSTANCE_NUMBER, INSTANCE_NAME, HOST_NAME, VERSION, STARTUP_TIME, STATUS, PARALLEL, THREAD#, ARCHIVER, LOG_SWITCH_WAIT, LOGINS, SHUTDOWN_PENDING, DATABASE_STATUS, INSTANCE_ROLE, ACTIVE_STATE, BLOCKED FROM GV$INSTANCE}
                                          , 'SQL_11' => q{SELECT INST_ID, INSTANCE_NUMBER, INSTANCE_NAME, HOST_NAME, VERSION, STARTUP_TIME, STATUS, PARALLEL, THREAD#, ARCHIVER, LOG_SWITCH_WAIT, LOGINS, SHUTDOWN_PENDING, DATABASE_STATUS, INSTANCE_ROLE, ACTIVE_STATE, BLOCKED FROM GV$INSTANCE}
                                          , 'SQL_12' => q{SELECT INST_ID, INSTANCE_NUMBER, INSTANCE_NAME, HOST_NAME, VERSION, STARTUP_TIME, STATUS, PARALLEL, THREAD#, ARCHIVER, LOG_SWITCH_WAIT, LOGINS, SHUTDOWN_PENDING, DATABASE_STATUS, INSTANCE_ROLE, ACTIVE_STATE, BLOCKED FROM GV$INSTANCE}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_CONTAINER'     => { 'FILE'   =>  'nirvana_db_container.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT CON_ID,DBID,CON_UID,GUID,NAME,OPEN_MODE,RESTRICTED,CAST(OPEN_TIME AS DATE) OPEN_TIME,CREATE_SCN,TOTAL_SIZE,BLOCK_SIZE,RECOVERY_STATUS,SNAPSHOT_PARENT_CON_ID,LOCAL_UNDO,UNDO_SCN,UNDO_TIMESTAMP,CREATION_TIME,PDB_COUNT,AUDIT_FILES_SIZE,MAX_SIZE,MAX_AUDIT_SIZE FROM V$CONTAINERS}
                                          , 'SQL_10' => q{SELECT 0 CON_ID, D.DBID, 0 CON_UID, NULL GUID, D.NAME, D.OPEN_MODE, CASE WHEN I.ACTIVE_STATE = 'NORMAL' THEN 'NO' ELSE 'YES' END RESTRICTED, I.STARTUP_TIME OPEN_TIME, NULL CREATE_SCN, NULL TOTAL_SIZE, NULL BLOCK_SIZE, NULL RECOVERY_STATUS, NULL SNAPSHOT_PARENT_CON_ID, NULL LOCAL_UNDO, NULL UNDO_SCN, NULL UNDO_TIMESTAMP, NULL CREATION_TIME, NULL PDB_COUNT, NULL AUDIT_FILES_SIZE, NULL MAX_SIZE, NULL MAX_AUDIT_SIZE FROM V$DATABASE D, V$INSTANCE I}
                                          , 'SQL_11' => q{SELECT 0 CON_ID, D.DBID, 0 CON_UID, NULL GUID, D.NAME, D.OPEN_MODE, CASE WHEN I.ACTIVE_STATE = 'NORMAL' THEN 'NO' ELSE 'YES' END RESTRICTED, I.STARTUP_TIME OPEN_TIME, NULL CREATE_SCN, NULL TOTAL_SIZE, NULL BLOCK_SIZE, NULL RECOVERY_STATUS, NULL SNAPSHOT_PARENT_CON_ID, NULL LOCAL_UNDO, NULL UNDO_SCN, NULL UNDO_TIMESTAMP, NULL CREATION_TIME, NULL PDB_COUNT, NULL AUDIT_FILES_SIZE, NULL MAX_SIZE, NULL MAX_AUDIT_SIZE FROM V$DATABASE D, V$INSTANCE I}
                                          , 'SQL_12.1' => q{SELECT CON_ID,DBID,CON_UID,GUID,NAME,OPEN_MODE,RESTRICTED,CAST(OPEN_TIME AS DATE) OPEN_TIME,CREATE_SCN,TOTAL_SIZE,BLOCK_SIZE,RECOVERY_STATUS,SNAPSHOT_PARENT_CON_ID FROM V$CONTAINERS}
                                          }
               , 'RD_DB_REGHIST'       => { 'FILE'   =>  'nirvana_db_regHist.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT ACTION_TIME, ACTION, NAMESPACE, VERSION, ID, COMMENTS FROM DBA_REGISTRY_HISTORY}
                                          , 'SQL_12' => q{SELECT ACTION_TIME, ACTION, BUNDLE_SERIES NAMESPACE, VERSION, BUNDLE_ID ID, DESCRIPTION COMMENTS FROM DBA_REGISTRY_SQLPATCH}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_OBJ'           => { 'FILE'   =>  'nirvana_db_obj.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT OWNER, OBJECT_NAME, SUBOBJECT_NAME, OBJECT_ID, DATA_OBJECT_ID, OBJECT_TYPE, CREATED, LAST_DDL_TIME, TIMESTAMP, STATUS, TEMPORARY, GENERATED, SECONDARY FROM DBA_OBJECTS WHERE STATUS <> 'VALID' OR TRIM(OBJECT_NAME) IN ('DBMS_CORE_INTERNAL', 'DBMS_SYSTEM_INTERNAL', 'DBMS_SUPPORT_INTERNAL')}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_JOB'           => { 'FILE'   =>  'nirvana_db_job.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT JOB, LOG_USER, PRIV_USER, SCHEMA_USER, LAST_DATE, LAST_SEC, THIS_DATE, THIS_SEC, NEXT_DATE, NEXT_SEC, TOTAL_TIME, BROKEN, INTERVAL, FAILURES, SUBSTR(WHAT, 1, 1000) WHAT, NLS_ENV, MISC_ENV, INSTANCE FROM DBA_JOBS}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SCHEDULER'     => { 'FILE'   =>  'nirvana_db_scheduler.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL_10' => q{SELECT OWNER, JOB_NAME, JOB_SUBNAME, JOB_CREATOR, CLIENT_ID, GLOBAL_UID, PROGRAM_OWNER, PROGRAM_NAME, JOB_TYPE, JOB_ACTION, NUMBER_OF_ARGUMENTS, SCHEDULE_OWNER, SCHEDULE_NAME, SCHEDULE_TYPE, START_DATE, REPEAT_INTERVAL, EVENT_QUEUE_OWNER, EVENT_QUEUE_NAME, EVENT_QUEUE_AGENT, EVENT_CONDITION, EVENT_RULE, END_DATE, JOB_CLASS, ENABLED, AUTO_DROP, RESTARTABLE, STATE, JOB_PRIORITY, RUN_COUNT, MAX_RUNS, FAILURE_COUNT, MAX_FAILURES, RETRY_COUNT, LAST_START_DATE, TO_CHAR(LAST_RUN_DURATION) LAST_RUN_DURATION, NEXT_RUN_DATE, TO_CHAR(SCHEDULE_LIMIT) SCHEDULE_LIMIT, TO_CHAR(MAX_RUN_DURATION) MAX_RUN_DURATION, LOGGING_LEVEL, STOP_ON_WINDOW_CLOSE, INSTANCE_STICKINESS, RAISE_EVENTS, SYSTEM, JOB_WEIGHT, NLS_ENV, SOURCE, DESTINATION, COMMENTS, FLAGS FROM DBA_SCHEDULER_JOBS}
                                          , 'SQL_11' => q{SELECT OWNER, JOB_NAME, JOB_SUBNAME, JOB_STYLE, JOB_CREATOR, CLIENT_ID, GLOBAL_UID, PROGRAM_OWNER, PROGRAM_NAME, JOB_TYPE, JOB_ACTION, NUMBER_OF_ARGUMENTS, SCHEDULE_OWNER, SCHEDULE_NAME, SCHEDULE_TYPE, START_DATE, REPEAT_INTERVAL, EVENT_QUEUE_OWNER, EVENT_QUEUE_NAME, EVENT_QUEUE_AGENT, EVENT_CONDITION, EVENT_RULE, FILE_WATCHER_OWNER, FILE_WATCHER_NAME, END_DATE, JOB_CLASS, ENABLED, AUTO_DROP, RESTARTABLE, STATE, JOB_PRIORITY, RUN_COUNT, MAX_RUNS, FAILURE_COUNT, MAX_FAILURES, RETRY_COUNT, LAST_START_DATE, TO_CHAR(LAST_RUN_DURATION) LAST_RUN_DURATION, NEXT_RUN_DATE, TO_CHAR(SCHEDULE_LIMIT) SCHEDULE_LIMIT, TO_CHAR(MAX_RUN_DURATION) MAX_RUN_DURATION, LOGGING_LEVEL, STOP_ON_WINDOW_CLOSE, INSTANCE_STICKINESS, RAISE_EVENTS, SYSTEM, JOB_WEIGHT, NLS_ENV, SOURCE, NUMBER_OF_DESTINATIONS, DESTINATION_OWNER, DESTINATION, CREDENTIAL_OWNER, CREDENTIAL_NAME, INSTANCE_ID, DEFERRED_DROP, ALLOW_RUNS_IN_RESTRICTED_MODE, COMMENTS, FLAGS FROM DBA_SCHEDULER_JOBS}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SCN'           => { 'FILE'   =>  'nirvana_db_SCN.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SYSDATE COLLECT_TIME, CURRENT_SCN COLLECT_SCN, ROUND((CHK16KSCN - CURRENT_SCN)/24/3600/16/1024,1) HEADROOM FROM (SELECT CURRENT_SCN, ((((TO_NUMBER(TO_CHAR(SYSDATE,'YYYY'))-1988)*12*31*24*60*60) + ((TO_NUMBER(TO_CHAR(SYSDATE,'MM'))-1)*31*24*60*60) + (((TO_NUMBER(TO_CHAR(SYSDATE,'DD'))-1))*24*60*60) + (TO_NUMBER(TO_CHAR(SYSDATE,'HH24'))*60*60) + (TO_NUMBER(TO_CHAR(SYSDATE,'MI'))*60) + (TO_NUMBER(TO_CHAR(SYSDATE,'SS'))) ) * (16*1024)) CHK16KSCN FROM V$DATABASE)}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_ROLEPRIV'      => { 'FILE'   =>  'nirvana_db_rolePriv.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT GRANTEE, GRANTED_ROLE, ADMIN_OPTION, DEFAULT_ROLE FROM DBA_ROLE_PRIVS}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SYSPRIV'       => { 'FILE'   =>  'nirvana_db_sysPriv.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT GRANTEE, PRIVILEGE, ADMIN_OPTION FROM DBA_SYS_PRIVS}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SYSUSER'       => { 'FILE'   =>  'nirvana_db_sysUser.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT INST_ID, USERNAME, SYSDBA, SYSOPER FROM GV$PWFILE_USERS}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_LINKS'         => { 'FILE'   =>  'nirvana_db_links.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT OWNER, DB_LINK, USERNAME, HOST, CREATED FROM DBA_DB_LINKS}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_USER'          => { 'FILE'   =>  'nirvana_db_user.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT U.USERNAME, U.USER_ID, U.PASSWORD, U.ACCOUNT_STATUS, U.LOCK_DATE, U.EXPIRY_DATE, U.DEFAULT_TABLESPACE, U.TEMPORARY_TABLESPACE, U.CREATED, U.PROFILE, U.INITIAL_RSRC_CONSUMER_GROUP, U.EXTERNAL_NAME, X.PTIME FROM DBA_USERS U, SYS.USER$ X WHERE U.USER_ID = X.USER#}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_ROLE'          => { 'FILE'   =>  'nirvana_db_role.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT ROLE, PASSWORD_REQUIRED FROM DBA_ROLES}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_PROFILE'       => { 'FILE'   =>  'nirvana_db_profile.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT PROFILE, RESOURCE_NAME, RESOURCE_TYPE, LIMIT FROM DBA_PROFILES}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_REGISTRY'      => { 'FILE'   =>  'nirvana_db_registry.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT COMP_ID, COMP_NAME, VERSION, STATUS, MODIFIED, NAMESPACE, CONTROL, SCHEMA, PROCEDURE, STARTUP, PARENT_ID FROM DBA_REGISTRY}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_TS'            => { 'FILE'   =>  'nirvana_db_ts.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT CON_ID, TABLESPACE_NAME, BLOCK_SIZE, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, MIN_EXTLEN, STATUS, CONTENTS, LOGGING, FORCE_LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE, PLUGGED_IN, SEGMENT_SPACE_MANAGEMENT, DEF_TAB_COMPRESSION, RETENTION, BIGFILE FROM CDB_TABLESPACES}
                                          , 'SQL_10' => q{SELECT 0 CON_ID, TABLESPACE_NAME, BLOCK_SIZE, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, MIN_EXTLEN, STATUS, CONTENTS, LOGGING, FORCE_LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE, PLUGGED_IN, SEGMENT_SPACE_MANAGEMENT, DEF_TAB_COMPRESSION, RETENTION, BIGFILE FROM DBA_TABLESPACES}
                                          , 'SQL_11' => q{SELECT 0 CON_ID, TABLESPACE_NAME, BLOCK_SIZE, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, MIN_EXTLEN, STATUS, CONTENTS, LOGGING, FORCE_LOGGING, EXTENT_MANAGEMENT, ALLOCATION_TYPE, PLUGGED_IN, SEGMENT_SPACE_MANAGEMENT, DEF_TAB_COMPRESSION, RETENTION, BIGFILE FROM DBA_TABLESPACES}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_DFILE'         => { 'FILE'   =>  'nirvana_db_dFile.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT CON_ID, FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES, BLOCKS, STATUS, RELATIVE_FNO, AUTOEXTENSIBLE, MAXBYTES, MAXBLOCKS, INCREMENT_BY, USER_BYTES, USER_BLOCKS, ONLINE_STATUS FROM CDB_DATA_FILES}
                                          , 'SQL_10' => q{SELECT 0 CON_ID, FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES, BLOCKS, STATUS, RELATIVE_FNO, AUTOEXTENSIBLE, MAXBYTES, MAXBLOCKS, INCREMENT_BY, USER_BYTES, USER_BLOCKS, ONLINE_STATUS FROM DBA_DATA_FILES}
                                          , 'SQL_11' => q{SELECT 0 CON_ID, FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES, BLOCKS, STATUS, RELATIVE_FNO, AUTOEXTENSIBLE, MAXBYTES, MAXBLOCKS, INCREMENT_BY, USER_BYTES, USER_BLOCKS, ONLINE_STATUS FROM DBA_DATA_FILES}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_TFILE'         => { 'FILE'   =>  'nirvana_db_tFile.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT CON_ID, FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES, BLOCKS, STATUS, RELATIVE_FNO, AUTOEXTENSIBLE, MAXBYTES, MAXBLOCKS, INCREMENT_BY, USER_BYTES, USER_BLOCKS FROM CDB_TEMP_FILES}
                                          , 'SQL_10'    => q{SELECT 0 CON_ID, FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES, BLOCKS, STATUS, RELATIVE_FNO, AUTOEXTENSIBLE, MAXBYTES, MAXBLOCKS, INCREMENT_BY, USER_BYTES, USER_BLOCKS FROM DBA_TEMP_FILES}
                                          , 'SQL_11'    => q{SELECT 0 CON_ID, FILE_NAME, FILE_ID, TABLESPACE_NAME, BYTES, BLOCKS, STATUS, RELATIVE_FNO, AUTOEXTENSIBLE, MAXBYTES, MAXBLOCKS, INCREMENT_BY, USER_BYTES, USER_BLOCKS FROM DBA_TEMP_FILES}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_DSKGRP'        => { 'FILE'   =>  'nirvana_db_dskGrp.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT GROUP_NUMBER, NAME, SECTOR_SIZE, BLOCK_SIZE, ALLOCATION_UNIT_SIZE, STATE, TYPE, TOTAL_MB, FREE_MB, REQUIRED_MIRROR_FREE_MB, USABLE_FILE_MB, OFFLINE_DISKS, COMPATIBILITY, DATABASE_COMPATIBILITY FROM V$ASM_DISKGROUP}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_ASMDSK'        => { 'FILE'   =>  'nirvana_db_asmDsk.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT GROUP_NUMBER, DISK_NUMBER, COMPOUND_INDEX, INCARNATION, MOUNT_STATUS, HEADER_STATUS, MODE_STATUS, STATE, REDUNDANCY, LIBRARY, TOTAL_MB, FREE_MB, NAME, FAILGROUP, LABEL, PATH, UDID, PRODUCT, CREATE_DATE, MOUNT_DATE, REPAIR_TIMER, READS, WRITES, READ_ERRS, WRITE_ERRS, READ_TIME, WRITE_TIME, BYTES_READ, BYTES_WRITTEN FROM V$ASM_DISK}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_LOG'           => { 'FILE'   =>  'nirvana_db_log.txt'
                                          , 'CLASS'  =>  'DB,DG'
                                          , 'DEFINE' =>  'DB_UNIQUE_NAME, GROUP#, THREAD#, SEQUENCE#, BYTES, MEMBERS, ARCHIVED, STATUS, FIRST_CHANGE#, FIRST_TIME'
                                          , 'SQL'    => q{SELECT '?' DB_UNIQUE_NAME, GROUP#, THREAD#, SEQUENCE#, BYTES, MEMBERS, ARCHIVED, STATUS, FIRST_CHANGE#, FIRST_TIME FROM V$LOG}
                                          , 'VALUE'  =>  'UNIQUE_NAME'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_LOGFILE'       => { 'FILE'   =>  'nirvana_db_logFile.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT GROUP#, STATUS, TYPE, MEMBER, IS_RECOVERY_DEST_FILE FROM V$LOGFILE}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_LOGHIST'       => { 'FILE'   =>  'nirvana_db_logHist.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT INST_ID, RECID, STAMP, THREAD#, SEQUENCE#, FIRST_CHANGE#, FIRST_TIME, NEXT_CHANGE#, RESETLOGS_CHANGE#, RESETLOGS_TIME FROM GV$LOG_HISTORY WHERE FIRST_TIME > TRUNC(SYSDATE) - ?}
                                          , 'VALUE'  =>  'LOG_LIMIT'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_CONTROL'   => { 'FILE'   =>  'nirvana_db_awr_control.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT DBID, TO_CHAR(SNAP_INTERVAL) SNAP_INTERVAL, TO_CHAR(RETENTION) RETENTION, TOPNSQL FROM DBA_HIST_WR_CONTROL WHERE DBID = ?}
                                          , 'VALUE'  =>  'DBID'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SNAPSHOT'  => { 'FILE'   =>  'nirvana_db_awr_snapshot.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SNAP_ID, DBID, INSTANCE_NUMBER, STARTUP_TIME, BEGIN_INTERVAL_TIME, END_INTERVAL_TIME, TO_CHAR(FLUSH_ELAPSED) FLUSH_ELAPSED, SNAP_LEVEL, ERROR_COUNT FROM DBA_HIST_SNAPSHOT WHERE DBID = ? AND SNAP_ID >= ?}
                                          , 'VALUE'  =>  'DBID,MIN_SNAP'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_INSTANCE'  => { 'FILE'   =>  'nirvana_db_awr_instance.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT DBID, INSTANCE_NUMBER, STARTUP_TIME, PARALLEL, VERSION, DB_NAME, INSTANCE_NAME, HOST_NAME, LAST_ASH_SAMPLE_ID FROM DBA_HIST_DATABASE_INSTANCE WHERE DBID = ?}
                                          , 'VALUE'  =>  'DBID'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SYSSTAT'   => { 'FILE'   =>  'nirvana_db_awr_sysstat.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SNAP_ID, DBID, INSTANCE_NUMBER, STAT_ID, STAT_NAME, VALUE FROM DBA_HIST_SYSSTAT WHERE DBID = ? AND SNAP_ID >= ? AND STAT_NAME IN (?)}
                                          , 'VALUE'  =>  'DBID,MIN_SNAP,SYSSTAT_FILTER'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_TIMEMODEL' => { 'FILE'   =>  'nirvana_db_awr_timeModel.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SNAP_ID, DBID, INSTANCE_NUMBER, STAT_ID, STAT_NAME, VALUE FROM DBA_HIST_SYS_TIME_MODEL WHERE DBID = ? AND SNAP_ID >= ?}
                                          , 'VALUE'  =>  'DBID,MIN_SNAP'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SGA'       => { 'FILE'   =>  'nirvana_db_awr_sga.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SNAP_ID, DBID, INSTANCE_NUMBER, NAME, POOL, BYTES FROM DBA_HIST_SGASTAT WHERE DBID = ? AND SNAP_ID >= ?}
                                          , 'VALUE'  =>  'DBID,MIN_SNAP'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_OSSTAT'    => { 'FILE'   =>  'nirvana_db_awr_osStat.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SNAP_ID, DBID, INSTANCE_NUMBER, STAT_ID, STAT_NAME, VALUE FROM DBA_HIST_OSSTAT WHERE DBID = ? AND SNAP_ID >= ?}
                                          , 'VALUE'  =>  'DBID,MIN_SNAP'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_RESLIMIT'  => { 'FILE'   =>  'nirvana_db_awr_resLimit.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SNAP_ID, DBID, INSTANCE_NUMBER, RESOURCE_NAME, CURRENT_UTILIZATION, MAX_UTILIZATION, INITIAL_ALLOCATION, LIMIT_VALUE FROM DBA_HIST_RESOURCE_LIMIT WHERE DBID = ? AND SNAP_ID >= ?}
                                          , 'VALUE'  =>  'DBID,MIN_SNAP'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_TOPSEGS'       => { 'FILE'   =>  'nirvana_db_topsegs.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT TABLESPACE_NAME, SEGMENT_NAME||NVL2(PARTITION_NAME, ':'||PARTITION_NAME, '')||(CASE WHEN SEGMENT_TYPE LIKE 'LOB%' THEN (SELECT CHR(10)||'('||TABLE_NAME||'.'||COLUMN_NAME||')' FROM DBA_LOBS WHERE OWNER=A.OWNER AND SEGMENT_NAME=A.SEGMENT_NAME) ELSE '' END) SEGMENT_NAME, SEGMENT_TYPE, SIZE_MB, SIZE_PCT FROM (SELECT ROW_NUMBER() OVER (PARTITION BY TABLESPACE_NAME ORDER BY BYTES DESC) LV, TABLESPACE_NAME, OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, ROUND(BYTES/1048576,2) SIZE_MB, ROUND(100*BYTES/T.ALL_BYTES, 2) SIZE_PCT FROM DBA_SEGMENTS S, (SELECT TABLESPACE_NAME TS_NAME, SUM(BYTES) ALL_BYTES FROM DBA_SEGMENTS GROUP BY TABLESPACE_NAME) T WHERE S.TABLESPACE_NAME=T.TS_NAME AND S.TABLESPACE_NAME IN (SELECT TABLESPACE_NAME FROM DBA_TABLESPACES WHERE CONTENTS = 'PERMANENT')) A WHERE LV <= ?}
                                          , 'VALUE'  =>  'TOP_SEGMENTS'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SEGSUMM_SIZE'  => { 'FILE'   =>  'nirvana_db_segSumm_size.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT CON_ID, TABLESPACE_NAME, SEGMENT_TYPE, SUM(BYTES) SEGMENT_BYTES, COUNT(1) SEGMENT_COUNT FROM CDB_SEGMENTS S WHERE NOT EXISTS (SELECT /*+ unnest hash_aj */ 1 FROM CDB_RECYCLEBIN R WHERE R.CON_ID = S.CON_ID AND R.OWNER = S.OWNER AND R.OBJECT_NAME = S.SEGMENT_NAME) GROUP BY CON_ID, TABLESPACE_NAME,SEGMENT_TYPE}
                                          , 'SQL_10' => q{SELECT 0 CON_ID, TABLESPACE_NAME, SEGMENT_TYPE, SUM(BYTES) SEGMENT_BYTES, COUNT(1) SEGMENT_COUNT FROM DBA_SEGMENTS S WHERE NOT EXISTS (SELECT /*+ unnest hash_aj */ 1 FROM DBA_RECYCLEBIN R WHERE R.OWNER = S.OWNER AND R.OBJECT_NAME = S.SEGMENT_NAME) GROUP BY TABLESPACE_NAME,SEGMENT_TYPE}
                                          , 'SQL_11' => q{SELECT 0 CON_ID, TABLESPACE_NAME, SEGMENT_TYPE, SUM(BYTES) SEGMENT_BYTES, COUNT(1) SEGMENT_COUNT FROM DBA_SEGMENTS S WHERE NOT EXISTS (SELECT /*+ unnest hash_aj */ 1 FROM DBA_RECYCLEBIN R WHERE R.OWNER = S.OWNER AND R.OBJECT_NAME = S.SEGMENT_NAME) GROUP BY TABLESPACE_NAME,SEGMENT_TYPE}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_TOPEVENT'  => { 'FILE'   =>  'nirvana_db_awr_topEvent.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT SNAP_TIME,INSTANCE_NUMBER,TOP_LEVEL,EVENT_NAME,TOTAL_WAITS,TOTAL_TIME,WAIT_CLASS FROM (SELECT ROW_NUMBER() OVER (PARTITION BY INSTANCE_NUMBER,SNAP_TIME ORDER BY TOTAL_TIME DESC) TOP_LEVEL,SNAP_TIME,INSTANCE_NUMBER,EVENT_NAME,TOTAL_WAITS,TOTAL_TIME,WAIT_CLASS FROM (SELECT /*+ NO_MERGE(S) NO_MERGE(E) LEADING(S,E) USE_HASE(E) */ S.SNAP_TIME,E.INSTANCE_NUMBER,E.EVENT_NAME,E.TOTAL_WAITS-LAG(E.TOTAL_WAITS) OVER (PARTITION BY E.INSTANCE_NUMBER,E.EVENT_NAME ORDER BY E.SNAP_ID) TOTAL_WAITS,E.TIME_WAITED_MICRO-LAG(E.TIME_WAITED_MICRO) OVER (PARTITION BY E.INSTANCE_NUMBER,E.EVENT_NAME ORDER BY E.SNAP_ID) TOTAL_TIME,WAIT_CLASS FROM (SELECT /*+ MATERIALIZE */ SNAP_ID,INSTANCE_NUMBER,EVENT_NAME,?,WAIT_CLASS FROM DBA_HIST_SYSTEM_EVENT WHERE WAIT_CLASS<>'Idle' AND DBID=?) E,(SELECT MIN(SNAP_ID) ID,INSTANCE_NUMBER,TRUNC(BEGIN_INTERVAL_TIME,'HH24') SNAP_TIME FROM DBA_HIST_SNAPSHOT WHERE DBID=? AND SNAP_ID>=? GROUP BY INSTANCE_NUMBER,TRUNC(BEGIN_INTERVAL_TIME,'HH24')) S WHERE E.INSTANCE_NUMBER=S.INSTANCE_NUMBER AND E.SNAP_ID=S.ID) WHERE TOTAL_WAITS>0 AND TOTAL_TIME>0) W WHERE TOP_LEVEL<=? OR EVENT_NAME IN (?)}
                                          , 'VALUE'  =>  'SQL_LIST,DBID,DBID,MIN_SNAP,TOP_WAITS,EVENT_FILTER'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_DICTSTAT'      => { 'FILE'   =>  'nirvana_db_dictStat.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT D.DICT_COUNT, D.DICT_NOT_COLLECT, F.FIXED_COUNT, F.FIXED_NOT_COLLECT FROM (SELECT SUM(DECODE(LAST_ANALYZED, NULL, 1, 0)) DICT_NOT_COLLECT, COUNT(*) DICT_COUNT FROM DBA_TABLES WHERE OWNER = 'SYS') D, (SELECT SUM(DECODE(LAST_ANALYZED, NULL, 1, 0)) FIXED_NOT_COLLECT, COUNT(*) FIXED_COUNT FROM DBA_TAB_STATISTICS WHERE OBJECT_TYPE = 'FIXED TABLE') F}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_PAR'           => { 'FILE'   =>  'nirvana_db_par.txt'
                                          , 'CLASS'  =>  'DB,SUB'
                                          , 'SQL'    => q{SELECT '?' INST_TYPE, INST_ID, NUM, NAME, TYPE, VALUE, DISPLAY_VALUE, ISDEFAULT, ISSES_MODIFIABLE, ISSYS_MODIFIABLE, ISINSTANCE_MODIFIABLE, ISMODIFIED, ISADJUSTED, ISDEPRECATED, DESCRIPTION, UPDATE_COMMENT, HASH FROM GV$PARAMETER}
                                          , 'VALUE'  =>  'INST_TYPE'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SPPAR'         => { 'FILE'   =>  'nirvana_db_spPar.txt'
                                          , 'CLASS'  =>  'DB,SUB'
                                          , 'SQL'    => q{SELECT '?' INST_TYPE, SID, NAME, VALUE, DISPLAY_VALUE, ISSPECIFIED, ORDINAL, UPDATE_COMMENT FROM V$SPPARAMETER WHERE ISSPECIFIED = 'TRUE'}
                                          , 'VALUE'  =>  'INST_TYPE'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_PROPS'         => { 'FILE'   =>  'nirvana_db_props.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    => q{SELECT NAME,VALUE$ VALUE,COMMENT$ DESCRIPTION,CON_ID FROM CONTAINERS(PROPS$)}
                                          , 'SQL_10' => q{SELECT NAME,VALUE$ VALUE,COMMENT$ DESCRIPTION,0 CON_ID FROM PROPS$}
                                          , 'SQL_11' => q{SELECT NAME,VALUE$ VALUE,COMMENT$ DESCRIPTION,0 CON_ID FROM PROPS$}
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }                                          
               , 'RD_DB_BAKSET'        => { 'FILE'   =>  'nirvana_db_bakSet.txt'
                                          , 'CLASS'  =>  'DB,DG'
                                          , 'DEFINE' =>  'DB_UNIQUE_NAME, SESSION_KEY, SESSION_RECID, SESSION_STAMP, BS_KEY, RECID, STAMP, SET_STAMP, SET_COUNT, BACKUP_TYPE, CONTROLFILE_INCLUDED, INCREMENTAL_LEVEL, PIECES, START_TIME, COMPLETION_TIME, ELAPSED_SECONDS, BLOCK_SIZE, KEEP, KEEP_UNTIL, KEEP_OPTIONS, DEVICE_TYPE, COMPRESSED, NUM_COPIES, OUTPUT_BYTES, ORIGINAL_INPUT_BYTES, COMPRESSION_RATIO, STATUS, ORIGINAL_INPRATE_BYTES, OUTPUT_RATE_BYTES, ORIGINAL_INPUT_BYTES_DISPLAY, OUTPUT_BYTES_DISPLAY, ORIGINAL_INPRATE_BYTES_DISPLAY, OUTPUT_RATE_BYTES_DISPLAY, TIME_TAKEN_DISPLAY'
                                          , 'SQL'    => q{SELECT '?' DB_UNIQUE_NAME, SESSION_KEY, SESSION_RECID, SESSION_STAMP, BS_KEY, RECID, STAMP, SET_STAMP, SET_COUNT, BACKUP_TYPE, CONTROLFILE_INCLUDED, INCREMENTAL_LEVEL, PIECES, START_TIME, COMPLETION_TIME, ELAPSED_SECONDS, BLOCK_SIZE, KEEP, KEEP_UNTIL, KEEP_OPTIONS, DEVICE_TYPE, COMPRESSED, NUM_COPIES, OUTPUT_BYTES, ORIGINAL_INPUT_BYTES, COMPRESSION_RATIO, STATUS, ORIGINAL_INPRATE_BYTES, OUTPUT_RATE_BYTES, ORIGINAL_INPUT_BYTES_DISPLAY, OUTPUT_BYTES_DISPLAY, ORIGINAL_INPRATE_BYTES_DISPLAY, OUTPUT_RATE_BYTES_DISPLAY, TIME_TAKEN_DISPLAY FROM V$BACKUP_SET_DETAILS}
                                          , 'VALUE'  =>  'UNIQUE_NAME'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_BAKSPFILE'     => { 'FILE'   =>  'nirvana_db_bakSPfile.txt'
                                          , 'CLASS'  =>  'DB,DG'
                                          , 'DEFINE' =>  'DB_UNIQUE_NAME, RECID, STAMP, SET_STAMP, SET_COUNT, MODIFICATION_TIME, BYTES, COMPLETION_TIME'
                                          , 'SQL'    => q{SELECT '?' DB_UNIQUE_NAME, RECID, STAMP, SET_STAMP, SET_COUNT, MODIFICATION_TIME, BYTES, COMPLETION_TIME FROM V$BACKUP_SPFILE}
                                          , 'VALUE'  =>  'UNIQUE_NAME'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_BAKFILE'       => { 'FILE'   =>  'nirvana_db_bakFile.txt'
                                          , 'CLASS'  =>  'DB,DG'
                                          , 'DEFINE' =>  'DB_UNIQUE_NAME, RECID, STAMP, SET_STAMP, SET_COUNT, FILE#, CREATION_CHANGE#, CREATION_TIME, RESETLOGS_CHANGE#, RESETLOGS_TIME, INCREMENTAL_LEVEL, INCREMENTAL_CHANGE#, CHECKPOINT_CHANGE#, CHECKPOINT_TIME, ABSOLUTE_FUZZY_CHANGE#, MARKED_CORRUPT, MEDIA_CORRUPT, LOGICALLY_CORRUPT, DATAFILE_BLOCKS, BLOCKS, BLOCK_SIZE, OLDEST_OFFLINE_RANGE, COMPLETION_TIME, CONTROLFILE_TYPE, USED_CHANGE_TRACKING, BLOCKS_READ, USED_OPTIMIZATION'
                                          , 'SQL'    => q{SELECT '?' DB_UNIQUE_NAME, RECID, STAMP, SET_STAMP, SET_COUNT, FILE#, CREATION_CHANGE#, CREATION_TIME, RESETLOGS_CHANGE#, RESETLOGS_TIME, INCREMENTAL_LEVEL, INCREMENTAL_CHANGE#, CHECKPOINT_CHANGE#, CHECKPOINT_TIME, ABSOLUTE_FUZZY_CHANGE#, MARKED_CORRUPT, MEDIA_CORRUPT, LOGICALLY_CORRUPT, DATAFILE_BLOCKS, BLOCKS, BLOCK_SIZE, OLDEST_OFFLINE_RANGE, COMPLETION_TIME, CONTROLFILE_TYPE, USED_CHANGE_TRACKING, BLOCKS_READ, USED_OPTIMIZATION FROM (SELECT ROW_NUMBER() OVER (PARTITION BY FILE# ORDER BY COMPLETION_TIME DESC) LV, T.* FROM V$BACKUP_DATAFILE T WHERE INCREMENTAL_LEVEL = 0 OR INCREMENTAL_LEVEL IS NULL) WHERE LV = 1}
                                          , 'VALUE'  =>  'UNIQUE_NAME'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_BAKARCH'       => { 'FILE'   =>  'nirvana_db_bakArch.txt'
                                          , 'CLASS'  =>  'DB,DG'
                                          , 'DEFINE' =>  'DB_UNIQUE_NAME, BTYPE, BTYPE_KEY, SESSION_KEY, SESSION_RECID, SESSION_STAMP, ID1, ID2, THREAD#, SEQUENCE#, RESETLOGS_CHANGE#, RESETLOGS_TIME, FIRST_CHANGE#, FIRST_TIME, NEXT_CHANGE#, NEXT_TIME, FILESIZE, COMPRESSION_RATIO, FILESIZE_DISPLAY'
                                          , 'SQL'    => q{SELECT '?' DB_UNIQUE_NAME, BTYPE, BTYPE_KEY, SESSION_KEY, SESSION_RECID, SESSION_STAMP, ID1, ID2, THREAD#, SEQUENCE#, RESETLOGS_CHANGE#, RESETLOGS_TIME, FIRST_CHANGE#, FIRST_TIME, NEXT_CHANGE#, NEXT_TIME, FILESIZE, COMPRESSION_RATIO, FILESIZE_DISPLAY FROM V$BACKUP_ARCHIVELOG_DETAILS}
                                          , 'VALUE'  =>  'UNIQUE_NAME'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_MANSTANDBY'    => { 'FILE'   =>  'nirvana_db_manStandby.txt'
                                          , 'CLASS'  =>  'DG'
                                          , 'DEFINE' =>  'DB_UNIQUE_NAME,INST_ID,PROCESS,PID,STATUS,CLIENT_PROCESS,CLIENT_PID,CLIENT_DBID,GROUP#,RESETLOG_ID,THREAD#,SEQUENCE#,BLOCK#,BLOCKS,DELAY_MINS,KNOWN_AGENTS,ACTIVE_AGENTS'
                                          , 'SQL'    => q{SELECT '?' DB_UNIQUE_NAME,INST_ID,PROCESS,PID,STATUS,CLIENT_PROCESS,CLIENT_PID,CLIENT_DBID,GROUP#,RESETLOG_ID,THREAD#,SEQUENCE#,BLOCK#,BLOCKS,DELAY_MINS,KNOWN_AGENTS,ACTIVE_AGENTS FROM GV$MANAGED_STANDBY}
                                          , 'VALUE'  =>  'UNIQUE_NAME'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_CRSSTAT'       => { 'FILE'   =>  'nirvana_db_crsstat.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'DEFINE' =>  'RESOURCE_NAME,RESOURCE_STATUS,TARGET_STATUS,HOST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , RD_DB_SCN_COMPAT      => { FILE     =>  'nirvana_db_scn_compat.txt'
                                          , CLASS    =>  'SUB'
                                          , DEFINE   =>  'ROLLOVER_DATE,TARGET_COMPAT,ENABLED'
                                          , STATUS   =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_REPORT'    => { 'FILE'   =>  'nirvana_db_awr_report.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'DEFINE' =>  'TOP_LEVEL,INSTANCE_NUMBER,BEGIN_TIME,BEGIN_SNAP,END_TIME,END_SNAP,STAT_NAME,STAT_VALUE,FILE_NAME'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SQLSTAT'   => { 'FILE'   =>  'nirvana_db_awr_sqlStat.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'DEFINE' =>  'INSTANCE_NUMBER,SNAP_TIME,DBTIME,SQL_FMS,SQL_ID,SQL_ALL,SQL_SNAP,MODULE,PARSE_USER,VERSION_COUNT,FETCHES,SORTS,EXECUTIONS,LOADS,INVALIDATIONS,PARSE_CALLS,DISK_READS,BUFFER_GETS,ROWS_PROCESSED,CPU_TIME,ELAPSED_TIME,IO_WAIT,CL_WAIT,AP_WAIT,CC_WAIT,PLAN_HASH_VALUE'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SQLTEXT'   => { 'FILE'   =>  'nirvana_db_awr_sqlText.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SQLPLAN'   => { 'FILE'   =>  'nirvana_db_awr_sqlPlan.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT H.SQL_ID, H.PLAN_HASH_VALUE, H.ID, OPERATION, OPTIONS, OBJECT_NODE, OBJECT#, OBJECT_OWNER, OBJECT_NAME, OBJECT_ALIAS, OBJECT_TYPE, OPTIMIZER, PARENT_ID, DEPTH, POSITION, SEARCH_COLUMNS, COST, CARDINALITY, BYTES, OTHER_TAG, PARTITION_START, PARTITION_STOP, PARTITION_ID, SUBSTR(OTHER, 1, 1000) OTHER, DISTRIBUTION, CPU_COST, IO_COST, TEMP_SPACE, SUBSTR(P.ACCESS_PREDICATES, 1, 1000) ACCESS_PREDICATES, SUBSTR(P.FILTER_PREDICATES, 1, 1000) FILTER_PREDICATES, PROJECTION, TIME, QBLOCK_NAME, REMARKS, TIMESTAMP FROM DBA_HIST_SQL_PLAN H LEFT OUTER JOIN (SELECT SQL_ID, PLAN_HASH_VALUE, ID, MAX(ACCESS_PREDICATES) ACCESS_PREDICATES, MAX(FILTER_PREDICATES) FILTER_PREDICATES FROM GV$SQL_PLAN GROUP BY SQL_ID, PLAN_HASH_VALUE, ID) P ON H.SQL_ID = P.SQL_ID AND H.PLAN_HASH_VALUE = P.PLAN_HASH_VALUE AND H.ID = P.ID WHERE H.DBID = ? AND H.SQL_ID IN (?)}
                                          , 'VALUE'  =>  'DBID,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SEGSTATS'  => { 'FILE'   =>  'nirvana_db_awr_segStats.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    =>  'SELECT SNAP_ID,INSTANCE_NUMBER,TS#,OBJ#,DATAOBJ#,LOGICAL_READS_DELTA,PHYSICAL_READS_DELTA,TABLE_SCANS_DELTA,DB_BLOCK_CHANGES_DELTA,ROW_LOCK_WAITS_DELTA,BUFFER_BUSY_WAITS_DELTA FROM (SELECT SNAP_ID,INSTANCE_NUMBER,TS#,OBJ#,DATAOBJ#,LOGICAL_READS_DELTA,PHYSICAL_READS_DELTA,TABLE_SCANS_DELTA,DB_BLOCK_CHANGES_DELTA,ROW_LOCK_WAITS_DELTA,BUFFER_BUSY_WAITS_DELTA,ROW_NUMBER() OVER (PARTITION BY SNAP_ID, INSTANCE_NUMBER ORDER BY LOGICAL_READS_DELTA DESC) LRD_ID,ROW_NUMBER() OVER (PARTITION BY SNAP_ID, INSTANCE_NUMBER ORDER BY PHYSICAL_READS_DELTA DESC) PRD_ID,ROW_NUMBER() OVER (PARTITION BY SNAP_ID, INSTANCE_NUMBER ORDER BY TABLE_SCANS_DELTA DESC) TSD_ID,ROW_NUMBER() OVER (PARTITION BY SNAP_ID, INSTANCE_NUMBER ORDER BY DB_BLOCK_CHANGES_DELTA DESC) DBCD_ID,ROW_NUMBER() OVER (PARTITION BY SNAP_ID, INSTANCE_NUMBER ORDER BY ROW_LOCK_WAITS_DELTA DESC) RLWD_ID,ROW_NUMBER() OVER (PARTITION BY SNAP_ID, INSTANCE_NUMBER ORDER BY BUFFER_BUSY_WAITS_DELTA DESC) BBRD_ID FROM DBA_HIST_SEG_STAT WHERE DBID = ? AND SNAP_ID >= ?) WHERE LRD_ID  <= ? OR PRD_ID  <= ? OR TSD_ID  <= ? OR DBCD_ID <= ? OR RLWD_ID <= ? OR BBRD_ID <= ?'
                                          , 'VALUE'  =>  'DBID,MIN_SNAP,TOP_SEGSTATS,TOP_SEGSTATS,TOP_SEGSTATS,TOP_SEGSTATS,TOP_SEGSTATS,TOP_SEGSTATS'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_AWR_SEGOBJ'    => { 'FILE'   =>  'nirvana_db_awr_segObj.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    =>  'SELECT TS#,OBJ#,DATAOBJ#,OWNER,OBJECT_NAME,SUBOBJECT_NAME,OBJECT_TYPE,TABLESPACE_NAME,PARTITION_TYPE FROM DBA_HIST_SEG_STAT_OBJ WHERE DBID = ? AND (TS#,OBJ#,DATAOBJ#) IN (?)'
                                          , 'VALUE'  =>  'DBID,SEGOBJ_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_TRIGGER'       => { 'FILE'   =>  'nirvana_db_trigger.txt'
                                          , 'CLASS'  =>  'DB'
                                          , 'SQL'    =>  "SELECT OWNER, TRIGGER_NAME, TRIGGER_TYPE, TRIGGERING_EVENT, TABLE_OWNER, BASE_OBJECT_TYPE, TABLE_NAME, COLUMN_NAME, REFERENCING_NAMES, WHEN_CLAUSE, STATUS, DESCRIPTION, ACTION_TYPE FROM DBA_TRIGGERS WHERE OWNER = 'SYS' OR TRIM(BASE_OBJECT_TYPE) = 'DATABASE'"
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_TABLES'        => { 'FILE'   =>  'nirvana_db_table.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT OWNER, TABLE_NAME, TABLESPACE_NAME, CLUSTER_NAME, IOT_NAME, STATUS, PCT_FREE, PCT_USED, INI_TRANS, MAX_TRANS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING, BACKED_UP, NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN, AVG_SPACE_FREELIST_BLOCKS, NUM_FREELIST_BLOCKS, DEGREE, INSTANCES, CACHE, TABLE_LOCK, SAMPLE_SIZE, LAST_ANALYZED, PARTITIONED, IOT_TYPE, TEMPORARY, SECONDARY, NESTED, BUFFER_POOL, ROW_MOVEMENT, GLOBAL_STATS, USER_STATS, DURATION, SKIP_CORRUPT, MONITORING, CLUSTER_OWNER, DEPENDENCIES, COMPRESSION, DROPPED FROM DBA_TABLES WHERE OWNER = '?' AND TABLE_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_INDEXES'       => { 'FILE'   =>  'nirvana_db_index.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT OWNER, INDEX_NAME, INDEX_TYPE, TABLE_OWNER, TABLE_NAME, TABLE_TYPE, UNIQUENESS, COMPRESSION, PREFIX_LENGTH, TABLESPACE_NAME, INI_TRANS, MAX_TRANS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, PCT_THRESHOLD, INCLUDE_COLUMN, FREELISTS, FREELIST_GROUPS, PCT_FREE, LOGGING, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, STATUS, NUM_ROWS, SAMPLE_SIZE, LAST_ANALYZED, DEGREE, INSTANCES, PARTITIONED, TEMPORARY, GENERATED, SECONDARY, BUFFER_POOL, USER_STATS, DURATION, PCT_DIRECT_ACCESS, ITYP_OWNER, ITYP_NAME, PARAMETERS, GLOBAL_STATS, DOMIDX_STATUS, DOMIDX_OPSTATUS, FUNCIDX_STATUS, JOIN_INDEX, IOT_REDUNDANT_PKEY_ELIM, DROPPED FROM DBA_INDEXES WHERE OWNER = '?' AND INDEX_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_COLUMNS'       => { 'FILE'   =>  'nirvana_db_column.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT OWNER, TABLE_NAME, COLUMN_NAME, DATA_TYPE, DATA_TYPE_MOD, DATA_TYPE_OWNER, DATA_LENGTH, DATA_PRECISION, DATA_SCALE, NULLABLE, COLUMN_ID, DEFAULT_LENGTH, DATA_DEFAULT, NUM_DISTINCT, LOW_VALUE, HIGH_VALUE, DENSITY, NUM_NULLS, NUM_BUCKETS, LAST_ANALYZED, SAMPLE_SIZE, CHARACTER_SET_NAME, CHAR_COL_DECL_LENGTH, GLOBAL_STATS, USER_STATS, AVG_COL_LEN, CHAR_LENGTH, CHAR_USED, V80_FMT_IMAGE, DATA_UPGRADED, HISTOGRAM FROM DBA_TAB_COLUMNS WHERE OWNER = '?' AND TABLE_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_TABPART'       => { 'FILE'   =>  'nirvana_db_tabPart.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT TABLE_OWNER, TABLE_NAME, COMPOSITE, PARTITION_NAME, SUBPARTITION_COUNT, HIGH_VALUE, HIGH_VALUE_LENGTH, PARTITION_POSITION, TABLESPACE_NAME, PCT_FREE, PCT_USED, INI_TRANS, MAX_TRANS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENT, MAX_EXTENT, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING, COMPRESSION, NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN, SAMPLE_SIZE, LAST_ANALYZED, BUFFER_POOL, GLOBAL_STATS, USER_STATS FROM DBA_TAB_PARTITIONS WHERE TABLE_OWNER = '?' AND TABLE_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_TABSUBPART'    => { 'FILE'   =>  'nirvana_db_tabSubPart.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT TABLE_OWNER, TABLE_NAME, PARTITION_NAME, SUBPARTITION_NAME, HIGH_VALUE, HIGH_VALUE_LENGTH, SUBPARTITION_POSITION, TABLESPACE_NAME, PCT_FREE, PCT_USED, INI_TRANS, MAX_TRANS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENT, MAX_EXTENT, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING, COMPRESSION, NUM_ROWS, BLOCKS, EMPTY_BLOCKS, AVG_SPACE, CHAIN_CNT, AVG_ROW_LEN, SAMPLE_SIZE, LAST_ANALYZED, BUFFER_POOL, GLOBAL_STATS, USER_STATS FROM DBA_TAB_SUBPARTITIONS WHERE TABLE_OWNER = '?' AND TABLE_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_INDPART'       => { 'FILE'   =>  'nirvana_db_indPart.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT INDEX_OWNER, INDEX_NAME, COMPOSITE, PARTITION_NAME, SUBPARTITION_COUNT, HIGH_VALUE, HIGH_VALUE_LENGTH, PARTITION_POSITION, STATUS, TABLESPACE_NAME, PCT_FREE, INI_TRANS, MAX_TRANS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENT, MAX_EXTENT, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING, COMPRESSION, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, NUM_ROWS, SAMPLE_SIZE, LAST_ANALYZED, BUFFER_POOL, USER_STATS, PCT_DIRECT_ACCESS, GLOBAL_STATS, DOMIDX_OPSTATUS, PARAMETERS FROM DBA_IND_PARTITIONS WHERE INDEX_OWNER = '?' AND INDEX_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_INDSUBPART'    => { 'FILE'   =>  'nirvana_db_indSubPart.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT INDEX_OWNER, INDEX_NAME, PARTITION_NAME, SUBPARTITION_NAME, HIGH_VALUE, HIGH_VALUE_LENGTH, SUBPARTITION_POSITION, STATUS, TABLESPACE_NAME, PCT_FREE, INI_TRANS, MAX_TRANS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENT, MAX_EXTENT, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, LOGGING, COMPRESSION, BLEVEL, LEAF_BLOCKS, DISTINCT_KEYS, AVG_LEAF_BLOCKS_PER_KEY, AVG_DATA_BLOCKS_PER_KEY, CLUSTERING_FACTOR, NUM_ROWS, SAMPLE_SIZE, LAST_ANALYZED, BUFFER_POOL, USER_STATS, GLOBAL_STATS FROM DBA_IND_SUBPARTITIONS WHERE INDEX_OWNER = '?' AND INDEX_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_INDCOL'        => { 'FILE'   =>  'nirvana_db_indCol.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT INDEX_OWNER, INDEX_NAME, TABLE_OWNER, TABLE_NAME, COLUMN_NAME, COLUMN_POSITION, COLUMN_LENGTH, CHAR_LENGTH, DESCEND FROM DBA_IND_COLUMNS WHERE INDEX_OWNER = '?' AND INDEX_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_INDEXP'        => { 'FILE'   =>  'nirvana_db_indExp.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT INDEX_OWNER, INDEX_NAME, TABLE_OWNER, TABLE_NAME, COLUMN_EXPRESSION, COLUMN_POSITION FROM DBA_IND_EXPRESSIONS WHERE INDEX_OWNER = '?' AND INDEX_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_OBJECT'        => { 'FILE'   =>  'nirvana_db_obj.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT OWNER, OBJECT_NAME, SUBOBJECT_NAME, OBJECT_ID, DATA_OBJECT_ID, OBJECT_TYPE, CREATED, LAST_DDL_TIME, TIMESTAMP, STATUS, TEMPORARY, GENERATED, SECONDARY FROM DBA_OBJECTS WHERE OWNER = '?' AND OBJECT_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SEGMENT'       => { 'FILE'   =>  'nirvana_db_segment.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT OWNER, SEGMENT_NAME, PARTITION_NAME, SEGMENT_TYPE, TABLESPACE_NAME, HEADER_FILE, HEADER_BLOCK, BYTES, BLOCKS, EXTENTS, INITIAL_EXTENT, NEXT_EXTENT, MIN_EXTENTS, MAX_EXTENTS, PCT_INCREASE, FREELISTS, FREELIST_GROUPS, RELATIVE_FNO, BUFFER_POOL FROM DBA_SEGMENTS WHERE OWNER = '?' AND SEGMENT_NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_PARTKEY'       => { 'FILE'   =>  'nirvana_db_partKey.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT OWNER, NAME, OBJECT_TYPE, COLUMN_NAME, COLUMN_POSITION FROM DBA_PART_KEY_COLUMNS WHERE OWNER = '?' AND NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               , 'RD_DB_SUBPARTKEY'    => { 'FILE'   =>  'nirvana_db_subPartKey.txt'
                                          , 'CLASS'  =>  'SUB'
                                          , 'SQL'    => q{SELECT OWNER, NAME, OBJECT_TYPE, COLUMN_NAME, COLUMN_POSITION FROM DBA_SUBPART_KEY_COLUMNS WHERE OWNER = '?' AND NAME IN (?)}
                                          , 'VALUE'  =>  'OBJ_SCHEMA,SQL_LIST'
                                          , 'STATUS' =>  'ENABLE'  # Switcher: Enable/Disable
                                          }
               );


################################################################################
##                                                                            ##
## Collection Status                                                          ##
##                                                                            ##
################################################################################
our %gStatus;



################################################################################
##                                                                            ##
## Alert Capture Keywords                                                     ##
##                                                                            ##
################################################################################
our %gALTCapture = ( 'CKPT_NOT_OK'   => 'Checkpoint\s+not\s+complete'
                   , 'ARCH_REQUIRED' => 'archival\s+required'
                   , 'WARNING'       => 'warn'
                   );


1;
