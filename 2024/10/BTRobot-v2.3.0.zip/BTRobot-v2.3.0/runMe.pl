#!/usr/bin/perl
#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 09/02/17 | Use Local Setting Envs (PATH/LD_LIBRARY_PATH etc.)     ##
##         | 11/02/17 | Add Multi-Server Mode                                  ##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use BTTools;
use BTConfig;
use Getopt::Std;

# 0. Open Logfile
# ------------------------------------------------------------------------------
logADM('OPEN', "$gFName{'LOGFILE'}");


# 1. Check Multi-Server Mode
# ------------------------------------------------------------------------------
my @allARGV = @ARGV;
my %args;
getopts('B:c:e:hi:L:M:o:p:Qr:R:s:St:T:u:U:vw:z', \%args);
if(exists $args{'M'})
{
    $args{'M'} = $gFName{'SERVER_CONFIG'} if(not defined $args{'M'});
    if(-r $gFName{'CONFIG_DIR'}.'/'.$args{'M'})
    {
        printLOG('runMe', "Multi-Server Collecction using Config File [$args{'M'}]");
        system("perl $gFName{'LIB_DIR'}/$gFName{'DISPATCHER_SCRIPT'} $args{'M'}");
        logADM('CLOSE');
    }
    else
    {
        printLOG('runMe', "Cannot Read Multi-Server Config File [$args{'M'}]");
        logADM('CLOSE');
        exit 1;
    }
}
else
{
    printLOG('runMe', "Running in Local Mode");
    # 1. Check Environment
    # ------------------------------------------------------------------------------
    die "Oracle Home not Set" if(not defined $ENV{'ORACLE_HOME'});
    die "Oracle SID not Set"  if(not defined $ENV{'ORACLE_SID'});

    # 2. Set Library
    # ------------------------------------------------------------------------------
    if($^O eq 'MSWin32')
    {
        $ENV{'PERL5LIB'}        = '.' if(not defined $ENV{'PERL5LIB'});
        $ENV{'PATH'}            = "$ENV{'PATH'};$ENV{ORACLE_HOME}\\lib32;$ENV{ORACLE_HOME}\\lib";
        $ENV{'PERL5LIB'}        = "$ENV{'ORACLE_HOME'}\\perl\\lib;$ENV{'ORACLE_HOME'}\\perl\\lib\\site_perl;./lib;$ENV{'PERL5LIB'}";
        printLOG('runMe', "Library  [$ENV{'PATH'}]");
        printLOG('runMe', "Perl Lib [$ENV{'PERL5LIB'}]");
    }
    else
    {
        $ENV{'LD_LIBRARY_PATH'} = '.' if(not defined $ENV{'LD_LIBRARY_PATH'});
        $ENV{'SHLIB_PATH'}      = '.' if(not defined $ENV{'SHLIB_PATH'});
        $ENV{'LIBPATH'}         = '.' if(not defined $ENV{'LIBPATH'});
        $ENV{'PERL5LIB'}        = '.' if(not defined $ENV{'PERL5LIB'});
        $ENV{'LD_LIBRARY_PATH'} = "$ENV{'ORACLE_HOME'}/lib32:$ENV{'ORACLE_HOME'}/lib:$ENV{'LD_LIBRARY_PATH'}";
        $ENV{'SHLIB_PATH'}      = "$ENV{'ORACLE_HOME'}/lib32:$ENV{'ORACLE_HOME'}/lib:$ENV{'SHLIB_PATH'}";
        $ENV{'LIBPATH'}         = "$ENV{'ORACLE_HOME'}/lib32:$ENV{'ORACLE_HOME'}/lib:$ENV{'LIBPATH'}";
        $ENV{'PERL5LIB'}        = "$ENV{'ORACLE_HOME'}/perl/lib:$ENV{'ORACLE_HOME'}/perl/lib/site_perl:./lib:$ENV{'PERL5LIB'}";
        printLOG('runMe', "Library  [$ENV{'LIBPATH'}]");
        printLOG('runMe', "Perl Lib [$ENV{'PERL5LIB'}]");
    }


    # 3. Set Local Veriable, Get OS Version for AIX Usage
    # ------------------------------------------------------------------------------
    $ENV{'BTROBOT_LOCAL'} = $^O;
    if($^O eq 'aix')
    {
        $ENV{'AIX_VERSION'} = execOS('oslevel -s 2>/dev/null');
        printLOG('runMe', "Set AIX Version [$ENV{'AIX_VERSION'}]", 'L');
    }
    printLOG('runMe', "Set Local Tip [$ENV{'BTROBOT_LOCAL'}]", 'L');


    # 4. Finding Perl Executable
    # ------------------------------------------------------------------------------
    $ENV{'PERL_EXEC'} = $ENV{'ORACLE_HOME'}.'/perl/bin/perl';
    if(not -x $ENV{'PERL_EXEC'})
    {
        my @searchDir = "$ENV{'ORACLE_HOME'}/perl";
        while(scalar @searchDir)
        {
            my $nDir = shift @searchDir;
            printLOG('runMe', "Search Perl [$nDir]", 'L');
            if(opendir CDIR, $nDir)
            {
                while(my $fNam = readdir CDIR)
                {
                    chomp $fNam;
                    if($fNam eq '.' or $fNam eq '..')
                    {
                        next;
                    }
                    elsif($fNam eq 'perl' or uc($fNam) eq 'PERL.EXE' and -x "$nDir/$fNam")
                    {
                        $ENV{'PERL_EXEC'} = "$nDir/$fNam";
                        undef @searchDir;
                        last;
                    }
                    elsif(-d "$nDir/$fNam")
                    {
                        push(@searchDir, "$nDir/$fNam");
                    }
                }
                closedir CDIR;
            }
        }
    }
    printLOG('runMe', "Get Perl [$ENV{'PERL_EXEC'}]");


    # 5. Run Main Script
    # ------------------------------------------------------------------------------
    logADM('CLOSE');
    system("$ENV{'PERL_EXEC'} $gFName{'LIB_DIR'}/$gFName{'MAIN_SCRIPT'} ".join(' ', @allARGV));
}
