#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 17/04/17 | Expand Multi-Host into Multi-Rows                      ##
## 2.2.0   | 05/05/17 | Version [2.2.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osHosts;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osHosts", "Begin OS Hosts Collection");
    my $fNam;


    # Get File Location
    # --------------------------------------------------------------------------
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        $fNam = 'C:\Windows\System32\drivers\etc\hosts';
    }
    else{
        $fNam = '/etc/hosts';
    }
    printLOG("osHosts", "Hosts File Location [$fNam]");


    # Read Hosts File
    # --------------------------------------------------------------------------
    printLOG("osHosts", "Read Hosts File [$fNam]", 'L');
    if(open HOSTF, '<', $fNam)
    {
        # Loop to Read File
        while(<HOSTF>)
        {
            s/[\r\n]+//;                # chomp
            printLOG("osHosts", "Read [$_]", 'L');
            s/(\A\s+|\s*#.*|\s+\z)//g;  # Remove Blanks at the Begin/End; Remove Comments

            if($_ =~ m/\A([\d\.]+)\s+(.+)\z/)
            {
                foreach(split(/\s+/, $2))
                {
                    printLOG("RD_OS_HOSTS", "$.,'$1','$_'");
                }
            }
            elsif($_ ne '' and $_ ne '#')
            {
                printLOG("osHosts", "Unknown Host Line", 'L');
            }
        }

        # Close Hosts File
        close HOSTF;
    }
    else{
        printLOG("Warn", "Cannot Read [$fNam], Reason [$!]");
        printLOG("STATUS", "RD_OS_HOSTS|Cannot Read [$fNam], Reason [$!]");
    }


    # Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_HOSTS|COMPLETED");
    printLOG("osHosts", "Complete OS Hosts Collection");
}

1;
