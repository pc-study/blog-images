#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 26/09/16 | Add 3rd Condition in Windows Memory Collection         ##
##         | 31/10/16 | Add Large Page Collection for Linux                    ##
##         | 01/11/16 | Add Large Page Advisor for Linux                       ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osMemory;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osMemory", "Begin Memory Collection");

    my $memAll    = 0;
    my $memUsed   = 0;
    my $memFree   = 0;
    my $LPSize    = 0;
    my $LPCount   = 0;
    my $LPAdvisor = 0;
    if($gENV{'OS_TYPE'} eq 'linux')
    {
        printLOG("osMemory", "Read LINUX memory statistics", 'L');

        # Get Large Page Settings
        printLOG("osMemory", "================= [ /proc/meminfo ] =================", 'L');
        my $LPFree = 0;
        my $LPRsvd = 0;
        if (open MEMINFOF, "<:encoding($gENV{'OS_CHARSET'})", '/proc/meminfo')
        {
            while(<MEMINFOF>)
            {
                s/\r|\n//g;  # chomp;

                printLOG("osMemory", $_, 'L');
                # HugePages_Total:   40972
                # HugePages_Free:     9101
                # HugePages_Rsvd:     1410
                # HugePages_Surp:        0
                # Hugepagesize:       2048 kB
                if (m/HugePages_Total[\s:]+(\d+)/i)
                {
                    $LPCount = $1;
                }
                elsif (m/HugePages_Free[\s:]+(\d+)/i)
                {
                    $LPFree = $1;
                }
                elsif (m/HugePages_Rsvd[\s:]+(\d+)/i)
                {
                    $LPRsvd = $1;
                }
                elsif (m/Hugepagesize[\s:]+(\d+)\s+KB/i)
                {
                    $LPSize = $1 / 1024;
                    $LPSize = roundNum($LPSize, 0);
                }
                elsif (m/Hugepagesize[\s:]+(\d+)\s+MB/i)
                {
                    $LPSize = $1;
                }
            }
        }
        else{
            printLOG("Warn", "Cannot Read [/proc/meminfo], Reason [$!]");
            printLOG("STATUS", "RD_OS_MEMSTAT|Cannot Read [/proc/meminfo], Reason [$!]");
        }
        printLOG("osMemory", "=====================================================", 'L');

        # Get Memory Free Statistics
        foreach (execOS('free -m', 'ARRAY'))
        {
            #              total       used       free     shared    buffers     cached
            # Mem:       8058056    7903824     154232          0     284464    6583992
            # -/+ buffers/cache:    1035368    7022688

            if (m@buffers/cache[:\s]+(\d+)@i)
            {
                $memUsed = $1;
                printLOG("osMemory", "Get Memory Used [$memUsed]", 'L');
            }
            elsif (m@\AMem[:\s]+(\d+)@i)
            {
                $memAll  = $1;
                printLOG("osMemory", "Get Memory All [$memAll]", 'L');
            }
        }

        # Get Memory Segment Statistics
        foreach (execOS('ipcs -m', 'ARRAY'))
        {
            # ------ Shared Memory Segments --------
            # key        shmid      owner      perms      bytes      nattch     status
            # 0x00000000 32768      oracle     640        33554432   41
            # 0x00000000 65537      oracle     640        3690987520 41
            # 0xbf9f43f8 98306      oracle     640        2097152    41
            # 0x00000000 983044     oracle     640        608174080  85

            my @items = split(/\s+/);
            if (defined $items[4] and $items[4] =~ m/\A\d+\z/)
            {
                printLOG("osMemory", "Get IPCS Bytes [$items[4]]", 'L');
                $memUsed += roundNum($items[4] / 1048576, 2);


                # Get Advisor for Large Page
                if($LPSize > 0 and $items[4]/$LPSize/1048576 >= 1)
                {
                    $LPAdvisor += roundNum($items[4]/$LPSize/1048576, 0) + 1;
                }
            }
        }

        # Get Huge Pages
        my $kernelVersion = execOS('uname -r');
        $kernelVersion =~ s/\A(\d+\.\d+).*\z/$1/m;
        if($kernelVersion == '2.2')
        {
            $LPAdvisor = -1;
            printLOG("osMemory", "Kernel Version [2.2], Not Supported", 'L');
        }
        elsif($kernelVersion == '2.4')
        {
            $LPAdvisor = roundNum($LPAdvisor * $LPSize / 1048576, 0);
            printLOG("osMemory", "Get Advisor Huge Pages [$LPAdvisor]");
        }
        elsif($kernelVersion == '2.6' or $kernelVersion == '3.8' or $kernelVersion == '3.10')
        {
            printLOG("osMemory", "Get Advisor Huge Pages [$LPAdvisor]");
        }
        else
        {
            $LPAdvisor = -2;
            printLOG("osMemory", "Unknown Kernel Version [$kernelVersion]", 'L');
        }

        # Remove Huge Page's Used Size from Used Size
        $memUsed = $memUsed - ($LPCount - $LPFree + $LPRsvd) * $LPSize;
        $memFree = $memAll - $memUsed;
    }
    elsif($gENV{'OS_TYPE'} eq 'aix')
    {
        printLOG("osMemory", "Read AIX memory statistics", 'L');
        foreach (execOS('svmon -G -O unit=MB', 'ARRAY'))
        {
            # oracle@hxcrmdb2:/oracle$svmon -G
            #                size       inuse        free         pin     virtual   mmode
            # memory    117964800   117894677       70123     6493864    31136130     Ded
            # pg space    5242880      127360
            #
            #                work        pers        clnt       other
            # pin         2955758           0       40506     3497600
            # in use     31136130           0    86758547
            #
            # PageSize   PoolSize       inuse        pgsp         pin     virtual
            # s    4 KB         -   100353077      127360     4702264    13594530
            # m   64 KB         -     1096350           0      111975     1096350

            if (m/\Amemory\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)/i)
            {
                $memAll  = $1;
                $memUsed = $2;
                $memFree = $3;
            }
        }
    }
    elsif($gENV{'OS_TYPE'} eq 'solaris')
    {
        printLOG("osMemory", "Read SUNOS memory statistics", 'L');
        # Get Memory Size
        foreach (execOS('prtconf', 'ARRAY'))
        {
            if (m/Memory\ssize[^\d]+(\d+)\s+G/i)
            {
                $memAll = $1 * 1024;
            }
            elsif (m/Memory\ssize[^\d]+(\d+)/i)
            {
                $memAll = $1;
            }
        }
        # Get Memory Free
        foreach (execOS('vmstat', 'ARRAY'))
        {
            # kthr      memory            page            disk          faults      cpu
            # r b w     swap     free re mf pi po fr de sr s2 sd sd --   in   sy   cs us sy id
            # 0 0 0 54425312 25009768 19 79 39 0 0 0  1 -0 -0  7  0  455  306  226  0  0 100

            if (m/\A\s*\d+\s+\d+\s+\d+\s+\d+\s+(\d+)/i)
            {
                $memFree = $1 / 1024;
                $memFree = roundNum($memFree, 2);
            }
        }
        # Calculate Memory Used
        $memUsed = $memAll - $memFree;
    }
    elsif($gENV{'OS_TYPE'} eq 'hpux')
    {
        printLOG("osMemory", "Read HP-UX memory statistics", 'L');
        foreach (execOS('swapinfo', 'ARRAY'))
        {
            #              Kb      Kb      Kb   PCT  START/      Kb
            # TYPE      AVAIL    USED    FREE  USED   LIMIT RESERVE  PRI  NAME
            # memory  9548580 8152156 1396424   85%

            if (m/\Amemory\s+(\d+)\s+(\d+)\s+(\d+)/i)
            {
                $memAll  = $1 / 1024;
                $memUsed = $2 / 1024;
                $memFree = $3 / 1024;
                $memAll  = roundNum($memAll, 2);
                $memUsed = roundNum($memUsed, 2);
                $memFree = roundNum($memFree, 2);
            }
        }
    }
    elsif($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        # Get Physical Memory Size
        $memAll = execOS('WMIC COMPUTERSYSTEM GET TOTALPHYSICALMEMORY /FORMAT:LIST 2>nul');
        if($memAll eq '')
        {
            $memAll = execOS('WMIC MEMLOGICAL GET TotalPhysicalMemory /Format:List 2>nul');
            # TotalPhysicalMemory=2096536
        }
        if($memAll eq '')
        {
            $memAll = execOS('WMIC OS GET TotalVisibleMemorySize /FORMAT:LIST 2>nul');
        }
        $memAll =~ s/[^\d]+//g;
        $memAll = $memAll/1024;
        $memAll = roundNum($memAll, 2);

        # Get Physical Memory Free Size
        $memFree = execOS('WMIC OS GET FreePhysicalMemory /Format:List 2>nul');
        # FreePhysicalMemory=2096536
        $memFree =~ s/[^\d]+//g;
        $memFree = $memFree/1024;
        $memFree = roundNum($memFree, 2);

        # Calculate Physical Used
        $memUsed = $memAll - $memFree;

        # Get Large Pages
        # HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE\KEY_OraDb10g_home1
        my $oraKey = execOS('reg query HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE | find "KEY_O"');
        $LPCount   = execOS('reg query HKEY_LOCAL_MACHINE\SOFTWARE\ORACLE\KEY_OraDb10g_home1 | find "ORA_LPSIZE"') + 0;
    }
    else{
        printLOG("Warn", "Unknown OS Type [$gENV{'OS_TYPE'}]");
    }

    printLOG("RD_OS_MEMSTAT", "$memAll,$memUsed,$memFree,$LPSize,$LPCount,$LPAdvisor");

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_MEMSTAT|COMPLETED");
    printLOG("osMemory", "Complete Memory Collection");
}

1;
