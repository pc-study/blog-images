#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 12/09/16 | Add Quota Conversion to Message Contents               ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 27/03/17 | Tuning HPUX/Solaris Func, Exactly for Position         ##
## 2.1.0   | 29/03/17 | Version [2.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osError;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osError", "Begin OS Error Collection");

    if($^O eq 'aix')
    {
        # Convert OS Error Begin Time
        # 2012-12-12 12:12:12
        my $erBT = substr($gENV{'OSERR_TIME'}, 5, 2).substr($gENV{'OSERR_TIME'}, 8, 2).substr($gENV{'OSERR_TIME'}, 11, 2).substr($gENV{'OSERR_TIME'}, 14, 2).substr($gENV{'OSERR_TIME'}, 2, 2);
        printLOG("osError", "Convert OS Erro Time from [$gENV{'OSERR_TIME'}] to [$erBT]", 'L');
        my ($curS, $curMi, $curH, $curD, $curM, $curY) = (localtime)[0..5];
        $curM ++;
        $curY += 1900;
        ($curY, $curM, $curD, $curH, $curMi, $curS) = timeAdd($curY, $curM, $curD, $curH, $curMi, $curS, 3600);
        my $curMontoSec = sprintf("%02d%02d%02d%02d%02d", $curM, $curD, $curH, $curMi, $curS);

        # Get All Error
        printLOG("osError", "Read AIX Error Log from [errpt -s '$erBT']");
        my @errA = execOS("errpt -s '$erBT'", 'ARRAY');
        printLOG("osError", "Get Error Log from [errpt -s '$erBT']", 'L');

        if(scalar @errA and defined $errA[1])
        {
            shift @errA;       # Remove Header
            my $errC = $#errA;
            printLOG("osError", "Found [".($errC + 1)."] OS errors", 'L');

            # Init to Get First Error
            $_ = shift @errA;
            s/\r|\n//g;  # chomp;
            my @errL  = split(/\s+/);
            my $iDent = shift @errL;
            my $timS  = shift @errL;
            my $type  = shift @errL;
            my $class = shift @errL;
            my $resN  = shift @errL;
            my $desc  = join(' ', @errL);
            my $erTM  = substr($timS, 0, 2);
            my $erTD  = substr($timS, 2, 2);
            my $erTH  = substr($timS, 4, 2);
            my $erTi  = substr($timS, 6, 2);
            my $erTS  = substr($timS, 8, 2);
            if("$erTM$erTD$erTH$erTi$erTS" > $curMontoSec)
            {
                $timS = ($curY - 1)."-$erTM-$erTD $erTH:$erTi:$erTS";
            }
            else
            {
                $timS = "$curY-$erTM-$erTD $erTH:$erTi:$erTS";
            }
            push(@errA, "TO_DATE('$timS','YYYY-MM-DD HH24:MI:SS'),'$iDent','$type','$class','$resN','$desc'");
            my $preE = "$iDent,$type,$class,$resN,$desc";
            my $preC = 1;

            # Loop to Remove Duplicate Error
            for(my $x = 0; $x < $errC; $x ++)
            {
                $_ = shift @errA;
                s/\r|\n//g;  # chomp;
                @errL  = split(/\s+/);
                $iDent = shift @errL;
                $timS  = shift @errL;
                $type  = shift @errL;
                $class = shift @errL;
                $resN  = shift @errL;
                $desc  = join(' ', @errL);
                $desc =~ s/'/''/g;               # Convert Single Quota
                $erTM  = substr($timS, 0, 2);
                $erTD  = substr($timS, 2, 2);
                $erTH  = substr($timS, 4, 2);
                $erTi  = substr($timS, 6, 2);
                $erTS  = substr($timS, 8, 2);
                if($erTM > $curM) {$timS  = ($curY - 1)."-$erTM-$erTD $erTH:$erTi:$erTS";}
                else              {$timS  = $curY."-$erTM-$erTD $erTH:$erTi:$erTS";}

                if($preE eq "$iDent,$type,$class,$resN,$desc")
                {
                    $preC ++;
                }
                else
                {
                    $errA[$#errA] = $errA[$#errA].",$preC";
                    push(@errA, "TO_DATE('$timS','YYYY-MM-DD HH24:MI:SS'),'$iDent','$type','$class','$resN','$desc'");
                    $preE = "$iDent,$type,$class,$resN,$desc";
                    $preC = 1;
                }
            }

            # Add Last Error Count
            $errA[$#errA] = $errA[$#errA].",$preC";

            # Loop to Write All Errors
            for(my $x = 0; $x < $#errA; $x ++)
            {
                printLOG("RD_OS_ERR", "$x,$errA[$x]");
            }
        }
        else
        {
            printLOG("osError", "Found [0] OS errors");
        }
    }
    elsif($^O eq 'solaris')
    {
        printLOG("osError", "Read Solaris Error Log from [/var/adm/messages]");
        &cltERLog('/var/adm/messages');
    }
    elsif($^O eq 'hpux')
    {
        printLOG("osError", "Read HPUX Error Log from [/var/adm/syslog/syslog.log]");
        &cltERLog('/var/adm/syslog/syslog.log');
    }
    elsif($^O eq 'linux')
    {
        printLOG("Warn", "No Permision to Read Linux Error Log");
        printLOG("STATUS", "RD_OS_ERR|No Permision to Read Linux Error Log");
    }
    else
    {
        printLOG("Warn", "Unhandler OS Type [$^O] for OS Error Collection");
        printLOG("STATUS", "RD_OS_ERR|Unhandler OS Type [$^O] for Error Collection");
    }

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_ERR|COMPLETED");
    printLOG("osError", "Complete OS Error Collection");
}


################################################################################
##                                                                            ##
## cltERLog : Collect OS Error Logs                                           ##
##                                                                            ##
################################################################################
sub cltERLog
{
    my $fNam = shift;

    if(open ERRF, "<:encoding($gENV{'OS_CHARSET'})", $fNam)
    {
        printLOG("cltERLog", "Openned Logfile [$fNam] for Read", 'L');
        my $fSiz  = (stat ERRF)[7];
        printLOG("RD_OS_FILESIZE", "'OS_ERROR','$fNam',$fSiz");

        # Get Current Year/Month
        my ($curS, $curMi, $curH, $curD, $curM, $curY) = (localtime)[0..5];
        $curM ++;
        $curY += 1900;
        printLOG("cltERLog", "Current date [$curY, $curM, $curD, $curH, $curMi, $curS]");
        ($curY, $curM, $curD, $curH, $curMi, $curS) = timeAdd($curY, $curM, $curD, $curH, $curMi, $curS, 3600);
        my $curMontoSec = sprintf("%02d%02d%02d%02d%02d", $curM, $curD, $curH, $curMi, $curS);
        printLOG("cltERLog", "Month to Second [$curMontoSec]");

        # Try to Get Error Begining
        my $erPOS   = 0;
        my $preTime = '';
        seek(ERRF, 0, 0);
        while (<ERRF>)
        {
            s/\r|\n//g;  # chomp;
            # printLOG("cltERLog", "Read: [$_]", 'L');
            if(m/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d+)\s+(\d+)[\:\：](\d+)[\:\：](\d+)\s+(\d{4})?(.+)\z/i)
            {
                # Solaris:
                # Apr 24 20：31：05 nmssa inetd[140]： /usr/dt/bin/rpc.ttdbserverd： Segmentation Fault - core dumped
                # Apr 24 11：27：23 unix.secu.com ftpd[7264]： 163 (bogus) LOGIN FAILED [from 11.22.33.49]
                # HP-UX:
                # Jun 18 22:20:49 gsioms02  above message repeats 2 times
                # Jun 18 22:20:49 gsioms02 vmunix: 64000/0xfa00 esvroot
                # Jun 18 22:20:49 gsioms02 vmunix: Kernel EVM initialized
                # Jun 18 22:20:49 gsioms02 vmunix: 64000/0x0 mass_storage
                # Jun 18 22:20:49 gsioms02 vmunix: 64000/0x0/0x0 usb_ms_scsi
                # Jun 18 22:20:49 gsioms02 vmunix: sec_init(): kernel RPC authentication/security initialization.

                # Parse Time
                my $erTM = '01';
                if   ($1 eq 'Feb') {$erTM = '02'}
                elsif($1 eq 'Mar') {$erTM = '03'}
                elsif($1 eq 'Apr') {$erTM = '04'}
                elsif($1 eq 'May') {$erTM = '05'}
                elsif($1 eq 'Jun') {$erTM = '06'}
                elsif($1 eq 'Jul') {$erTM = '07'}
                elsif($1 eq 'Aug') {$erTM = '08'}
                elsif($1 eq 'Sep') {$erTM = '09'}
                elsif($1 eq 'Oct') {$erTM = '10'}
                elsif($1 eq 'Nov') {$erTM = '11'}
                elsif($1 eq 'Dec') {$erTM = '12'}
                my $erTD = $2;
                my $erTH = $3;
                my $erTi = $4;
                my $erTS = $5;
                if(length($erTD) == 1)
                {
                    $erTD = '0'.$erTD;
                }
                if(length($erTH) == 1)
                {
                    $erTH = '0'.$erTH;
                }
                if(length($erTi) == 1)
                {
                    $erTi = '0'.$erTi;
                }
                if(length($erTS) == 1)
                {
                    $erTS = '0'.$erTS;
                }
                my $erMsg = $7;

                # Make Time String
                my $timS = '';
                if(defined $6 and $6 ne '')
                {
                    $timS = "$6-$erTM-$erTD $erTH:$erTi:$erTS";
                }
                else
                {
                    if("$erTM$erTD$erTH$erTi$erTS" > $curMontoSec)
                    {
                        $timS = ($curY - 1)."-$erTM-$erTD $erTH:$erTi:$erTS";
                    }
                    else
                    {
                        $timS = "$curY-$erTM-$erTD $erTH:$erTi:$erTS";
                    }
                }

                # Reset Error Position when Pre time bigger than current time:
                # Just Like: 2017-03-28 -> 2017-02-14
                # This maybe time format error, because log message in HP/Solaris does not has Year field.
                if($preTime gt $timS)
                {
                    $erPOS = 0;
                    printLOG("cltERLog", "POINT: Reset Error Position due to Pre [$preTime] is bigger than Current [$timS] at line [$.]", 'L');
                }
                $preTime = timeMinus($timS, 600);

                # Filter by OS Error Time
                if($timS ge $gENV{'OSERR_TIME'} and $erPOS == 0)
                {
                    $erPOS = tell ERRF;
                    printLOG("cltERLog", "POINT: Found First Read Position [$erPOS] [$timS] at line [$.]", 'L');
                }
                elsif($timS lt $gENV{'OSERR_TIME'} and $erPOS == 1)
                {
                    $erPOS = 0;
                    printLOG("cltERLog", "POINT: Reset Error Position due to Time [$timS] less than Expected at line [$.]", 'L');
                }
            }
        }
        my $rdSiz = $fSiz - $erPOS;
        if($rdSiz > 1048576)
        {
            $rdSiz = $rdSiz / 1048576;
            $rdSiz = roundNum($rdSiz, 2)." MB";
        }
        elsif($rdSiz > 1024)
        {
            $rdSiz = $rdSiz / 1024;
            $rdSiz = roundNum($rdSiz, 2)." KB";
        }
        else
        {
            $rdSiz = $rdSiz." B";
        }
        printLOG("cltERLog", "Read Error Message from [$erPOS], Size is [$rdSiz]");


        # Get Needed Error Messages
        my $erCNT   = 1;        # Read Error for Current
        my $erMAX   = 1000;     # Max Read Error Allowd in Message Format
        seek(ERRF, $erPOS, 0);
        while (<ERRF>)
        {
            s/\r|\n//g;  # chomp;
            if(m/(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+(\d+)\s+(\d+)[\:\：](\d+)[\:\：](\d+)\s+(\d{4})?(.+)\z/i)
            {
                # Parse Time
                my $erTM = '01';
                if   ($1 eq 'Feb') {$erTM = '02'}
                elsif($1 eq 'Mar') {$erTM = '03'}
                elsif($1 eq 'Apr') {$erTM = '04'}
                elsif($1 eq 'May') {$erTM = '05'}
                elsif($1 eq 'Jun') {$erTM = '06'}
                elsif($1 eq 'Jul') {$erTM = '07'}
                elsif($1 eq 'Aug') {$erTM = '08'}
                elsif($1 eq 'Sep') {$erTM = '09'}
                elsif($1 eq 'Oct') {$erTM = '10'}
                elsif($1 eq 'Nov') {$erTM = '11'}
                elsif($1 eq 'Dec') {$erTM = '12'}
                my $erTD = $2;
                my $erTH = $3;
                my $erTi = $4;
                my $erTS = $5;
                if(length($erTD) == 1)
                {
                    $erTD = '0'.$erTD;
                }
                if(length($erTH) == 1)
                {
                    $erTH = '0'.$erTH;
                }
                if(length($erTi) == 1)
                {
                    $erTi = '0'.$erTi;
                }
                if(length($erTS) == 1)
                {
                    $erTS = '0'.$erTS;
                }
                my $erMsg = $7;

                # Make Time String
                my $timS = '';
                if(defined $6 and $6 ne '')
                {
                    $timS = "$6-$erTM-$erTD $erTH:$erTi:$erTS";
                }
                else
                {
                    if("$erTM$erTD$erTH$erTi$erTS" > $curMontoSec)
                    {
                        $timS = ($curY - 1)."-$erTM-$erTD $erTH:$erTi:$erTS";
                    }
                    else
                    {
                        $timS = $curY."-$erTM-$erTD $erTH:$erTi:$erTS";
                    }
                }

                my $erHost = '';
                my $erProg = '';
                if($erMsg =~ /\A\s*([^\s]+)\s+([^\:\：]+)[\:\：]\s*(.*)\z/)
                {
                    # HP-UX:
                    # gsioms02 vmunix: sec_init(): kernel RPC authentication/security initialization.
                    # Solaris:
                    # jyjfdb1 scsi: [ID 107833 kern.warning] WARNING: /pci@700/pci@2/pci@0/pci@3/pci@0/pci@2/SUNW,qlc@0/fp@0,0/ssd@w5006048452a85d33,0 (ssd0):
                    # jyjfdb1     Corrupt label; wrong magic number
                    # jyjfdb1 fctl: [ID 517869 kern.warning] WARNING: fp(8)::N_x Port with D_ID=130f00, PWWN=500507630f672321 disappeared from fabric
                    # jyjfdb1 scsi: [ID 243001 kern.info] /pci@600/pci@1/pci@0/pci@4/pci@0/pci@2/SUNW,qlc@0,1/fp@0,0 (fcp8):
                    # jyjfdb1     offlining lun=0 (trace=0), target=130e00 (trace=2800004)
                    # jyjfdb1 scsi: [ID 243001 kern.info] /pci@600/pci@1/pci@0/pci@4/pci@0/pci@2/SUNW,qlc@0,1/fp@0,0 (fcp8):
                    # jyjfdb1     offlining lun=0 (trace=0), target=130d00 (trace=2800004)

                    $erHost = $1;
                    $erProg = $2;
                    $erMsg  = $3;
                }

                $erMsg =~ s/'/''/g;
                printLOG("RD_OS_ERR", "$.,TO_DATE('$timS','YYYY-MM-DD HH24:MI:SS'),'$erHost','','','$erProg','$erMsg',NULL");
            }
            else
            {
                # unknow os log : Tue Feb 17 12:30:36 2015
                printLOG("Warn", "Unknow OS Log: $_");
                $erCNT ++;
                if($erCNT > $erMAX)
                {
                    last;
                }
            }
        }

        # Close Error File
        close ERRF;

        # Give Error Tips
        if($erCNT > $erMAX)
        {
            printLOG("Warn", "Formatted Error");
            printLOG("STATUS", "RD_OS_ERR|Formatted Error");
        }
    }
    else
    {
        printLOG("Warn", "Cannot Read [$fNam], Reason [$!]");
        printLOG("STATUS", "RD_OS_ERR|Cannot Read [$fNam], Reason [$!]");
    }
}

1;
