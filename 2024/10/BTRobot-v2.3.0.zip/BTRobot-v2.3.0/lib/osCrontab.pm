#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 12/09/16 | Modify Crontab Collection, Convert Quota               ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osCrontab;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osCrontab", "Begin OS Crontab Collection");

    if($gENV{'OS_TYPE'} ne 'MSWin32')
    {
        foreach (execOS('crontab -l 2>/dev/null', 'ARRAY'))
        {
            s/\A\s+|#.+|\s+\z//g;
            # 0 1 * * * /home/oracle/admin/delARCH.pl 1>>/home/oracle/admin/delARCH.log 2>&1
            # 0 0 * * * /home/oracle/admin/uploadManager.pl 1>>/home/oracle/admin/uploadManager.log 2>&1
            if (m/\A([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+([^\s]+)\s+(.+)\z/)
            {
                my $cronPar_1 = $1;
                my $cronPar_2 = $2;
                my $cronPar_3 = $3;
                my $cronPar_4 = $4;
                my $cronPar_5 = $5;
                my $cronPar_6 = $6;
                $cronPar_6 =~ s/'/''/g;
                printLOG("RD_OS_CRONTAB", "'$cronPar_1','$cronPar_2','$cronPar_3','$cronPar_4','$cronPar_5','$cronPar_6'");
            }
            elsif($_ ne '')
            {
                printLOG("Warn", "Unknow Line [$_]");
            }
        }
        printLOG("STATUS", "RD_OS_CRONTAB|COMPLETED");
    }
    else
    {
        printLOG("STATUS", "RD_OS_CRONTAB|Crontab not available on Windows");
    }

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("osCrontab", "Complete OS Crontab Collection");
}

1;
