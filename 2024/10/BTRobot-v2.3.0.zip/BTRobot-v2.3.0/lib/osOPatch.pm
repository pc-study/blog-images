#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osOPatch;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    printLOG("osOPatch", "Begin Oracle Patch Collection");

    # Collect [opatch lsinventory -all]
    my $cmdNum = 1;
    foreach (execOS("$gENV{'ORACLE_HOME'}/OPatch/opatch lsinventory -all", 'ARRAY'))
    {
        s/\A\s+|\r|\n|\s+\z//g;
        if($_ ne '')
        {
            printLOG('RD_OS_RAW', "'OPATCH',$cmdNum,'$_'");
        }
        $cmdNum ++;
    }

    # Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_RAW|COMPLETED");
    printLOG("osOPatch", "Complete Oracle Patch Collection");
}


1;

