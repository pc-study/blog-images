#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 12/09/16 | Modify SQL Text Cutter to [20000]                      ##
##         | 19/09/16 | Move SQL Statement to Config File                      ##
##         | 19/09/16 | Package Control Data Direct Get from Variable          ##
##         | 19/09/16 | Open Result File by Class in Node/DG                   ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 29/09/16 | Shield some internal used variable in result           ##
##         | 20/10/16 | Cut Batch Status Message into 3000 chars               ##
##         | 02/11/16 | Add Global Error when Collection not Complete          ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 16/11/16 | Add State When Remote Node in Collection               ##
## 1.1.1   | 21/11/16 | Version [1.1.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 09/12/16 | Top SQL first use SQLID with SQL_Text and SQL_Plan     ##
## 1.1.3   | 20/12/16 | Version [1.1.3] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 26/12/16 | Compatiable with No StrictHostKeyChecking in SSH       ##
##         | 29/12/16 | Add Detail Help Messages (include usage and config)    ##
##         | 03/01/17 | Fix Bug when Running in PASSWORD MODE (Hang)           ##
##         | 03/01/17 | Modify SQL Text Cutter to [2000]                       ##
##         | 10/01/17 | Add Option [-B] to Specify Busy Section by Hour        ##
##         | 11/01/17 | Fix Bug when Option [-r] does not work                 ##
## 1.1.4   | 12/01/17 | Version [1.1.4] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 13/01/17 | Fix Bug: Remote Not Automatic Collectted               ##
## 1.1.5   | 13/01/17 | Version [1.1.5] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 16/01/17 | Fix Bug: Charactset Error in AWR Report                ##
##         | 17/01/17 | Fix Bug: Option [-T] Failed                            ##
##         | 10/02/17 | Fix Bug: Option [-t] Failed                            ##
##         | 14/02/17 | Add Quiet Mode, Show Less Logs in Quiet Mode           ##
##         | 21/02/17 | Fix Bug: Remote not Collected due to ORACLE_HOME       ##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 08/03/17 | Automatic Set ORACLE_SID in Remote Collection          ##
##         | 14/03/17 | Hide Warnings in Remote CMD and File Check             ##
##         | 16/03/17 | Host IP Address use first in [hosts] file              ##
## 2.1.0   | 29/03/17 | Version [2.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 30/03/17 | Automatic set LIBRARY and PERL5LIB env.                ##
##         | 04/05/17 | Add Segment Stat Collection                            ##
## 2.2.0   | 05/05/17 | Version [2.2.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 10/05/17 | Fix Remote [osInstance] Collection Error               ##
## 2.2.1   | 12/05/17 | Version [2.2.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 22/11/17 | Bug fix: DG lost when \n found in log_archive_dest     ##
## 2.2.3   | 29/11/17 | Version [2.2.3] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 17/12/18 | Set OS default encoding in MSWin32 to GBK              ##
##         | 19/12/18 | Add SCN compat version collection                      ##
## 2.2.6   | 19/12/18 | Version Released                                       ##
##---------|----------|--------------------------------------------------------##
##         | 19/03/19 | Remove logfile in /tmp when execute remotely           ## 
## 2.2.7   | 19/03/19 | Version Released                                       ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use PerlIO::encoding;
use Encode;
use File::Copy;
use Getopt::Std;
use Sys::Hostname;
use Cwd;
use utf8;
use BTTools qw(logADM printLOG lPad rPad getProc execOS decodeData openSocket closeSocket addStatus sendFile roundNum showCommand openResult writeTime getDirFree selfMonitor timeAdd timeMinus);
use DBTools;
use BTConfig;


# Global Parameters
# ------------------------------------------------------------------------------
our %osInst;
our %osPswd;
our %dbAlert;
our %asmAlert;


################################################################################
##                                                                            ##
## Signal Capture: Capture Some Signal by %SIG Var                            ##
##                                                                            ##
################################################################################
# Define Error Operations
$SIG{__DIE__}  = sub
{
    my $msgALL = join("\n", @_);
    foreach my $errMSG (split(/[\r\n]+/, $msgALL))
    {
        $gENV{'GLOBAL_ERROR'} = "$gENV{'GLOBAL_ERROR'} $errMSG";
        printLOG('Signal', "Main Error: [$errMSG]");
    }

    # do Post Process
    &postProcess;

    # Exit Program
    exit 1;
};

# Define Warn Operations
$SIG{__WARN__}  = sub
{
    my $msgALL = join("\n", @_);
    foreach my $errMSG (split(/[\r\n]+/, $msgALL))
    {
        printLOG('Signal', "Main Warn: [$errMSG]");
    }
};

$SIG{'INT'}  = sub
{
    print "\r";

    if($gENV{'SKIP_STEP'} == 1)
    {
        printLOG('Signal', "Skip Current Collection Step");

        # re-Set DG Collection Tips
        $gENV{'SKIP_STEP'} = 0;
    }
    else
    {
        $gENV{'GLOBAL_ERROR'} = "Main Process Interruptted by User";
        printLOG('Signal', "Main Process Interruptted by User");

        # do Post Process
        &postProcess;

        # Exit Program
        exit 1;
    }
};


################################################################################
##                                                                            ##
## parseArgs: Parse Arguments                                                 ##
##                                                                            ##
################################################################################
sub parseArgs()
{
    printLOG('parseArgs', 'Parse Arguments');
    # my %args = &getArgs;
    my %args;
    getopts('B:c:e:hi:L:M:o:p:Qr:R:s:St:T:u:U:vw:z', \%args);


    if(exists $args{'h'})
    {
        my $clearScreen = 'clear 2>/dev/null';
        $clearScreen = 'cls 2>nul' if ($^O eq 'MSWin32');

        print "\n";
        # system($clearScreen);
        # printLOG('parseArgs', '[1] Introduction');
        # printLOG('parseArgs', '=======================================================================================');
        # printLOG('parseArgs', '    Bethune Data Collect Tool (BTRobot) is coding with perl programming language,');
        # printLOG('parseArgs', '    It can be executed with system perl (Linux/Unix) or oracle perl (Windows).');
        # printLOG('parseArgs', '    During the period of collection, following three methods may be used:');
        # printLOG('parseArgs', '      a. Call system command to get system related data');
        # printLOG('parseArgs', '      b. Read system file to get configuration and logs');
        # printLOG('parseArgs', '      c. Use oracle DBI library to query database');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '    For BTRobot, there are three directories in it:');
        # printLOG('parseArgs', '      a. '.rPad($gFName{'CONFIG_DIR'}, 11).': Directory for configuration files');
        # printLOG('parseArgs', '      b. '.rPad($gFName{'DATA_DIR'}, 11).': Directory for result file, empty for a new BTRobot');
        # printLOG('parseArgs', '      c. '.rPad($gFName{'LIB_DIR'}, 11).': Directory for library and modules');
        # printLOG('parseArgs', '      d. '.rPad($gFName{'MODULE_DIR'}, 11).': Directory for External module used in batch mode');
        # printLOG('parseArgs', '      e. '.rPad('runMe.pl', 11).": Startup script");
        # printLOG('parseArgs', '      f. '.rPad('ReadMe_CN.txt', 11).": BTRobot Help Document in Chinase");
        # printLOG('parseArgs', '      g. '.rPad('ReadMe_EN.txt', 11).": BTRobot Help Document in English\n");

        # printLOG('parseArgs', '[Q] for quit, enter for next help page: ', 'N');
        # my $uInput = uc(<>);
        # chomp $uInput;
        # $uInput =~ s/\A\s+|\s+\z//g;
        # print "\n";
        # exit 0 if ($uInput eq 'Q');
        # system($clearScreen);

        printLOG('parseArgs', '[2] Options');
        printLOG('parseArgs', '=======================================================================================');
        printLOG('parseArgs', '    Opt  Message                                    Default');
        printLOG('parseArgs', '    ---- ------------------------------------------ ------------');
        # printLOG('parseArgs', '     -A  Batch Upload, Specify Login User           '.$gENV{'UPLOAD_USER'});
        printLOG('parseArgs', '     -B  Specify AWR Busy Section by hour(0 to 23)  0-23');
        printLOG('parseArgs', '         Format: 8-18 or 9,10,15,16 or 9-12,14-18');
        printLOG('parseArgs', '     -c  Specify CharacterSet/Encoding');
        printLOG('parseArgs', '         Format: O=GBK,A=GBK,L=GBK');
        printLOG('parseArgs', '                 O is database charactSet');
        printLOG('parseArgs', '                 A is alert logfile charactSet');
        printLOG('parseArgs', '                 L is listener logfile charactSet');
        printLOG('parseArgs', '     -e  Specify OS Error Collect Time in Days      '.$gENV{'OSERR_TIME'});
        printLOG('parseArgs', '     -h  Show Robot Introduction');
        printLOG('parseArgs', '     -i  Specify ASM SID                            '.$gENV{'ASM_SID'});
        printLOG('parseArgs', '     -L  Specify Log History Limit                  '.$gENV{'LOG_LIMIT'});
        printLOG('parseArgs', '     -M  Specify Multi-Server Config File in [conf] '.$gFName{'SERVER_CONFIG'});
        printLOG('parseArgs', '     -o  Specify ASM Home                           '.$gENV{'ASM_HOME'});
        printLOG('parseArgs', '     -p  Specify Listening Port on Primary          '.$gENV{'LISTEN_PORT'});
        printLOG('parseArgs', '     -Q  Quit Mode, Always used in [-M] Mode');
        printLOG('parseArgs', '     -r  Specify AWR Data Collect Time in Days      '.$gENV{'AWR_TIME'});
        printLOG('parseArgs', '     -R  Specify Top AWR Report Number              '.$gENV{'TOP_AWR'});
        printLOG('parseArgs', '     -s  Specify Top Segment Limit                  '.$gENV{'TOP_SEGMENTS'});
        printLOG('parseArgs', '     -S  do not Collect DG Data');
        printLOG('parseArgs', '     -t  Specify Alert Collect Time in Days         '.$gENV{'ALERT_TIME'});
        printLOG('parseArgs', '     -T  Specify Listener Collect Time in Days      '.$gENV{'LSNR_TIME'});
        printLOG('parseArgs', '     -u  Specify Oracle Logon Infomation            '.$gENV{'DB_USER'}.'/'.$gENV{'DB_PSWD'});
        printLOG('parseArgs', '     -U  Specify ASM Logon Infomation               '.$gENV{'ASM_USER'}.'/'.$gENV{'ASM_PSWD'});
        printLOG('parseArgs', '     -v  Show Robot Version');
        printLOG('parseArgs', '     -w  Specify Top Wait Limit                     '.$gENV{'TOP_WAITS'});
        printLOG('parseArgs', "     -z  do not zip Result Directory\n");
        printLOG('parseArgs', "more information in [ ReadMe_EN.txt ] and [ ReadMe_CN.txt ]");

        # printLOG('parseArgs', '[Q] for quit, enter for next help page: ', 'N');
        # $uInput = uc(<>);
        # chomp $uInput;
        # $uInput =~ s/\A\s+|\s+\z//g;
        # print "\n";
        # exit 0 if ($uInput eq 'Q');
        # system($clearScreen);

        # printLOG('parseArgs', '[3] Usage');
        # printLOG('parseArgs', '=======================================================================================');
        # printLOG('parseArgs', '--> Firstly, we strongly recommend reading this user help');
        # printLOG('parseArgs', '    * Note: directory may different in your server');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '      cd /home/oracle/BTRobot_v'.$gENV{'SCRIPT_VERSION'});
        # printLOG('parseArgs', '      perl runMe.pl -h');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> For Windows');
        # printLOG('parseArgs', '    * Note: location for perl.exe may different in your server');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '      SET ORACLE_HOME=C:\oracle\product\10.2.0\db_1');
        # printLOG('parseArgs', '      SET ORACLE_SID=WINDB');
        # printLOG('parseArgs', '      SET PATH=%ORACLE_HOME%\bin;%PATH%         # Add oracle bin');
        # printLOG('parseArgs', '      SET PATH=%ORACLE_HOME%\perl\bin;%PATH%    # Add oracle perl bin');
        # printLOG('parseArgs', '      where perl             # Check whether oracle perl is existed');
        # printLOG('parseArgs', '      sqlplus / as sysdba    # Check sys logon is OK, otherwise [-u] option may needed');
        # printLOG('parseArgs', '      cd C:\BTRobot_v'.$gENV{'SCRIPT_VERSION'});
        # printLOG('parseArgs', '      perl runMe.pl');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> For Linux/Unix');
        # printLOG('parseArgs', '    * Note: directory may different in your server');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '      which perl             # Check whether system perl is existed');
        # printLOG('parseArgs', '      sqlplus / as sysdba    # Check sys logon is OK, otherwise [-u] option may needed');
        # printLOG('parseArgs', '      cd /home/oracle/BTRobot_v'.$gENV{'SCRIPT_VERSION'});
        # printLOG('parseArgs', "      perl runMe.pl");
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> Batch Collection');
        # printLOG('parseArgs', '    * Note: this mode only used in Linux/Unix with SSH enabled');
        # printLOG('parseArgs', '            directory may different in your server');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '      su - root                              # root is needed to install perl module');
        # printLOG('parseArgs', '      which perl                             # Check whether system perl is existed');
        # printLOG('parseArgs', '      cd /home/oracle/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'MODULE_DIR'});
        # printLOG('parseArgs', '      # Install Needed Perl Module');
        # printLOG('parseArgs', '      tar -zxvf IO-Tty-1.12.tar.gz           # Install Perl Module IO-TTY/PTY');
        # printLOG('parseArgs', '      cd IO-Tty-1.12');
        # printLOG('parseArgs', '      perl Makefile.PL');
        # printLOG('parseArgs', '      make');
        # printLOG('parseArgs', '      make test');
        # printLOG('parseArgs', '      make install');
        # printLOG('parseArgs', '      tar -zxvf Expect-1.32.tar.gz           # Install Perl Module Expect');
        # printLOG('parseArgs', '      cd Expect-1.32');
        # printLOG('parseArgs', '      perl Makefile.PL');
        # printLOG('parseArgs', '      make');
        # printLOG('parseArgs', '      make test');
        # printLOG('parseArgs', '      make install');
        # printLOG('parseArgs', '      tar -zxvf Net-SSH-Expect-1.09.tar.gz   # Install Perl Module Net-SSH-Expect');
        # printLOG('parseArgs', '      cd Net-SSH-Expect-1.09');
        # printLOG('parseArgs', '      perl Makefile.PL');
        # printLOG('parseArgs', '      make');
        # printLOG('parseArgs', '      make test');
        # printLOG('parseArgs', '      make install');
        # printLOG('parseArgs', '      tar -zxvf Net-SCP-Expect-0.12.tar.gz   # Install Perl Module Net-SCP-Expect');
        # printLOG('parseArgs', '      cd Net-SCP-Expect-0.12');
        # printLOG('parseArgs', '      perl Makefile.PL');
        # printLOG('parseArgs', '      make');
        # printLOG('parseArgs', '      make test');
        # printLOG('parseArgs', '      make install');
        # printLOG('parseArgs', '      # Write DB Server Configurations, Detail see: '.$gFName{'LIB_DIR'}.'/'.$gFName{'SERVER_CONFIG'});
        # printLOG('parseArgs', "      vi ".$gFName{'CONFIG_DIR'}.'/'.$gFName{'SERVER_CONFIG'});
        # printLOG('parseArgs', '      # Run Collection Script in Batch Mode');
        # printLOG('parseArgs', "      perl runMe.pl -M\n");

        # printLOG('parseArgs', '[Q] for quit, enter for next help page: ', 'N');
        # $uInput = uc(<>);
        # chomp $uInput;
        # $uInput =~ s/\A\s+|\s+\z//g;
        # print "\n";
        # exit 0 if ($uInput eq 'Q');
        # system($clearScreen);

        # printLOG('parseArgs', '[4] Interaction');
        # printLOG('parseArgs', '=======================================================================================');
        # printLOG('parseArgs', '--> a. RAC without user equivalence');
        # printLOG('parseArgs', '    Generally, all nodes in RAC system is configured with user equivalence.');
        # printLOG('parseArgs', '    In this situation, BTRobot can collect all needed data on one node.');
        # printLOG('parseArgs', '    When RAC system without user equivalence configured, following tip shows:');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '       User equivalent is not configured');
        # printLOG('parseArgs', '       You can Choose :');
        # printLOG('parseArgs', '       P: [Password Mode] Use Password to Login Remote and Collect Data');
        # printLOG('parseArgs', '       L: [Listener Mode] You Must Run Command on Remote Manually (it\'s Default)');
        # printLOG('parseArgs', '       ====>');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '    We recommend to use [Listener Mode] to collect remote data');
        # printLOG('parseArgs', '    [Password Mode]: input remote oracle password to collect remote data');
        # printLOG('parseArgs', '    [Listener Mode]: execute command on remote manually to collect remote data');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> b. Waiting Remote Data');
        # printLOG('parseArgs', '    In situation [a], when collecting remote os related data, following tip shows:');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '       15:25:22     COMPLETE: BXDB -> Collection Completed, Running is [XX]');
        # printLOG('parseArgs', '       15:26:24    cltNodRes:');
        # printLOG('parseArgs', '       15:26:24    cltNodRes: <==================[ Attention ]==================>');
        # printLOG('parseArgs', '       15:26:24    cltNodRes:  Follow Command Must Manual Run on Remote Node');
        # printLOG('parseArgs', '       15:26:24    cltNodRes:  Remote List: XX');
        # printLOG('parseArgs', '       15:26:24    cltNodRes: <==================>==================>===========>');
        # printLOG('parseArgs', '       # ---------[ Please Run Following Command on Remote Server by Oracle ]----------');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '       perl -e \'use IO::Socket;use IO::Select;');
        # printLOG('parseArgs', '       $OH=$ENV{ORACLE_HOME};my ($PN,$PP)=(" 123.123.123.123",12345); # Primary');
        # printLOG('parseArgs', '       my $SK=IO::Socket::INET->new(PeerAddr=>$PN,PeerPort=>$PP,Proto=>TCP,Timeout=>60)');
        # printLOG('parseArgs', '       or die "Connect [$!]";$SL=IO::Select->new($SK);$NH=($SL->handles)[0];my @FL;');
        # printLOG('parseArgs', '       print "Files :";$NH->send("GET_FILE|X\n");die "No Reply"');
        # printLOG('parseArgs', '       if(! $SL->can_read(60));while(1){my $ND;chomp($ND=$NH->getline);last if($ND eq');
        # printLOG('parseArgs', '       "COMPLETED");print $ND;push(@FL,$ND);open FH,">",$ND;while(1){chomp($ND=');
        # printLOG('parseArgs', '       $NH->getline);last if($ND eq "<-EOF->");print FH "$ND\n";}close FH;');
        # printLOG('parseArgs', '       print "[OK] ";}print "\n";$ENV{"LIBPATH"}="$OH/lib32:$OH/lib";');
        # printLOG('parseArgs', '       $ENV{"SHLIB_PATH"}=$ENV{"LD_LIBRARY_PATH"}=$ENV{"LIBPATH"};');
        # printLOG('parseArgs', '       system("$OH/perl/bin/perl NodeRobot.pl $PN $PP");foreach(\@FL){unlink}\'');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '       # -------------------------------[ Command End ]--------------------------------');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '    When this tip shows, current collection task is suspend, then user must copy');
        # printLOG('parseArgs', '    the whole command in the tip and execute it on remote server.');
        # printLOG('parseArgs', '    Note: in the remote command, IP Address in second line may need to changed.');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> c. Waiting DG Data');
        # printLOG('parseArgs', '    When DG system found, following tip shows:');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '       15:35:15     cltDGDat: +=============== [ DG Information ] ===============+');
        # printLOG('parseArgs', '       15:35:15     cltDGDat: |  DG Name       Remote Host       Remote IP       |');
        # printLOG('parseArgs', '       15:35:15     cltDGDat: |  ------------- ----------------- --------------- |');
        # printLOG('parseArgs', '       15:35:15     cltDGDat: |  BXDG          BXDG              10.51.94.237    |');
        # printLOG('parseArgs', '       15:35:15     cltDGDat: +==================================================+');
        # printLOG('parseArgs', '       15:35:15     cltDGDat: Notes: You can skip DG Collection by [CTRL + C]');
        # printLOG('parseArgs', '       # ------------------------[ Run on Remote by Oracle ]---------------------------');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '       perl -e \'use IO::Socket;use IO::Select;');
        # printLOG('parseArgs', '       $OH=$ENV{ORACLE_HOME};my ($PN,$PP)=(" 123.123.123.123",12345); # Primary');
        # printLOG('parseArgs', '       my $SK=IO::Socket::INET->new(PeerAddr=>$PN,PeerPort=>$PP,Proto=>TCP,Timeout=>60)');
        # printLOG('parseArgs', '       or die "Connect [$!]";$SL=IO::Select->new($SK);$NH=($SL->handles)[0];my @FL;');
        # printLOG('parseArgs', '       print "Files :";$NH->send("GET_FILE|X\n");die "No Reply"');
        # printLOG('parseArgs', '       if(! $SL->can_read(60));while(1){my $ND;chomp($ND=$NH->getline);last if($ND eq');
        # printLOG('parseArgs', '       "COMPLETED");print $ND;push(@FL,$ND);open FH,">",$ND;while(1){chomp($ND=');
        # printLOG('parseArgs', '       $NH->getline);last if($ND eq "<-EOF->");print FH "$ND\n";}close FH;');
        # printLOG('parseArgs', '       print "[OK] ";}print "\n";$ENV{"LIBPATH"}="$OH/lib32:$OH/lib";');
        # printLOG('parseArgs', '       $ENV{"SHLIB_PATH"}=$ENV{"LD_LIBRARY_PATH"}=$ENV{"LIBPATH"};');
        # printLOG('parseArgs', '       system("$OH/perl/bin/perl DGRobot.pl $PN $PP");foreach(\@FL){unlink}\'');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '       # -------------------------------[ Command End ]--------------------------------');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '    When this tip shows, current collection task is suspend, then user must copy');
        # printLOG('parseArgs', '    the whole command in the tip and execute it on remote server.');
        # printLOG('parseArgs', "    Note: in the remote command, IP Address in second line may need to changed\n");

        # printLOG('parseArgs', '[Q] for quit, enter for next help page: ', 'N');
        # $uInput = uc(<>);
        # chomp $uInput;
        # $uInput =~ s/\A\s+|\s+\z//g;
        # print "\n";
        # exit 0 if ($uInput eq 'Q');
        # system($clearScreen);

        # printLOG('parseArgs', '[5] Configuration');
        # printLOG('parseArgs', '    In ['.$gFName{'CONFIG_DIR'}.'] directory, we have put some configuration files in it.');
        # printLOG('parseArgs', '=======================================================================================');
        # printLOG('parseArgs', '--> Config ['.$gFName{'LIB_CONFIG'}.']');
        # printLOG('parseArgs', '    ['.$gFName{'LIB_CONFIG'}.'] configuration file have most parameters for BTRobot, now it');
        # printLOG('parseArgs', '    has five parts of configuration:');
        # printLOG('parseArgs', '    -----------------------------------------------------------------------------------');
        # printLOG('parseArgs', '      a. Global Parameters       ');
        # printLOG('parseArgs', '      b. Global Files            -- Do not modify this part');
        # printLOG('parseArgs', '      c. OS Collection Modules   ');
        # printLOG('parseArgs', '      d. Result Files            ');
        # printLOG('parseArgs', '      e. Collection Status       -- Do not modify this part');
        # printLOG('parseArgs', "    -----------------------------------------------------------------------------------");
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> a. Global Parameters       ');
        # printLOG('parseArgs', '       This part of variables controls the behaviours of BTRobot when collect data.');
        # printLOG('parseArgs', '       The meaning of them list as below :');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '         Name                Value            Description');
        # printLOG('parseArgs', '         ------------------- ---------------- -----------------------------------------');
        # printLOG('parseArgs', '         SCRIPT_VERSION      '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Current script\'s version');
        # printLOG('parseArgs', '         ------------------- ---------------- -----------------------------------------');
        # printLOG('parseArgs', '         ALERT_KEEP          '.rPad($gENV{'ALERT_KEEP'}, 17)    .'[Var  ] Alert keep lines for each begining and ending of errors');
        # printLOG('parseArgs', '         ALT_IGNORE          <Not_List_Here>  '                 .'[Var  ] Error types ignored in alert collection');
        # printLOG('parseArgs', '         CPU_MIN_IDLE        '.rPad($gENV{'CPU_MIN_IDLE'}, 17)  .'[Var  ] Self-Monitor minimun percentage of CPU idle, -1 means off');
        # printLOG('parseArgs', '         DIR_MIN_SIZE        '.rPad($gENV{'DIR_MIN_SIZE'}, 17)  .'[Var  ] Self-Monitor minimun free space of result directory, -1 means off');
        # printLOG('parseArgs', '         EVENT_FILTER        <Not_List_Here>  '                 .'[Var  ] Wait event name in DB event collection');
        # #printLOG('parseArgs', '         GAP_IGNORE          '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] AWR gap ignore');
        # printLOG('parseArgs', '         ORACLE_HOME         '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Oracle Home, it comes from OS environment variable ORACLE_HOME');
        # printLOG('parseArgs', '         ORACLE_SID          '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Oracle SID, it comes from OS environment variable ORACLE_SID');
        # printLOG('parseArgs', '         PRINT_PROCESS       '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Print all process in function [getProc], do not change it');
        # printLOG('parseArgs', '         REMOTE_LOGIN        '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Remote login method, it set in interactive mode when RAC without SSH user equivalence');
        # printLOG('parseArgs', '         SKIP_STEP           '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Skip some waiting steps (such as DG), do not change it');
        # printLOG('parseArgs', '         SM_INTERVAL         '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Self-Monitor interval in seconds, 0 means off');
        # printLOG('parseArgs', '         SQL_BATCH_SIZE      '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Batch size to collect SQL-Releated data');
        # printLOG('parseArgs', '         SYSSTAT_FILTER      <Not_List_Here>  '                 .'[Var  ] Sysstat name in DB sysstat collection');
        # printLOG('parseArgs', '         TARGET_CHARSET      '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] Target file character, do not change it');
        # printLOG('parseArgs', '         TMOD_FILTER         <Not_List_Here>  '                 .'[Var  ] Time modle name in DB time modle collection');
        # printLOG('parseArgs', '         TOP_SQL             '.rPad($gENV{'SCRIPT_VERSION'}, 17).'[Var  ] AWR top SQL limits');
        # printLOG('parseArgs', '         ------------------- ---------------- -----------------------------------------');
        # printLOG('parseArgs', '         ASM_DIAG            '.rPad($gENV{'ASM_DIAG'}, 17)      .'[Var *] ASM diagnostic dest');
        # printLOG('parseArgs', '         CLT_TIME            '.rPad($gENV{'CLT_TIME'}, 17)      .'[Var *] Package collection time');
        # printLOG('parseArgs', '         DB_NAME             '.rPad($gENV{'DB_NAME'}, 17)       .'[Var *] DB name');
        # printLOG('parseArgs', '         DB_ROLE             '.rPad($gENV{'DB_ROLE'}, 17)       .'[Var *] DB role');
        # printLOG('parseArgs', '         DB_VERSION          '.rPad($gENV{'DB_VERSION'}, 17)    .'[Var *] DB version');
        # printLOG('parseArgs', '         DBID                '.rPad($gENV{'DBID'}, 17)          .'[Var *] DBID');
        # printLOG('parseArgs', '         EXTINST_TYPE        '.rPad($gENV{'EXTINST_TYPE'}, 17)  .'[Var *] Extra-Instances type (DG/OTHER), do not change it');
        # printLOG('parseArgs', '         GLOBAL_ERROR        '.rPad($gENV{'GLOBAL_ERROR'}, 17)  .'[Var *] Global error message');
        # printLOG('parseArgs', '         HOSTIP              '.rPad($gENV{'HOSTIP'}, 17)        .'[Var *] Current node IP');
        # printLOG('parseArgs', '         HOSTNAME            '.rPad($gENV{'HOSTNAME'}, 17)      .'[Var *] OS name');
        # printLOG('parseArgs', '         INST_COUNT          '.rPad($gENV{'INST_COUNT'}, 17)    .'[Var *] Instance count');
        # printLOG('parseArgs', '         INST_TYPE           '.rPad($gENV{'INST_TYPE'}, 17)     .'[Var *] Instance type [DB/ASM], do not change it');
        # printLOG('parseArgs', '         INSTANCE_LIST       '.rPad($gENV{'INSTANCE_LIST'}, 17) .'[Var *] Instance list for Extra-Instance collection');
        # printLOG('parseArgs', '         LISTEN_NODE         '.rPad($gENV{'LISTEN_NODE'}, 17)   .'[Var *] Package Listen node');
        # printLOG('parseArgs', '         MIN_SNAP            '.rPad($gENV{'MIN_SNAP'}, 17)      .'[Var *] Minimun snapshot ID in AWR data collection');
        # printLOG('parseArgs', '         MONITOR_PID         '.rPad($gENV{'MONITOR_PID'}, 17)   .'[Var *] Self-Monitor process ID');
        # printLOG('parseArgs', '         OBJ_SCHEMA          '.rPad($gENV{'OBJ_SCHEMA'}, 17)    .'[Var *] Object schema for Variable replace in SQL-Releated data collection');
        # printLOG('parseArgs', '         OS_TYPE             '.rPad($gENV{'OS_TYPE'}, 17)       .'[Var *] OS type');
        # printLOG('parseArgs', '         OS_USER             '.rPad($gENV{'OS_USER'}, 17)       .'[Var *] OS login user');
        # printLOG('parseArgs', '         PATH                '.rPad($gENV{'PATH'}, 17)          .'[Var *] OS path variable, it comes from OS environment variable PATH');
        # printLOG('parseArgs', '         SQL_LIST            '.rPad($gENV{'SQL_LIST'}, 17)      .'[Var *] List for variable replace in SQL-Releated data collection');
        # printLOG('parseArgs', '         TRACE_LIMIT         '.rPad($gENV{'TRACE_LIMIT'}, 17)   .'[Var *] Trace size limit, collection size for begining and ending of one trace');
        # printLOG('parseArgs', '         UNIQUE_NAME         '.rPad($gENV{'UNIQUE_NAME'}, 17)   .'[Var *] DB unique name');
        # printLOG('parseArgs', '         ------------------- ---------------- -----------------------------------------');
        # printLOG('parseArgs', '         DB_CHARSET          '.rPad($gENV{'DB_CHARSET'}, 17)    .'[Param] -c: DB Character');
        # printLOG('parseArgs', '         OS_CHARSET          '.rPad($gENV{'OS_CHARSET'}, 17)    .'[Param] -c: OS Character');
        # printLOG('parseArgs', '         ALT_CHARSET         '.rPad($gENV{'ALT_CHARSET'}, 17)   .'[Param] -c: Alert Character');
        # printLOG('parseArgs', '         LSN_CHARSET         '.rPad($gENV{'LSN_CHARSET'}, 17)   .'[Param] -c: Listener Character');
        # printLOG('parseArgs', '         OSERR_TIME          '.rPad($gENV{'OSERR_TIME'}, 17)    .'[Param] -e: OS Error Log Limit by Day');
        # printLOG('parseArgs', '         ASM_SID             '.rPad($gENV{'ASM_SID'}, 17)       .'[Param] -i: ASM SID');
        # printLOG('parseArgs', '         LOG_LIMIT           '.rPad($gENV{'LOG_LIMIT'}, 17)     .'[Param] -L: Log History Limit by Day');
        # printLOG('parseArgs', '         ASM_HOME            '.rPad($gENV{'ASM_HOME'}, 17)      .'[Param] -o: ASM Home');
        # printLOG('parseArgs', '         LISTEN_PORT         '.rPad($gENV{'LISTEN_PORT'}, 17)   .'[Param] -p: Script Listen Port');
        # printLOG('parseArgs', '         AWR_TIME            '.rPad($gENV{'AWR_TIME'}, 17)      .'[Param] -r: AWR Limit by Day');
        # printLOG('parseArgs', '         TOP_AWR             '.rPad($gENV{'TOP_AWR'}, 17)       .'[Param] -R: AWR Top AWR Report');
        # printLOG('parseArgs', '         TOP_SEGMENTS        '.rPad($gENV{'TOP_SEGMENTS'}, 17)  .'[Param] -s: AWR Top Segment Limits');
        # printLOG('parseArgs', '         COLLECT_DG          '.rPad($gENV{'COLLECT_DG'}, 17)    .'[Param] -S: Collect DG Data');
        # printLOG('parseArgs', '         ALERT_TIME          '.rPad($gENV{'ALERT_TIME'}, 17)    .'[Param] -t: Alert Log Limit by Day');
        # printLOG('parseArgs', '         LSNR_TIME           '.rPad($gENV{'LSNR_TIME'}, 17)     .'[Param] -T: Listener Log Limit by Day');
        # printLOG('parseArgs', '         DB_USER             '.rPad($gENV{'DB_USER'}, 17)       .'[Param] -u: DB Login - User');
        # printLOG('parseArgs', '         DB_PSWD             '.rPad($gENV{'DB_PSWD'}, 17)       .'[Param] -u: DB Login - Password');
        # printLOG('parseArgs', '         DB_SERV             '.rPad($gENV{'DB_SERV'}, 17)       .'[Param] -u: DB Login - Connect String');
        # printLOG('parseArgs', '         ASM_USER            '.rPad($gENV{'ASM_USER'}, 17)      .'[Param] -U: ASM Login - User');
        # printLOG('parseArgs', '         ASM_PSWD            '.rPad($gENV{'ASM_PSWD'}, 17)      .'[Param] -U: ASM Login - Password');
        # printLOG('parseArgs', '         ASM_SERV            '.rPad($gENV{'ASM_SERV'}, 17)      .'[Param] -U: ASM Login - Connect String');
        # printLOG('parseArgs', '         TOP_WAITS           '.rPad($gENV{'TOP_WAITS'}, 17)     .'[Param] -w: AWR Top Event Limits');
        # printLOG('parseArgs', '         RESULT_ZIP          '.rPad($gENV{'RESULT_ZIP'}, 17)    .'[Param] -z: Use Zip File');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '       * Note: Variables with * means it can be query from DB or get with OS command,');
        # printLOG('parseArgs', '               and normally user can not modify these variables.');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> b. Global Files');
        # printLOG('parseArgs', '       This part of variables controls the directories and file of BTRobot.');
        # printLOG('parseArgs', '       Do not modify this part.');
        # printLOG('parseArgs', '       The meaning of them list as below :');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '         Name            Value                Description');
        # printLOG('parseArgs', '         --------------- -------------------- -----------------------------------------');
        # printLOG('parseArgs', '         DATA_DIR        data                 BTRobot\'s data directory');
        # printLOG('parseArgs', '         CONFIG_DIR      conf                 BTRobot\'s configuration directory');
        # printLOG('parseArgs', '         LIB_DIR         lib                  BTRobot\'s library directory');
        # printLOG('parseArgs', '         RESULT_DIR      data                 Collection data directory, it different between each collections');
        # printLOG('parseArgs', '         DG_SCRIPT       DGRobot.pl           DG collection script');
        # printLOG('parseArgs', '         NODE_SCRIPT     NodeRobot.pl         OS node collection script');
        # printLOG('parseArgs', '         MAIN_SCRIPT     BTRobot.pl           BTRobot main collection script');
        # printLOG('parseArgs', '         LIB_TOOLS       BTTools.pm           Tool library');
        # printLOG('parseArgs', '         LIB_DBTOOL      DBTools.pm           DB tool library');
        # printLOG('parseArgs', '         LIB_CONFIG      BTConfig.pm          BTRobot configuration library');
        # printLOG('parseArgs', '         NOHUP_LOG       BTRobot_Nohup.log    Logfile for backgroup process when collect os data');
        # printLOG('parseArgs', '         MONITOR_LOG     BTRobot_Monitor.log  Logfile for monitor process');
        # printLOG('parseArgs', '         LOGFILE         BTRobot.log          Logfile for BTRobot main process');
        # printLOG('parseArgs', '         WARN_LOGFILE    BTRobot_warn.log     Error/Warn logfile for BTRobot main process');
        # printLOG('parseArgs', '         DBI_TRACE_FILE  BTRobot_DBI.trc      Logfile for DBI driver');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> c. OS Collection Modules');
        # printLOG('parseArgs', '       This part of variables controls the os data collection by modules.');
        # printLOG('parseArgs', '       The meaning of them list as below :');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '         Name         Value   Description');
        # printLOG('parseArgs', '         ------------ ------- ---------------------------------------------------------');
        # printLOG('parseArgs', '         osBasic      ENABLE  OS basic information collection, do not DISABLE it');
        # printLOG('parseArgs', '         osAlert      ENABLE  DB alert logfile collection');
        # printLOG('parseArgs', '         osCrontab    ENABLE  OS crontab collection, only valid for Linux/Unix');
        # printLOG('parseArgs', '         osListener   ENABLE  DB listener logfile collection, include listener status and configurations');
        # printLOG('parseArgs', '         osError      ENABLE  OS error log collection, only valid for AIX/HPUX/solaris');
        # printLOG('parseArgs', '         osInstance   ENABLE  OS Extra-Instance collection');
        # printLOG('parseArgs', '         osFS         ENABLE  OS file system usage collection');
        # printLOG('parseArgs', '         osHosts      ENABLE  OS hosts configuration collection');
        # printLOG('parseArgs', '         osMemory     ENABLE  OS memory usage collection');
        # printLOG('parseArgs', '         osNIC        ENABLE  OS network configuration collection');
        # printLOG('parseArgs', '         osOPatch     ENABLE  DB patch collection by opatch command');
        # printLOG('parseArgs', '         osParameter  ENABLE  OS kernel parameters collection, only valid for Linux/Unix');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> d. Result Files');
        # printLOG('parseArgs', '       This part of variables controls the format of each result file.');
        # printLOG('parseArgs', '       For database data, the format is given by SQL query columns');
        # printLOG('parseArgs', '       Each result items may have 5 attributes:');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '         a. FILE    : Result file name');
        # printLOG('parseArgs', '         b. CLASS   : Result data type, it can be CT/OS/DB/DG/SUB');
        # printLOG('parseArgs', '         c. DEFINE  : Valid in OS data items, it\'s the format of data lines');
        # printLOG('parseArgs', '         d. SQL     : Valid in DB data items, for different version, it can be SQL/SQL_10/SQL_11/SQL_12');
        # printLOG('parseArgs', '         e. STATUS  : Valid in DB data items, controls whether collect it or not');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '       Note: User can change STATUS, but not to change other data.');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> e. Collection Status');
        # printLOG('parseArgs', '       This part of variables controls the BTRobot collection status message.');
        # printLOG('parseArgs', '       Do not modify this part.');
        # printLOG('parseArgs', '');
        # printLOG('parseArgs', '--> f. Alert Capture Keywords');
        # printLOG('parseArgs', '       This part of variables controls the keywords in DB alert logfile collection.');
        # printLOG('parseArgs', '       Each item have to parts: Name and Expression(support simple regular expression).');
        # printLOG('parseArgs', '       Examples list as below:');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');
        # printLOG('parseArgs', '         Name              Expression');
        # printLOG('parseArgs', '         ----------------  ---------------------------------------------------------');
        # printLOG('parseArgs', '         CKPT_NOT_OK       Checkpoint\s+not\s+complete');
        # printLOG('parseArgs', '         ARCH_REQUIRED     archival\s+required');
        # printLOG('parseArgs', '         WARNING           warn');
        # printLOG('parseArgs', '       --------------------------------------------------------------------------------');

        print "\n";
        exit 0;
    }
    if(exists $args{'v'})
    {
        printLOG('parseArgs', "OPTION: Robot version [$gENV{'SCRIPT_VERSION'}]");
        exit 0;
    }
    # if(exists $args{'A'})
    # {
    #     printLOG('parseArgs', "OPTION: Batch Upload for User [$args{'A'}]");
    #     if($args{'A'} =~ m/\A1\d{12}\z/)
    #     {
    #         $gENV{'UPLOAD_USER'} = $args{'A'};
    #     }
    #     else
    #     {
    #         printLOG('parseArgs', "OPTION: Invalid Mobile Number [$args{'A'}]");
    #         exit 1;
    #     }
    # }
    if(exists $args{'B'})
    {
        printLOG('parseArgs', "OPTION: Busy Section [$args{'B'}]");
        if($args{'B'} =~ m/\A(\d+(\-\d+)?,?)+\z/)
        {
            $gENV{'BUSY_SECTIONS'} = "";
            foreach(split(/,/, $args{'B'}))
            {
                my @sections = split(/\-/);
                if(defined $sections[1])
                {
                    for (my $x = $sections[0]; $x <= $sections[1]; $x ++)
                    {
                        $gENV{'BUSY_SECTIONS'} = "$gENV{'BUSY_SECTIONS'},$x";
                    }
                }
                elsif(defined $sections[0])
                {
                    $gENV{'BUSY_SECTIONS'} = "$gENV{'BUSY_SECTIONS'},$sections[0]";
                }
            }
            $gENV{'BUSY_SECTIONS'} =~ s/\A,+//;
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Busy Section [$args{'B'}]");
            printLOG('parseArgs', "FORMAT: 8-18 or 9,10,15,16 or 9-12,14-18");
            exit 1;
        }
    }
    if(exists $args{'c'})
    {
        printLOG('parseArgs', "OPTION: CharacterSet/Encoding [$args{'C'}]");
        $args{'c'} = uc($args{'c'});   # Convert to UP Case
        $args{'c'} =~ s/\s//g;         # Remove Empty Char
        foreach (split(/,/, $args{'c'}))
        {
            my @CSE = split(/=/);
            if(defined $CSE[1])
            {
                if($CSE[0] eq 'O' and $CSE[1] =~ m/\A(UTF8|GBK)\z/)
                {
                    printLOG('parseArgs', "OPTION: Encoding for OS [$CSE[1]]");
                    $gENV{'OS_CHARSET'} = $CSE[1];
                }
                elsif($CSE[0] eq 'A' and $CSE[1] =~ m/\A(UTF8|GBK)\z/)
                {
                    printLOG('parseArgs', "OPTION: Encoding for Alert [$CSE[1]]");
                    $gENV{'ALT_CHARSET'} = $CSE[1];
                }
                elsif($CSE[0] eq 'L' and $CSE[1] =~ m/\A(UTF8|GBK)\z/)
                {
                    printLOG('parseArgs', "OPTION: Encoding for Listener [$CSE[1]]");
                    $gENV{'LSN_CHARSET'} = $CSE[1];
                }
                else
                {
                    printLOG('parseArgs', "OPTION: Invalid Value [$CSE[0]=$CSE[1]]");
                    exit 1;
                }
            }
            else
            {
                printLOG('parseArgs', "OPTION: Invalid CharacterSet/Encoding [".join('=', @CSE)."]");
                printLOG('parseArgs', "FORMAT: O=GBK,A=GBK,L=GBK");
                exit 1;
            }
        }
    }
    if(exists $args{'e'})
    {
        $args{'e'} = '' if(not defined $args{'e'});
        if($args{'e'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: OS Error Collect Day [$args{'e'}]");
            $gENV{'OSERR_TIME'} = $args{'e'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid OS Error Collect Day [$args{'e'}]");
            exit 1;
        }
    }
    if(exists $args{'i'})
    {
        $args{'i'} = '' if(not defined $args{'i'});
        if($args{'i'} =~ m/\A\w+\z/)
        {
            printLOG('parseArgs', "OPTION: ASM SID [$args{'i'}]");
            $gENV{'ASM_SID'} = $args{'i'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid ASM SID [$args{'i'}]");
            exit 1;
        }
    }
    if(exists $args{'L'})
    {
        $args{'L'} = '' if(not defined $args{'L'});
        if($args{'L'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: Log History Limit [$args{'L'}]");
            $gENV{'LOG_LIMIT'} = $args{'L'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Log History Limit [$args{'L'}]");
            exit 1;
        }
    }
    if(exists $args{'M'})
    {
        $args{'M'} = '' if(not defined $args{'M'});
        if(-r $gFName{'CONFIG_DIR'}.'/'.$args{'M'})
        {
            printLOG('parseArgs', "OPTION: Multi-Server Config File [$args{'M'}]");
            $gFName{'SERVER_CONFIG'} = $args{'M'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Multi-Server Config File [$args{'M'}]");
            exit 1;
        }
    }
    if(exists $args{'o'})
    {
        $args{'o'} = '' if(not defined $args{'o'});
        if(-d $args{'o'})
        {
            printLOG('parseArgs', "OPTION: ASM Home [$args{'o'}]");
            $gENV{'ASM_HOME'} = $args{'o'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid ASM Home [$args{'o'}]");
            exit 1;
        }
    }
    if(exists $args{'p'})
    {
        $args{'p'} = '' if(not defined $args{'p'});
        if($args{'p'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: Listening Port (Primary) [$args{'p'}]");
            $gENV{'LISTEN_PORT'} = $args{'p'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Listening Port (Primary) [$args{'p'}]");
            exit 1;
        }
    }
    if(exists $args{'Q'})
    {
        $gENV{'QUIET_MODE'} = 1;
    }
    if(exists $args{'r'})
    {
        $args{'r'} = '' if(not defined $args{'r'});
        if($args{'r'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: AWR Collect Day [$args{'r'}]");
            $gENV{'AWR_TIME'} = $args{'r'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid AWR Collect Day [$args{'r'}]");
            exit 1;
        }
    }
    if(exists $args{'R'})
    {
        $args{'R'} = '' if(not defined $args{'R'});
        if($args{'R'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: AWR Top Number [$args{'R'}]");
            $gENV{'TOP_AWR'} = $args{'R'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid AWR Top Number [$args{'R'}]");
            exit 1;
        }
    }
    if(exists $args{'s'})
    {
        $args{'s'} = '' if(not defined $args{'s'});
        if($args{'s'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: Top Segment Limit [$args{'s'}]");
            $gENV{'TOP_SEGMENTS'} = $args{'s'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Top Segment Limit [$args{'s'}]");
            exit 1;
        }
    }
    if(exists $args{'S'})
    {
        printLOG('parseArgs', "OPTION: not Collect DG Data");
        $gENV{'COLLECT_DG'} = 0;
    }
    if(exists $args{'t'})
    {
        $args{'t'} = '' if(not defined $args{'t'});
        if($args{'t'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: Alert Collect Day [$args{'t'}]");
            $gENV{'ALERT_TIME'} = $args{'t'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Alert Collect Day [$args{'t'}]");
            exit 1;
        }
    }
    if(exists $args{'T'})
    {
        $args{'T'} = '' if(not defined $args{'T'});
        if($args{'T'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: Listener Collect Day [$args{'T'}]");
            $gENV{'LSNR_TIME'} = $args{'T'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Listener Collect Day [$args{'T'}]");
            exit 1;
        }
    }
    if(exists $args{'u'})
    {
        $args{'u'} = '' if(not defined $args{'u'});
        if($args{'u'} =~ m#([^/]+)(/[^@]*)?(@.+)?#)
        {
            printLOG('parseArgs', "OPTION: DB Login Info [$args{'u'}]");
            $gENV{'DB_USER'} = $1;
            $gENV{'DB_USER'} =~ s/\A\s|\s\z//g;
            if(defined $2)
            {
                $gENV{'DB_PSWD'} = $2;
                $gENV{'DB_PSWD'} =~ s/\A(\s|\/)+|\s\z//g;
            }
            if(defined $3)
            {
                $gENV{'DB_SERV'} = $3;
                $gENV{'DB_SERV'} =~ s/\A(\s|@)+|\s\z//g;
            }
            printLOG('parseArgs', "OPTION: DB Login [$gENV{'DB_USER'}/$gENV{'DB_PSWD'}\@$gENV{'DB_SERV'}]", 'L');
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid DB Login Info [$args{'u'}]");
            exit 1;
        }
    }
    if(exists $args{'U'})
    {
        $args{'U'} = '' if(not defined $args{'U'});
        if($args{'U'} =~ m#([^/]+)(/[^@]*)?(@.+)?#)
        {
            printLOG('parseArgs', "OPTION: ASM Login Info [$args{'U'}]");
            $gENV{'ASM_USER'} = $1;
            $gENV{'ASM_USER'} =~ s/\A\s|\s\z//g;
            if(defined $2)
            {
                $gENV{'ASM_PSWD'} = $2;
                $gENV{'ASM_PSWD'} =~ s/\A(\s|\/)+|\s\z//g;
            }
            if(defined $3)
            {
                $gENV{'ASM_SERV'} = $3;
                $gENV{'ASM_SERV'} =~ s/\A(\s|@)+|\s\z//g;
            }
            printLOG('parseArgs', "OPTION: ASM Login [$gENV{'ASM_USER'}/$gENV{'ASM_PSWD'}\@$gENV{'ASM_SERV'}]", 'L');
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid ASM Login Info [$args{'U'}]");
            exit 1;
        }
    }
    if(exists $args{'w'})
    {
        $args{'w'} = '' if(not defined $args{'w'});
        if($args{'w'} =~ m/\A\d+\z/)
        {
            printLOG('parseArgs', "OPTION: Top Wait Limit [$args{'w'}]");
            $gENV{'TOP_WAITS'} = $args{'w'};
        }
        else
        {
            printLOG('parseArgs', "OPTION: Invalid Top Wait Limit [$args{'w'}]");
            exit 1;
        }
    }
    if(exists $args{'z'})
    {
        printLOG('parseArgs', "OPTION: not Automatic tar and gzip");
        $gENV{'RESULT_ZIP'} = 0;
    }
}

################################################################################
##                                                                            ##
## checkENV: Check Result Directory                                           ##
##                                                                            ##
################################################################################
sub checkENV()
{
    # 1. Get OS Type
    # --------------------------------------------------------------------------
    $gENV{'OS_TYPE'} = $^O;       # MSWin32/linux/aix/hpux/solaris
    printLOG('checkENV', "OS Type : [$gENV{'OS_TYPE'}]");
    if($gENV{'OS_TYPE'} !~ m/\AMSWin32|linux|aix|hpux|solaris\z/)
    {
        die "Cannot Support OS Type [$gENV{'OS_TYPE'}]";
    }


    # 2. Get OS Hostname/IP
    # --------------------------------------------------------------------------
    $gENV{'HOSTNAME'} = hostname;
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        $gENV{'HOSTNAME'} = uc($gENV{'HOSTNAME'});
    }
    printLOG('checkENV', "OS Hostname : [$gENV{'HOSTNAME'}]");
    if(open HOSTF, '<', '/etc/hosts'
    or open HOSTF, '<', 'C:\Windows\System32\Drivers\etc\hosts'
    or open HOSTF, '<', $ENV{'WINDIR'}.'\System32\Drivers\etc\hosts'
    or open HOSTF, '<', $ENV{'windir'}.'\System32\Drivers\etc\hosts')
    {
        while(<HOSTF>)
        {
            s/\A\s+|\r|\n|\s+\z//g;
            next if(m/(\A#|\A\z)/);
            my @items = split(/\s+/);
            for(my $x = 1; $x <= $#items; $x ++)
            {
                if(uc($items[$x]) eq uc($gENV{'HOSTNAME'}))
                {
                    $gENV{'HOSTIP'} = $items[0];
                    last;
                }
            }
            last if($gENV{'HOSTIP'} ne '127.0.0.1');
        }
        close HOSTF;
    }
    else
    {
        printLOG('checkENV', "Cannot Read [hosts] to Parse IP Address");
    }
    printLOG('checkENV', "OS HostIP : [$gENV{'HOSTIP'}]");


    # 3. Check Running User
    # --------------------------------------------------------------------------
    if(defined $ENV{'USER'})
    {
        $gENV{'OS_USER'} = $ENV{'USER'};
        printLOG('checkENV', "OS Login User (ENV:USER): [$gENV{'OS_USER'}]");
    }
    elsif(defined $ENV{'USERNAME'})
    {
        $gENV{'OS_USER'} = $ENV{'USERNAME'};
        printLOG('checkENV', "OS Login User (ENV:USERNAME): [$gENV{'OS_USER'}]");
    }
    else
    {
        $gENV{'OS_USER'} = execOS('whoami 2>/dev/null');
        printLOG('checkENV', "OS Login User (whoami): [$gENV{'OS_USER'}]");
    }
    if($gENV{'OS_USER'} eq 'root')
    {
        die "Cannot Execute Script with root User, Please Switch to Oracle!";
    }


    # 4. Write Running Environments
    # --------------------------------------------------------------------------
    printLOG('checkENV', 'Check Running Environments');
    $gENV{'ORACLE_SID'}  = $ENV{'ORACLE_SID'};
    $gENV{'ORACLE_HOME'} = $ENV{'ORACLE_HOME'};
    printLOG('checkENV', 'Script Version: ['.$gENV{'SCRIPT_VERSION'}.']');
    printLOG('checkENV', "  Perl Version: [$]]"                       , 'L');
    printLOG('checkENV', '   DBI Version: ['.$DBI::VERSION.']'        , 'L');
    printLOG('checkENV', '   DBD Version: ['.$DBD::Oracle::VERSION.']', 'L');
    printLOG('checkENV', "      PERL5LIB: [$ENV{'PERL5LIB'}]"         , 'L');
    printLOG('checkENV', "    Oracle SID: [$gENV{'ORACLE_SID'}]");
    printLOG('checkENV', "   Oracle Home: [$gENV{'ORACLE_HOME'}]");
    printLOG('checkENV', "  Library Path: [$ENV{'LIBPATH'}]");


    # 5. Set PATH (add /usr/sbin if not Set)
    # --------------------------------------------------------------------------
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        if ($ENV{'PATH'} =~ m@C:\\WINDOWS(;|\z)@i)
        {
            $ENV{'PATH'} =  $ENV{'PATH'}.';C:\WINDOWS';
        }
        if ($ENV{'PATH'} =~ m@C:\\WINDOWS\\system32(;|\z)@i)
        {
            $ENV{'PATH'} =  $ENV{'PATH'}.';C:\WINDOWS\system32';
        }
        if ($ENV{'PATH'} =~ m@C:\\WINDOWS\\system32\\Wbem(;|\z)@i)
        {
            $ENV{'PATH'} =  $ENV{'PATH'}.';C:\WINDOWS\System32\Wbem';
        }
    }
    elsif($ENV{'PATH'} !~ m@/usr/sbin(:|\z)@)
    {
        $ENV{'PATH'} = "/usr/sbin:$ENV{'PATH'}"
    }
    $gENV{'PATH'} = $ENV{'PATH'};
    printLOG('checkENV', "PATH is [$gENV{'PATH'}]", 'L');


    # 6. Get DB Version
    # --------------------------------------------------------------------------
    if(execOS("$gENV{'ORACLE_HOME'}/bin/sqlplus -v") =~ m/SQL\*Plus:\s+Release\s+(\d+)/i)
    {
        # SQL*Plus: Release 10.2.0.1.0 - Production
        $gENV{'DB_VERSION'} = $1;
        printLOG('checkENV', "Oracle Version [$gENV{'DB_VERSION'}]");
    }
    else
    {
        die "Cannot Get Oracle Version from [$gENV{'ORACLE_HOME'}/bin/sqlplus -v]";
    }
}

################################################################################
##                                                                            ##
## getBasic: Check Result Directory                                           ##
##                                                                            ##
################################################################################
sub getBasic()
{
    # 1. Test Oracle Login
    # --------------------------------------------------------------------------
    printLOG('getBasic', "Test DB Logging");
    if(not connDB('DB', $gENV{'DB_USER'}, $gENV{'DB_PSWD'}, $gENV{'DB_SERV'}))
    {
        foreach(split(/[\r\n]+/, $DBTools::dbError))
        {
            printLOG("getBasic", "Connect Error: ".$_);
        }
        die "Cannot Connect to Current DB Instance";
    }


    # 2. Check Privilege
    # --------------------------------------------------------------------------
    printLOG('getBasic', "Check DB Privilege for [$gENV{'DB_USER'}]");
    my $sqlRes = queryDB(qq{SELECT (SELECT COUNT(*) FROM ALL_TAB_PRIVS WHERE PRIVILEGE = 'EXECUTE' AND TABLE_NAME = 'DBMS_OUTPUT') DO
                                 , (SELECT COUNT(*) FROM ALL_TAB_PRIVS WHERE PRIVILEGE = 'EXECUTE' AND TABLE_NAME = 'DBMS_WORKLOAD_REPOSITORY') DWR
                                 , (SELECT COUNT(*) FROM (SELECT * FROM USER_SYS_PRIVS WHERE PRIVILEGE = 'SELECT ANY DICTIONARY' UNION ALL SELECT * FROM ROLE_SYS_PRIVS WHERE PRIVILEGE = 'SELECT ANY DICTIONARY')) SAD
                              FROM DUAL
                           });
    printLOG('getBasic', "Check Result [$sqlRes->[0]->[0]] [$sqlRes->[0]->[1]] [$sqlRes->[0]->[2]]", 'L');
    my @lostPriv;
    if($sqlRes->[0]->[0] == 0)
    {
        push(@lostPriv, "GRANT EXECUTE ON DBMS_OUTPUT TO $gENV{'DB_USER'};")
    }
    if($sqlRes->[0]->[1] == 0)
    {
        push(@lostPriv, "GRANT EXECUTE ON DBMS_WORKLOAD_REPOSITORY TO $gENV{'DB_USER'};")
    }
    if($sqlRes->[0]->[2] == 0)
    {
        push(@lostPriv, "GRANT SELECT ANY DICTIONARY TO $gENV{'DB_USER'};")
    }
    if(scalar @lostPriv)
    {
        printLOG('getBasic', "Some More Privilege Needed:");
        foreach (@lostPriv)
        {
            printLOG('getBasic', "==> ".$_);
        }
        exit 1;
    }


    # 3. Check Oracle Running, Get DB Basic Information
    # --------------------------------------------------------------------------
    printLOG('getBasic', "Get DB Basic Information");
    $sqlRes = queryDB(qq{SELECT DBID
                              , NAME
                              , DB_UNIQUE_NAME
                              , DATABASE_ROLE
                              , TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') CLT_TIME
                              , SYSDATE - $gENV{'OSERR_TIME'} OS_TIME
                              , SYSDATE - $gENV{'ALERT_TIME'} ALERT_TIME
                              , TRUNC(SYSDATE - $gENV{'LSNR_TIME'}, 'HH24')  LSNR_TIME
                              , (SELECT NVL(MIN(SNAP_ID), 0) FROM DBA_HIST_SNAPSHOT WHERE BEGIN_INTERVAL_TIME >= SYSDATE - $gENV{'AWR_TIME'}) MIN_SNAP
                           FROM V\$DATABASE
                        });
    $gENV{'DBID'}          = $sqlRes->[0]->[0];
    $gENV{'DB_NAME'}       = $sqlRes->[0]->[1];
    $gENV{'UNIQUE_NAME'}   = $sqlRes->[0]->[2];
    $gENV{'DB_ROLE'}       = $sqlRes->[0]->[3];
    $gENV{'CLT_TIME'}      = $sqlRes->[0]->[4];
    $gENV{'OSERR_TIME'}    = $sqlRes->[0]->[5];
    $gENV{'ALERT_TIME'}    = $sqlRes->[0]->[6];
    $gENV{'LSNR_TIME'}     = $sqlRes->[0]->[7];
    $gENV{'MIN_SNAP'}      = $sqlRes->[0]->[8];
    printLOG('getBasic', "         DBID: [$gENV{'DBID'}]");
    printLOG('getBasic', "      DB Name: [$gENV{'DB_NAME'}]");
    printLOG('getBasic', "  Unique Name: [$gENV{'UNIQUE_NAME'}]");
    printLOG('getBasic', "         Role: [$gENV{'DB_ROLE'}]");
    printLOG('getBasic', "         Time: [$gENV{'CLT_TIME'}]");
    printLOG('getBasic', "     Language: [$ENV{'NLS_LANG'}]");
    printLOG('getBasic', "      OS Time: [$gENV{'OSERR_TIME'}]");
    printLOG('getBasic', "   Alert Time: [$gENV{'ALERT_TIME'}]");
    printLOG('getBasic', "Listener Time: [$gENV{'LSNR_TIME'}]");
    printLOG('getBasic', " Minimum Snap: [$gENV{'MIN_SNAP'}]");


    # 4. Get Instance-Host Mapping
    # --------------------------------------------------------------------------
    printLOG('getBasic', "Read OS-Instance Mapping from DB");
    $sqlRes = queryDB(q{SELECT INST_ID, HOST_NAME, INSTANCE_NAME FROM GV$INSTANCE});
    $gENV{'INSTANCE_COUNT'} = $#{$sqlRes} + 1;
    printLOG('getBasic', "Instance Count: $gENV{'INSTANCE_COUNT'}");
    if($gENV{'INSTANCE_COUNT'} == 1)
    {
        $osInst{$gENV{'HOSTNAME'}}->{'ID'}   = $sqlRes->[0]->[0];
        $osInst{$gENV{'HOSTNAME'}}->{'NAME'} = $sqlRes->[0]->[2];
        printLOG('getBasic', "OS-Inst mapping item (Single): [$gENV{'HOSTNAME'}] ==> [$sqlRes->[0]->[0].$sqlRes->[0]->[2]]");
    }
    else
    {
        foreach my $resLine (@{$sqlRes})
        {
            $osInst{$resLine->[1]}->{'ID'}   = $resLine->[0];
            $osInst{$resLine->[1]}->{'NAME'} = $resLine->[2];
            printLOG('getBasic', "OS-Inst mapping item (RAC): [$resLine->[1]] ==> [$resLine->[0].$resLine->[2]]");
        }
    }
}

################################################################################
##                                                                            ##
## checkEncode: Check Result Directory                                        ##
##                                                                            ##
################################################################################
sub checkEncode()
{
    # 1. Set OS Character Set
    # --------------------------------------------------------------------------
    if($gENV{'OS_CHARSET'} eq 'NONE')
    {
        if($gENV{'OS_TYPE'} eq 'MSWin32')
        {
            $gENV{'OS_CHARSET'} = execOS('chcp');
            $gENV{'OS_CHARSET'} =~ s/[^\d]//g;

            if($gENV{'OS_CHARSET'} eq '65001')
            {
                $gENV{'OS_CHARSET'} = 'UTF8'
            }
            else
            {
                $gENV{'OS_CHARSET'} = 'GBK'
            }
        }
        else
        {
            $gENV{'OS_CHARSET'} = 'UTF8';
            if(exists $ENV{'LANG'})
            {
                printLOG('checkEncode', "OS Env of LANG is [$ENV{'LANG'}]", 'L');
                if($ENV{'LANG'} =~ m/GB/i)
                {
                    $gENV{'OS_CHARSET'} = 'GBK';
                }
            }
        }
    }
    printLOG('checkEncode', "Set OS Character [$gENV{'OS_CHARSET'}]");


    # 2. Set Alert Character Set
    # --------------------------------------------------------------------------
    if($gENV{'ALT_CHARSET'} eq 'NONE')
    {
        $gENV{'ALT_CHARSET'} = $gENV{'DB_CHARSET'};
        # if($gENV{'OS_TYPE'} eq 'MSWin32')
        # {
        #     $gENV{'ALT_CHARSET'} = $gENV{'OS_CHARSET'};
        # }
        # else
        # {
        #     $gENV{'ALT_CHARSET'} = $gENV{'DB_CHARSET'};
        # }
    }
    printLOG('checkEncode', "Set Alert Character [$gENV{'ALT_CHARSET'}]");


    # 3. Set Listener Character Set
    # --------------------------------------------------------------------------
    if($gENV{'LSN_CHARSET'} eq 'NONE')
    {
        # $gENV{'ALT_CHARSET'} = $gENV{'DB_CHARSET'};
        $gENV{'LSN_CHARSET'} = $gENV{'OS_CHARSET'};
    }
    printLOG('checkEncode', "Set Listener Character [$gENV{'LSN_CHARSET'}]");
}

################################################################################
##                                                                            ##
## checkASM: Check Result Directory                                           ##
##                                                                            ##
################################################################################
sub checkASM()
{
    # 4. Get ASM SID/Home
    # a. Get ASM SID
    # --------------------------------------------------------------------------
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {

        # a. Get ASM SID
        my $asmInf = execOS('sc query state= all | find  "SERVICE_NAME" | find "OracleASMService"');
        # SERVICE_NAME: OracleServiceWINDB
        if(defined $asmInf and $asmInf ne '')
        {
            printLOG('checkASM', "ASM Service on Windows [$asmInf]", 'L');

            $asmInf =~ s/\A.*SERVICE_NAME[\s\:]+//gm;
            printLOG('checkASM', "ASM Service Name : [$asmInf]", 'L');

            # b. Get ASM Home
            my $asmInf = execOS(qq{sc qc $asmInf | find "BINARY_PATH_NAME"});
            #        BINARY_PATH_NAME   : c:\oracle\product\10.2.0\db_1\bin\ORACLE.EXE WINDB
            printLOG('checkASM', "ASM Binary Path [$asmInf]", 'L');

            # Split ASM Home and SID
            $asmInf =~ s/\A.*BINARY_PATH_NAME[\s\:]+//i;
            ($gENV{'ASM_HOME'}, $gENV{'ASM_SID'}) = split(/\s+/, $asmInf);
            $gENV{'ASM_HOME'} =~ s/\\bin\\ORACLE.EXE//i;
            printLOG('checkASM', "ASM [SID:Home] on Windows is [$gENV{'ASM_SID'}:$gENV{'ASM_HOME'}]");
        }
        else
        {
            printLOG('checkASM', "no ASM instance found for Win");
        }
    }
    elsif(defined (my $asmInf = (getProc('asm_ckpt'))[0]))
    {   # Get ASM Instance (Linux), Keep only First One

        # a. Get ASM SID
        printLOG('checkASM', "ASM Process Line [$asmInf]", 'L');
        $asmInf =~ s/\A.+asm_ckpt_|\s+\z//g;
        $gENV{'ASM_SID'} = $asmInf;
        printLOG('checkASM', "ASM SID : [$gENV{'ASM_SID'}]");

        # b. Get ASM Home
        if(open ORATABF, '<', '/var/opt/oracle/oratab'  # oratab File for SunOS
           or open ORATABF, '<', '/etc/oratab')
           {           # oratab File for Other Unix OS
            printLOG('checkASM', "Search ASM Home from [oratab] file");
            while(<ORATABF>)
            {
                s/\r|\n//g;  # chomp;     # Remove New-Line Char
                printLOG('checkASM', "Oratab --> [$_]", 'L');
                s/#.*//;     # Remove Comments
                if(index($_, $gENV{'ASM_SID'}) >= 0)
                {
                    $gENV{'ASM_HOME'} = (split(/\:/))[1];  # Get ASM Home (Part 2 Split by :)
                    printLOG('checkASM', "ASM Home in Oratab File [$gENV{'ASM_HOME'}]", 'L');
                }
            }
            close ORATABF;
        }

        # c. Manually Input ASM Home if not Found Automatic
        if($gENV{'QUIET_MODE'} == 1)
        {
            $gENV{'ASM_HOME'} = $gENV{'ORACLE_HOME'};
        }
        else
        {
            writeTime('BEGINER');
            until(defined $gENV{'ASM_HOME'} and -f "$gENV{'ASM_HOME'}/bin/sqlplus")
            {
                printLOG('checkASM', "invalid ASM Home [$gENV{'ASM_HOME'}], Please re-Input (Default: use ORACLE_HOME) :");
                printLOG('checkASM', '====> ', 'N');
                $gENV{'ASM_HOME'} = <>;
                $gENV{'ASM_HOME'} =~ s/\r|\n//g;
                $gENV{'ASM_HOME'} =~ s@[/\\]+\z@@g;
                $gENV{'ASM_HOME'} = $gENV{'ORACLE_HOME'} if($gENV{'ASM_HOME'} eq '');
            }
            writeTime('INPUT.ASMHOME');
        }
        printLOG('checkASM', "Found ASM HOME : [$gENV{'ASM_HOME'}]");
    }
    else
    {
        printLOG('checkASM', "no ASM instance found for Unix");
    }
}

################################################################################
##                                                                            ##
## checkDIR: Check Result Directory                                           ##
##                                                                            ##
################################################################################
sub checkDIR()
{
    # Check Result Directory and Free Space
    printLOG('checkDIR', "Parse and Check Result Directory");

    # 1. Parse User Directory
    # --------------------------------------------------------------------------
    $gFName{'RESULT_DIR'} = "$gFName{'DATA_DIR'}/$gENV{'DB_NAME'}_$gENV{'CLT_TIME'}";
    printLOG('checkDIR', "Result Directory Set to [$gFName{'RESULT_DIR'}]");


    # 2. Check Result Directory
    # --------------------------------------------------------------------------
    # Rename Existing Directory
    if(-d $gFName{'RESULT_DIR'})
    {
        my $bakSeq = 1;
        while(-d "$gFName{'RESULT_DIR'}.$bakSeq")
        {
            $bakSeq ++;
        }
        rename($gFName{'RESULT_DIR'}, "$gFName{'RESULT_DIR'}.$bakSeq");
    }
    # Create New Result Directory
    mkdir($gFName{'RESULT_DIR'});


    # 3. Move Previour Files to New Result Directory
    # --------------------------------------------------------------------------
    printLOG('checkDIR', "Move Previour Files to New Result Directory", 'L');
    logADM('MOVE', "$gFName{'RESULT_DIR'}/$gFName{'LOGFILE'}");
    if(-f "$gFName{'DBI_TRACE_FILE'}")
    {
        rename "$gFName{'DBI_TRACE_FILE'}", "$gFName{'RESULT_DIR'}/$gFName{'DBI_TRACE_FILE'}";
        $gFName{'DBI_TRACE_FILE'} = "$gFName{'RESULT_DIR'}/$gFName{'DBI_TRACE_FILE'}";
    }


    # 4. Check Free Space of Result Directory, at Least 1 GB Free
    # --------------------------------------------------------------------------
    printLOG('checkDIR', "Check Free Space of Result Directory");
    my $dirFree = getDirFree($gFName{'RESULT_DIR'});

    if($dirFree < 1024)
    {
        die "Result Directory Free Space [$dirFree MB)], not Meet Requirement [1024 MB]";
    }
    else
    {
        printLOG('checkDIR', "Result Directory Free Space [$dirFree MB)], Meet Requirement");
    }
}

################################################################################
##                                                                            ##
## checkSSH: Check SSH Equivalent                                             ##
##                                                                            ##
################################################################################
sub checkSSH()
{
    # Default use Listen Mode
    $gENV{'REMOTE_LOGIN'} = 'MANUAL';

    # Means on Single Instance Database
    if($gENV{'INSTANCE_COUNT'} == 1)
    {
        printLOG('checkSSH', 'for Non-RAC Database, No Need to Check SSH Equivalent');
    }
    # Means on Windows RAC
    elsif($gENV{'OS_TYPE'} eq "MSWin32")
    {
        printLOG('checkSSH', 'for Windows RAC, in Listening Mode, Manual Command Must be Ran Later');
    }
    # Means No SSH Found
    elsif(execOS('which ssh 2>/dev/null') eq '')
    {
        printLOG('checkSSH', 'No SSH, in Listening Mode, Manual Command Must be Ran Later');
    }
    # Means on Non-Windows RAC, with SSH Found
    else
    {
        printLOG('checkSSH', "SSH Found, Check user equivalent");

        # Check Login Directly without Password
        my $ckFail = 0;
        foreach my $osNam (keys %osInst)
        {
            # Remote Node, Check for Direct Login
            if($osNam ne $gENV{'HOSTNAME'})
            {
                printLOG('checkSSH', "Attempt to Login Remote [$osNam]");
                my @sshTest = execOS("ssh -n -q -o 'PasswordAuthentication=no StrictHostKeyChecking=no' $osNam echo 'OK' 2>/dev/null", 'ARRAY');
                if((not scalar @sshTest) or $sshTest[$#sshTest] eq '')
                {
                    @sshTest = execOS("ssh -n -q -o PasswordAuthentication=no $osNam echo 'OK' 2>/dev/null", 'ARRAY');
                }
                if((not scalar @sshTest) or $sshTest[$#sshTest] eq '')
                {
                    $ckFail ++;
                }
            }
        }

        if($ckFail == 0)
        {
            $gENV{'REMOTE_LOGIN'} = 'EQUAL';
        }
        # Not all Node can Login Direct
        elsif($gENV{'QUIET_MODE'} == 0)
        {
            if($gENV{'OS_TYPE'} eq 'hpux')
            {
                $gENV{'REMOTE_LOGIN'} = 'LISTEN';
                printLOG('checkSSH', 'HP-UX Server and User Equivalent not Set, use Lieten Mode');
            }
            elsif(execOS('which setsid 2>/dev/null') eq '')
            {
                $gENV{'REMOTE_LOGIN'} = 'LISTEN';
                printLOG('checkSSH', 'Cannot use setsid to Perform Remote Access, use Lieten Mode');
            }
            else
            {
                printLOG('checkSSH', 'User equivalent is not configured');
                printLOG('checkSSH', 'You can Choose : ');
                printLOG('checkSSH', "  P: [Password Mode] Use Password to Login Remote and Collect Data");
                printLOG('checkSSH', "  L: [Listener Mode] You Must Run Command on Remote Manually (it's Default)");

                writeTime('BEGINER');
                my $osMsg = 'NONE';
                until($osMsg =~ m/\A[PL]?\z/)
                {
                    printLOG('checkSSH', "====> Mode Selection [$osMsg]: ", 'N');
                    $osMsg = uc(<>);
                    $osMsg =~ s/\r|\n//g;
                }
                writeTime('INPUT.SSHMODE');

                if ($osMsg eq 'L' or $osMsg eq '')
                {
                    $gENV{'REMOTE_LOGIN'} = 'LISTEN';
                    printLOG('checkSSH', 'We will listened in the session, wait scripts to be ran in other nodes');
                }
                else
                {
                    $gENV{'REMOTE_LOGIN'} = 'PSWD';

                    # Password is Same ?
                    # Ask if the Node > 2, Remote > 1
                    if($gENV{'INSTANCE_COUNT'} > 2)
                    {
                        $osMsg = 'X';
                        writeTime('BEGINER');
                        until($osMsg =~ m/\A[YN]\z/)
                        {
                            printLOG('checkSSH', 'Does all the nodes have same password (Y/N) ? ====> ', 'N');
                            $osMsg = uc(<>);
                            $osMsg =~ s/\r|\n//g;
                        }
                        writeTime('INPUT.SAMEPSWD');
                    }
                    else
                    {
                        $osMsg = 'Y';
                    }

                    # Input Same Password
                    if($osMsg eq 'Y')
                    {
                        printLOG('checkSSH', 'OS User Login Password ====> ', 'N');
                        writeTime('BEGINER');
                        $osMsg = <>;
                        $osMsg =~ s/\r|\n//g;
                        until($osMsg =~ m/\A[^\s]+\z/)
                        {
                            printLOG('checkSSH', "Blank Char is not Allow [$osMsg] ====> ", 'N');
                            $osMsg = <>;
                            $osMsg =~ s/\r|\n//g;
                        }
                        writeTime('INPUT.PSWD');
                        printLOG('checkSSH', 'OS Password ['.$osMsg.']', 'L');
                        foreach my $osNam (keys %osInst)
                        {
                            $osPswd{$osNam} = $osMsg;
                        }
                    }
                    else
                    {                                 # Servers use Different Passwords
                        foreach my $osNam (keys %osInst)
                        {
                            if($osNam ne $gENV{'HOSTNAME'})
                            {
                                printLOG('checkSSH', "OS Login Password for [$osNam] ====> ", 'N');
                                writeTime('BEGINER');
                                $osMsg = <>;
                                $osMsg =~ s/\r|\n//g;
                                until($osMsg =~ m/\A[^\s]+\z/)
                                {
                                    printLOG('checkSSH', "Blank Char is not Allow [$osMsg] ====> ", 'N');
                                    $osMsg = <>;
                                    $osMsg =~ s/\r|\n//g;
                                }
                                writeTime('INPUT.PSWD');
                                $osPswd{$osNam} = $osMsg;
                                printLOG('checkSSH', 'OS Password for ['.$osNam.'] is ['.$osMsg.']', 'L');
                            }
                        }
                    }
                }
            }
        }
    }
}

################################################################################
##                                                                            ##
## getALoc: Get Alert File Location                                           ##
##                                                                            ##
################################################################################
sub getALoc()
{
    printLOG('getALoc', 'Get Alert Locations');

    # Init ASM Alert Variable
    foreach (%osInst)
    {
        $asmAlert{$_} = 'NONE';
    }

    # SQL to Get Alert
    my $sqlAlert = q{SELECT I.HOST_NAME||'|'||B.VALUE||'/alert_'||I.INSTANCE_NAME||'.log' SQL_RESULT FROM GV$DIAG_INFO B,GV$INSTANCE I WHERE B.INST_ID=I.INST_ID AND B.NAME='Diag Trace'};

    # Get File Location of DB Alert
    my $sqlRes = queryDB($sqlAlert);
    foreach my $resLine (@{$sqlRes})
    {
        my ($osNam, $fNam) = split(/\|/, $resLine->[0]);
        $dbAlert{$osNam} = $fNam;
        printLOG('getALoc', "Get DB Alert [$fNam] for Node [$osNam]");
    }

    # Get File Location of ASM Alert
    if($gENV{'ASM_SID'} ne 'NONE')
    {
        # Setting ASM Environment
        $ENV{'ORACLE_SID'}  = $gENV{'ASM_SID'};
        $ENV{'ORACLE_HOME'} = $gENV{'ASM_HOME'};

        # Connect ASM Instance
        connDB('ASM', $gENV{'ASM_USER'}, $gENV{'ASM_PSWD'}, $gENV{'ASM_SERV'});

        # Execute SQL to Get ASM Alert
        $sqlRes = queryDB($sqlAlert);
        foreach my $resLine (@{$sqlRes})
        {
            my ($osNam, $fNam) = split(/\|/, $resLine->[0]);
            $asmAlert{$osNam} = $fNam;
            printLOG('getALoc', "Get ASM Alert [$fNam] for Node [$osNam]");
        }

        # Execute SQL to Get ASM Diag
        $sqlRes = queryDB(q{SELECT VALUE FROM V$PARAMETER WHERE NAME = 'diagnostic_dest'});
        if (defined $sqlRes->[0]->[0] and $sqlRes->[0]->[0] ne '')
        {
            $gENV{'ASM_DIAG'} = $sqlRes->[0]->[0];
            printLOG('getALoc', "Get ASM Diagnostic Dest [$gENV{'ASM_DIAG'}]");
        }

        # Restore Oracle Environment
        $ENV{'ORACLE_SID'}  = $gENV{'ORACLE_SID'};
        $ENV{'ORACLE_HOME'} = $gENV{'ORACLE_HOME'};
        connDB('DB', $gENV{'DB_USER'}, $gENV{'DB_PSWD'}, $gENV{'DB_SERV'});
    }
}

################################################################################
##                                                                            ##
## cltASMDat: Get ASM-Related Data                                            ##
##                                                                            ##
################################################################################
sub cltASMDat()
{
    printLOG('cltASMDat', 'Begin ASM-Related Data Collection');
    writeTime('BEGINER');

    # Collect ASM-Related Data if ASM Instance Found
    if($gENV{'ASM_SID'} eq 'NONE')
    {
        printLOG('cltASMDat', 'No ASM Instance Found for Current DB System');
    }
    else
    {
        # Setting ASM Environment
        $ENV{'ORACLE_SID'}  = $gENV{'ASM_SID'};
        $ENV{'ORACLE_HOME'} = $gENV{'ASM_HOME'};

        # Connect ASM Instance
        connDB('ASM', $gENV{'ASM_USER'}, $gENV{'ASM_PSWD'}, $gENV{'ASM_SERV'});
        printLOG('cltASMDat', 'Connected to ASM Instance');

        # Collect ASM Parameters
        $gENV{'INST_TYPE'} = 'ASM';
        collectDB('RD_DB_PAR');
        collectDB('RD_DB_SPPAR');
        $gENV{'INST_TYPE'} = 'DB';

        # Restore Oracle Environment
        $ENV{'ORACLE_SID'}  = $gENV{'ORACLE_SID'};
        $ENV{'ORACLE_HOME'} = $gENV{'ORACLE_HOME'};
        connDB('DB', $gENV{'DB_USER'}, $gENV{'DB_PSWD'}, $gENV{'DB_SERV'});
        printLOG('cltASMDat', 'Connection Reset to DB Instance');
    }

    writeTime('cltASMDat');
    printLOG('cltASMDat', 'Completed ASM-Related Data Collection');
}

################################################################################
##                                                                            ##
## cltNodRes: Collect Node Related Resource                                   ##
##                                                                            ##
################################################################################
sub cltNodRes()
{
    printLOG('cltNodRes', 'Begin Node Resources Collection');
    writeTime('BEGINER');

    # Open Network Socket
    my ($mSocket, $mSelect) = openSocket($gENV{'LISTEN_PORT'});

    # Set toRun List
    my %toRun = %osInst;

    # Automatic Running Current Node
    printLOG('cltNodRes', "Starting Collection Robot on Local [$gENV{'HOSTNAME'}]");
    execOS(qq{$ENV{'PERL_EXEC'} $gFName{'LIB_DIR'}/$gFName{'NODE_SCRIPT'} 127.0.0.1 $gENV{'LISTEN_PORT'} 1>$gFName{'RESULT_DIR'}/$gFName{'NOHUP_LOG'} 2>&1}, 'Background');
    delete $toRun{$gENV{'HOSTNAME'}};

    # Get Host IP/Name
    my $nodeIP = $gENV{'HOSTNAME'};
    if($gENV{'HOSTIP'} ne '127.0.0.1' and $gENV{'HOSTIP'} =~ m/\A\d+\.\d+\.\d+\.\d+\z/)
    {
        $nodeIP = $gENV{'HOSTIP'};
        printLOG('cltNodRes', "Current Node IP Address [$nodeIP]");
    }

    # Send Node Script to Remote and Execute
    if($gENV{'REMOTE_LOGIN'} eq 'EQUAL')
    {
        foreach my $osNam (keys %toRun)
        {
            # 1. Sent Lib to Remote
            my $osMsg = "";
            my $fileList = '';
            printLOG('cltNodRes', "Sent Library [$gFName{'LIB_TOOLS'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{scp $gFName{'LIB_DIR'}/$gFName{'LIB_TOOLS'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'LIB_TOOLS'}";
            printLOG('cltNodRes', "Sent Library [$gFName{'LIB_DBTOOL'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{scp $gFName{'LIB_DIR'}/$gFName{'LIB_DBTOOL'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'LIB_DBTOOL'}";
            printLOG('cltNodRes', "Sent Library [$gFName{'LIB_CONFIG'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{scp $gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'LIB_CONFIG'}";
            foreach my $cltItem (keys %gOSCollect)
            {
                if($gOSCollect{$cltItem} eq 'ENABLE')
                {
                    printLOG('cltNodRes', "Sent Library [$cltItem.pm] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
                    $osMsg = $osMsg.execOS(qq{scp $gFName{'LIB_DIR'}/$cltItem.pm $osNam:/tmp/ 1>/dev/null});
                    $fileList = $fileList." $cltItem.pm";
                }
            }

            # 2. Sent Node Script to Remote
            printLOG('cltNodRes', "Sent Robot [$gFName{'NODE_SCRIPT'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{scp $gFName{'LIB_DIR'}/$gFName{'NODE_SCRIPT'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'NODE_SCRIPT'}";

            # 3. Check File Sending Error
            if ($osMsg ne '')
            {
                die "Sent Error : [$osMsg]";
            }

            # 4. Check Env
            my $envSetting = '';
            # Check [.bash_profile]
            $osMsg = execOS(qq{ssh $osNam 'ls ~/.bash_profile 2>/dev/null'});
            if($osMsg ne '')
            {
                $envSetting = $envSetting.'. ~/.bash_profile;';
            }
            # Check [.profile]
            $osMsg = execOS(qq{ssh $osNam 'ls ~/.profile 2>/dev/null'});
            if($osMsg ne '')
            {
                $envSetting = $envSetting.'. ~/.profile;';
            }
            # Check [.bashrc]
            $osMsg = execOS(qq{ssh $osNam 'ls ~/.bashrc 2>/dev/null'});
            if($osMsg ne '')
            {
                $envSetting = $envSetting.'. ~/.bashrc;';
            }
            # Check [export]
            $osMsg = execOS(qq{ssh $osNam 'TEST_EXPORT=XXX;export TEST_EXPORT 2>/dev/null && echo OK'});
            if($osMsg eq 'OK')
            {
                $envSetting = $envSetting."ORACLE_SID=$toRun{$osNam}->{'NAME'};OH=$gENV{'ORACLE_HOME'};".'ORACLE_HOME=$OH;LIBPATH=$OH/lib32:$OH/lib;LD_LIBRARY_PATH=$LIBPATH;SHLIB_PATH=$LIBPATH;PERL5LIB=$OH/perl/lib:$OH/perl/lib/site_perl:$LIBPATH;export ORACLE_SID ORACLE_HOME LD_LIBRARY_PATH LIBPATH SHLIB_PATH PERL5LIB;';
            }
            # Check [setenv]
            $osMsg = execOS(qq{ssh $osNam 'setenv TEST_SETNENV 2>/dev/null XXX && echo OK'});
            if($osMsg eq 'OK')
            {
                $envSetting = $envSetting."setenv ORACLE_SID $toRun{$osNam}->{'NAME'};setenv ORACLE_HOME $gENV{'ORACLE_HOME'};".'setenv LIBPATH $ORACLE_HOME/lib32:$ORACLE_HOME/lib;setenv LD_LIBRARY_PATH $LIBPATH;setenv SHLIB_PATH $$LIBPATH;setenv PERL5LIB $ORACLE_HOME/perl/lib:$ORACLE_HOME/perl/lib/site_perl:$LIBPATH;';
            }

            # 5. Running Script on Remote
            printLOG('cltNodRes', "Starting collect robot on [$osNam]");
            printLOG('cltNodRes', "Env Settings [$envSetting]", 'L');
            # execOS(qq{ssh $osNam '$envSetting cd /tmp;$ENV{'PERL_EXEC'} $gFName{"NODE_SCRIPT"} $nodeIP $gENV{'LISTEN_PORT'} 1>/tmp/$gFName{"LOGFILE"} 2>&1;unalias rm;rm -f $fileList' 1>/dev/null 2>$gFName{'RESULT_DIR'}/$gFName{'WARN_LOGFILE'}}, 'Background');
            execOS(qq{ssh $osNam '$envSetting cd /tmp;$ENV{'PERL_EXEC'} $gFName{"NODE_SCRIPT"} $nodeIP $gENV{'LISTEN_PORT'};unalias rm;rm -f $fileList'}, 'Background');
        }
    }
    elsif($gENV{'REMOTE_LOGIN'} eq 'PSWD')
    {
        foreach my $osNam (keys %toRun)
        {
            # 1. Make Password File
            printLOG('cltNodRes', "Prepare Remote Password");
            my $tPsF  = "$gFName{'RESULT_DIR'}/.forRemote.ps";
            my $osMsg = execOS(qq{echo 'echo "$osPswd{$osNam}"' > $tPsF; chmod 777 $tPsF});
            my $fileList = '';

            # 2. Sent Lib to Remote
            printLOG('cltNodRes', "Sent Library [$gFName{'LIB_TOOLS'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{scp $gFName{'LIB_DIR'}/$gFName{'LIB_TOOLS'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'LIB_TOOLS'}";
            printLOG('cltNodRes', "Sent Library [$gFName{'LIB_DBTOOL'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{scp $gFName{'LIB_DIR'}/$gFName{'LIB_DBTOOL'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'LIB_DBTOOL'}";
            printLOG('cltNodRes', "Sent Library [$gFName{'LIB_CONFIG'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{scp $gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'LIB_CONFIG'}";
            foreach my $cltItem (keys %gOSCollect)
            {
                if($gOSCollect{$cltItem} eq 'ENABLE')
                {
                    printLOG('cltNodRes', "Sent Library [$cltItem.pm] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
                    $osMsg = $osMsg.execOS(qq{scp $gFName{'LIB_DIR'}/$cltItem.pm $osNam:/tmp/ 1>/dev/null});
                    $fileList = $fileList." $cltItem.pm";
                }
            }

            # 3. Sent Node Script to Remote
            printLOG('cltNodRes', "Sent Robot [$gFName{'NODE_SCRIPT'}] to Remote [$osNam] in [$gENV{'REMOTE_LOGIN'}] Mode");
            $osMsg = $osMsg.execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' scp -o GSSAPIAuthentication='no' $gFName{'LIB_DIR'}/$gFName{'NODE_SCRIPT'} $osNam:/tmp/ 1>/dev/null});
            $fileList = $fileList." $gFName{'NODE_SCRIPT'}";

            # 4. Check File Sending Error
            if ($osMsg ne '')
            {
                die "Sent Error : [$osMsg]";
            }

            # 5. Check Env
            my $envSetting = '';
            # Check [.bash_profile]
            $osMsg = execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' ssh -n -o GSSAPIAuthentication='no' $osNam 'ls ~/.bash_profile 2>/dev/null'});
            if($osMsg ne '')
            {
                $envSetting = $envSetting.'. ~/.bash_profile;';
            }
            # Check [.profile]
            $osMsg = execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' ssh -n -o GSSAPIAuthentication='no' $osNam 'ls ~/.profile 2>/dev/null'});
            if($osMsg ne '')
            {
                $envSetting = $envSetting.'. ~/.profile;';
            }
            # Check [.bashrc]
            $osMsg = execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' ssh -n -o GSSAPIAuthentication='no' $osNam 'ls ~/.bashrc 2>/dev/null'});
            if($osMsg ne '')
            {
                $envSetting = $envSetting.'. ~/.bashrc;';
            }
            # Check [export]
            $osMsg = execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' ssh -n -o GSSAPIAuthentication='no' $osNam 'TEST_EXPORT=XXX;export TEST_EXPORT 2>/dev/null && echo OK'});
            if($osMsg eq 'OK')
            {
                $envSetting = $envSetting."ORACLE_SID=$toRun{$osNam}->{'NAME'};OH=$gENV{'ORACLE_HOME'};".'ORACLE_HOME=$OH;LIBPATH=$OH/lib32:$OH/lib;LD_LIBRARY_PATH=$LIBPATH;SHLIB_PATH=$LIBPATH;PERL5LIB=$OH/perl/lib:$OH/perl/lib/site_perl:$LIBPATH;export ORACLE_SID ORACLE_HOME LD_LIBRARY_PATH LIBPATH SHLIB_PATH PERL5LIB;';
            }
            # Check [setenv]
            $osMsg = execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' ssh -n -o GSSAPIAuthentication='no' $osNam 'setenv TEST_SETNENV XXX 2>/dev/null && echo OK'});
            if($osMsg eq 'OK')
            {
                $envSetting = $envSetting."setenv ORACLE_SID $toRun{$osNam}->{'NAME'};setenv ORACLE_HOME $gENV{'ORACLE_HOME'};".'setenv LIBPATH $ORACLE_HOME/lib32:$ORACLE_HOME/lib;setenv LD_LIBRARY_PATH $LIBPATH;setenv SHLIB_PATH $$LIBPATH;setenv PERL5LIB $ORACLE_HOME/perl/lib:$ORACLE_HOME/perl/lib/site_perl:$LIBPATH;';
            }

            # 6. Running Script on Remote
            printLOG('cltNodRes', "Starting collect robot on [$osNam]");
            printLOG('cltNodRes', "Env Settings [$envSetting]", 'L');
            # execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' ssh -n -o GSSAPIAuthentication='no' $osNam '$envSetting cd /tmp;$ENV{'PERL_EXEC'} $gFName{"NODE_SCRIPT"} $nodeIP $gENV{'LISTEN_PORT'} 1>/tmp/$gFName{"LOGFILE"} 2>&1;unalias rm;rm -f $fileList' 1>/dev/null 2>$gFName{'RESULT_DIR'}/$gFName{'WARN_LOGFILE'}}, 'Background');
            execOS(qq{setsid env SSH_ASKPASS='$tPsF' DISPLAY='none:0' ssh -n -o GSSAPIAuthentication='no' $osNam '$envSetting cd /tmp;$ENV{'PERL_EXEC'} $gFName{"NODE_SCRIPT"} $nodeIP $gENV{'LISTEN_PORT'};unalias rm;rm -f $fileList'}, 'Background');

            # 7. Remove Temp Password File
            unlink($tPsF);
        }
    }
    else
    {
        printLOG('cltNodRes', "Do Nothing Mode [$gENV{'REMOTE_LOGIN'}]");
    }

    # Open Result File
    my %FD;
    foreach (keys %gResult)
    {
        if($gResult{$_}->{'CLASS'} =~ m/(OS|CT)/)
        {
            $FD{$_} = openResult($_);
        }
    }

    # Init Temporary Variables
    my %cNum;
    foreach(keys %FD)
    {
        $cNum{$_} = 0;
    }

    # Init Variable
    my $mTip = 0;         # Manual Tips, +1 Per Seconds When no Data, Give Manual Tips When greater than 60 (1 Minutes)
    %toRun = %osInst;     # [Value = -1] Means in Collection

    # Collect Node Data
    printLOG('cltNodRes', 'Loop to read node resource informations');
    while(scalar %toRun)
    {
        # Check can Read Data on Network
        foreach my $fHand ($mSelect->can_read(1))
        {
            $mTip = 0;

            # Accept New Connection
            if ($fHand == $mSocket)
            {
                my $newConn = $mSocket->accept();
                $mSelect->add($newConn);
            }
            else
            {                       # Read Data
                while (defined (my $netLine = $fHand->getline))
                {
                    # Split Network Messages
                    $netLine =~ s/\r|\n//g;
                    $netLine = decodeData('UTF8', $netLine);
                    my ($mTyp, $osNam, $mDat) = split(/\|/, $netLine, 3);
                    if(not defined $osNam)
                    {
                        printLOG('NODE_WARN', "Wrong Format [$netLine]");
                        next;
                    }

                    # Process Message
                    if($mTyp eq 'RD_DB_ALERT'
                    or $mTyp eq 'RD_DB_LSNR'
                    or $mTyp eq 'RD_DB_EXTINST'
                    or $mTyp eq 'BX_BATCH_CONTROL')
                    {
                        # Get File Handler
                        my $FH = $FD{$mTyp};
                        $cNum{$mTyp} ++;
                        print $FH "$mDat\n";
                    }
                    elsif($mTyp eq 'RD_DB_ALERT_TRACE')
                    {
                        # Get File Handler
                        my $FH = $FD{$mTyp};
                        $cNum{$mTyp} ++;

                        my ($trcTime, $erInst, $erCod, $trcType, $trcFile) = split(/,/, $mDat);
                        print $FH "TO_DATE('$trcTime','YYYY-MM-DD HH24:MI:SS'),'$erInst','$erCod','$trcType','$trcFile'\n";

                        open $FD{$trcFile}, ">:unix:encoding(UTF8)", "$gFName{'RESULT_DIR'}/$trcFile"
                        or printLOG('NODE_MSG', "$osNam -> Cannot Write Trace [$gFName{'RESULT_DIR'}/$trcFile], Reason [$!]\n");
                    }
                    elsif(exists $gResult{$mTyp})
                    {
                        # Get File Handler
                        my $FH = $FD{$mTyp};
                        $cNum{$mTyp} ++;
                        print $FH $osInst{$osNam}->{'ID'}.",$mDat\n";
                    }
                    elsif(exists $FD{$mTyp})
                    {
                        # Get File Handler
                        my $FH = $FD{$mTyp};
                        print $FH "$mDat\n";
                    }
                    elsif($mTyp eq 'GET_FILE')
                    {
                        # Sent DG Collection File
                        sendFile("$gFName{'LIB_DIR'}/$gFName{'NODE_SCRIPT'}", $fHand);
                        sendFile("$gFName{'LIB_DIR'}/$gFName{'LIB_TOOLS'}", $fHand);
                        sendFile("$gFName{'LIB_DIR'}/$gFName{'LIB_DBTOOL'}", $fHand);
                        sendFile("$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}", $fHand);
                        foreach my $cltItem (keys %gOSCollect)
                        {
                            if($gOSCollect{$cltItem} ne 'ENABLE')
                            {
                                printLOG('WARN', "Collection Item [$cltItem] not Enable [$gOSCollect{$cltItem}]");
                            }
                            elsif(-f "$gFName{'LIB_DIR'}/$cltItem.pm")
                            {
                                sendFile("$gFName{'LIB_DIR'}/$cltItem.pm", $fHand);
                            }
                            else
                            {
                                printLOG('WARN', "Cannot find [$gFName{'LIB_DIR'}/$cltItem.pm]");
                            }
                        }
                        $fHand->send("COMPLETED\n");
                        $fHand->flush;
                        printLOG('NODE_FILE', "$osNam -> All Node File have been sent Remote");
                        last;
                    }
                    elsif($mTyp eq 'GET_PARAMS')
                    {
                        $fHand->send("UNIQUE_NAME|$gENV{'UNIQUE_NAME'}\n");
                        $fHand->send("ORACLE_HOME|$gENV{'ORACLE_HOME'}\n");
                        $fHand->send("LSN_CHARSET|$gENV{'LSN_CHARSET'}\n");
                        $fHand->send("ALT_CHARSET|$gENV{'ALT_CHARSET'}\n");
                        $fHand->send("OS_CHARSET|$gENV{'OS_CHARSET'}\n");
                        $fHand->send("OSERR_TIME|$gENV{'OSERR_TIME'}\n");
                        $fHand->send("ALERT_TIME|$gENV{'ALERT_TIME'}\n");
                        $fHand->send("LSNR_TIME|$gENV{'LSNR_TIME'}\n");
                        $fHand->send("ORACLE_ALERT|$dbAlert{$osNam}\n");
                        $fHand->send("ASM_ALERT|$asmAlert{$osNam}\n");
                        $fHand->send("ASM_DIAG|$gENV{'ASM_DIAG'}\n");
                        $fHand->send("PATH|$gENV{'PATH'}\n");
                        $fHand->send("COMPLETED\n");
                        $fHand->flush;
                        printLOG('NODE_PARAMS', "$osNam -> Node Parameters have been sent Remote");
                    }
                    elsif($mTyp eq 'COMPLETE')
                    {
                        delete $toRun{$osNam};
                        $mSelect->remove($fHand);
                        my $oMsg = '';
                        $oMsg = ", Running is [".join(',', (sort keys %toRun))."]" if (scalar %toRun);
                        printLOG($mTyp, "$osNam -> Collection Completed$oMsg");

                        # If not Equal with SSH, then set Tip to 59
                        if($gENV{'REMOTE_LOGIN'} ne 'EQUAL')
                        {
                            $mTip = 59;
                        }
                    }
                    elsif($mTyp eq 'CHECKER')
                    {
                        my ($rTyp, $hNam) = split(/\:/, $mDat);
                        if($rTyp ne 'NODE_RESOURCE')
                        {
                            printLOG('Checker', "$osNam -> Check Failed : Remote Script is not NodeRobot [$rTyp]");
                            $fHand->send("Check Failed : Remote Script is not NodeRobot [$rTyp]\n");
                        }
                        elsif(exists $toRun{$hNam})
                        {
                            if($toRun{$hNam} == -1)
                            {
                                printLOG('Checker', "$osNam -> Check Failed : Remote Node is Already in Collection");
                                $fHand->send("Check Failed : Remote Node is Already in Collection");
                            }
                            else
                            {
                                $toRun{$hNam} = -1;
                                printLOG('Checker', "$osNam -> Check Passed for [$hNam]");
                                $fHand->send("PASSED\n");
                            }
                        }
                        else
                        {
                            my $nodeList = join(',', (sort keys %toRun));
                            printLOG('Checker', "$osNam -> Check Failed : [$hNam] not in Remote Node List [$nodeList]");
                            $fHand->send("Check Failed : [$hNam] not in Remote Node List [$nodeList]\n");
                        }
                    }
                    elsif($mTyp eq 'TRACE_OVER')
                    {
                        close $FD{$mDat};
                        delete $FD{$mDat};
                    }
                    elsif($mTyp eq 'STATUS')
                    {
                        my ($kNam, $kLin, $kMsg) = split(/\|/, $mDat);
                        if(not defined $kMsg)
                        {
                            $kMsg = $kLin;
                            $kLin = $cNum{$kNam};
                        }
                        addStatus($kNam, $kLin, $kMsg);
                    }
                    elsif($mTyp eq 'LOG')
                    {
                        printLOG('NodeLog', "$osNam -> $mDat", 'L');
                    }
                    else
                    {
                        printLOG($mTyp, "$osNam -> $mDat");
                    }
                }
            }
        }

        # Give Tips if Remote maybe Down or Error
        if($mTip >= 60)
        {
            if($gENV{'QUIET_MODE'} == 1)
            {
                printLOG('cltNodRes', "Remote List: ".join(', ', (sort keys %toRun)));
                print "REQUIRE_SUB_NODE_DATA\n";
            }
            else
            {
                printLOG('cltNodRes', '');
                printLOG('cltNodRes', '<=============================[ Attention ]=============================>');
                printLOG('cltNodRes', ' Follow Command Must Manual Run on Remote Node');
                printLOG('cltNodRes', " Remote List: ".join(', ', (sort keys %toRun)));
                printLOG('cltNodRes', '<=======================================================================>');
                showCommand('NODE_SCRIPT');
            }
            $mTip = -1;
        }
        elsif($mTip != -1)
        {
            $mTip ++;
        }
    }

    # Close all Result File
    foreach(keys %FD)
    {
        close $FD{$_};
    }

    writeTime('cltNodRes');
    printLOG('cltNodRes', 'Complete Node Resources Collection');
}

################################################################################
##                                                                            ##
## cltAWRSqlS: Collect AWR SQL Stats                                          ##
##                                                                            ##
################################################################################
sub cltAWRSqlS()
{
    printLOG('cltAWRSqlS', 'Collect AWR SQL Statistics');
    writeTime('BEGINER');

    # Check Status
    if($gResult{'RD_DB_AWR_SQLSTAT'}->{'STATUS'} ne 'ENABLE')
    {
        printLOG('cltAWRSqlS', "Ignore Collection for [RD_DB_AWR_SQLSTAT], due to status [$gResult{'RD_DB_AWR_SQLSTAT'}->{'STATUS'}]");
        addStatus('RD_DB_AWR_SQLSTAT', 0, "Ignore by Status [$gResult{'RD_DB_AWR_SQLSTAT'}->{'STATUS'}]");
        writeTime('RD_DB_AWR_SQLSTAT');
        return 1;
    }

    # Prepare for SQL Statement
    my @sqlResult = collectPLSQL(qq{DECLARE
                                      -- Define FMS List Type and Varible
                                      TYPE L_FMS_LIST_TYPE IS TABLE OF VARCHAR2(64) INDEX BY VARCHAR2(64);
                                      L_FMS_LIST_SQLID     L_FMS_LIST_TYPE;
                                      L_FMS_LIST_SQLCNT    L_FMS_LIST_TYPE;
                                    BEGIN
                                      -- Get FMS List
                                      FOR X IN (SELECT FMS, HIGH_SQL, COUNT(*) SQL_CNT
                                                  FROM (SELECT FMS
                                                             , LAST_VALUE(SQL_ID) OVER (PARTITION BY FMS ORDER BY TYPE DESC, ET DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) HIGH_SQL
                                                          FROM (SELECT CASE WHEN S.FORCE_MATCHING_SIGNATURE > 0 THEN TO_CHAR(S.FORCE_MATCHING_SIGNATURE) ELSE S.SQL_ID END FMS
                                                                     , S.SQL_ID
                                                                     , NVL2(T.SQL_ID, 1, 0) + NVL2(P.SQL_ID, 1, 0) TYPE
                                                                     , SUM(S.ELAPSED_TIME_DELTA) ET
                                                                  FROM DBA_HIST_SQLSTAT S
                                                                     , (SELECT DISTINCT SQL_ID
                                                                          FROM DBA_HIST_SQLTEXT
                                                                         WHERE DBID = $gENV{'DBID'}
                                                                       ) T
                                                                     , (SELECT DISTINCT SQL_ID
                                                                          FROM DBA_HIST_SQLTEXT
                                                                         WHERE DBID = $gENV{'DBID'}
                                                                       ) P
                                                                 WHERE S.DBID     = $gENV{'DBID'}
                                                                   AND S.SNAP_ID >= $gENV{'MIN_SNAP'}
                                                                   AND S.SQL_ID   = T.SQL_ID(+)
                                                                   AND S.SQL_ID   = P.SQL_ID(+)
                                                                 GROUP BY CASE WHEN S.FORCE_MATCHING_SIGNATURE > 0 THEN TO_CHAR(S.FORCE_MATCHING_SIGNATURE) ELSE S.SQL_ID END, S.SQL_ID, T.SQL_ID, P.SQL_ID
                                                               )
                                                       )
                                                 GROUP BY FMS, HIGH_SQL
                                               )
                                      LOOP
                                        L_FMS_LIST_SQLID(X.FMS)  := X.HIGH_SQL;
                                        L_FMS_LIST_SQLCNT(X.FMS) := X.SQL_CNT;
                                      END LOOP;
                                      -- Loop to Get SQL Statistics
                                      FOR X IN (SELECT INST_NO, BTIME, MIN(SNAP_ID) BEGIN_SNAP, MAX(SNAP_ID) END_SNAP, SUM(VALUE) DBT
                                                  FROM (SELECT SN.INSTANCE_NUMBER INST_NO
                                                             , TRUNC(SN.BEGIN_INTERVAL_TIME, 'HH24') BTIME
                                                             , SN.SNAP_ID
                                                             , VALUE - LAG(VALUE) OVER(PARTITION BY SN.INSTANCE_NUMBER ORDER BY SN.SNAP_ID) VALUE
                                                          FROM DBA_HIST_SYS_TIME_MODEL TM
                                                             , DBA_HIST_SNAPSHOT       SN
                                                         WHERE SN.DBID      = $gENV{'DBID'}
                                                           AND SN.SNAP_ID  >= $gENV{'MIN_SNAP'}
                                                           AND SN.DBID      = TM.DBID
                                                           AND SN.SNAP_ID   = TM.SNAP_ID
                                                           AND SN.INSTANCE_NUMBER = TM.INSTANCE_NUMBER
                                                           AND TM.STAT_NAME = 'DB time') T
                                                 WHERE T.VALUE > 0              -- Get DB Time Bigger than 0  ( Ignore 0 )
                                                 GROUP BY INST_NO, BTIME)
                                      LOOP
                                        FOR Y IN (SELECT FMS, SQLID, CNT||','''||MOD||''','''||PUSR||''','||VCNT||','||FET||','||SORT||','||EXEC||','||LOAD||','||INV||','||PCAL||','||DRD||','||BGET||','||ROWP||','||CTIM||','||ETIM||','||IOWT||','||CLWT||','||APWT||','||CCWT||','||PHV SQL_RESULT
                                                    FROM (SELECT FMS
                                                               , MAX(SQL_ID)               SQLID
                                                               , COUNT(DISTINCT SQL_ID)    CNT
                                                               , MAX(MAX_PHV)              PHV
                                                               , MAX(MAX_MOD)              MOD
                                                               , MAX(MAX_PSN)              PUSR
                                                               , SUM(VERSION_COUNT)        VCNT
                                                               , SUM(FETCHES_DELTA)        FET
                                                               , SUM(SORTS_DELTA)          SORT
                                                               , SUM(EXECUTIONS_DELTA)     EXEC
                                                               , SUM(LOADS_DELTA)          LOAD
                                                               , SUM(INVALIDATIONS_DELTA)  INV
                                                               , SUM(PARSE_CALLS_DELTA)    PCAL
                                                               , SUM(DISK_READS_DELTA)     DRD
                                                               , SUM(BUFFER_GETS_DELTA)    BGET
                                                               , SUM(ROWS_PROCESSED_DELTA) ROWP
                                                               , SUM(CPU_TIME_DELTA)       CTIM
                                                               , SUM(ELAPSED_TIME_DELTA)   ETIM
                                                               , SUM(IOWAIT_DELTA)         IOWT
                                                               , SUM(CLWAIT_DELTA)         CLWT
                                                               , SUM(APWAIT_DELTA)         APWT
                                                               , SUM(CCWAIT_DELTA)         CCWT
                                                               , ROUND(100*SUM(ELAPSED_TIME_DELTA)/X.DBT,2) ET_PER_DBT
                                                            FROM (SELECT DECODE(FORCE_MATCHING_SIGNATURE, 0, SQL_ID, TO_CHAR(FORCE_MATCHING_SIGNATURE)) FMS
                                                                       , SQL_ID
                                                                       , FIRST_VALUE(SQL_ID)              OVER (PARTITION BY DECODE(FORCE_MATCHING_SIGNATURE, 0, SQL_ID, TO_CHAR(FORCE_MATCHING_SIGNATURE)) ORDER BY ELAPSED_TIME_DELTA DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) MAX_ID
                                                                       , FIRST_VALUE(PLAN_HASH_VALUE)     OVER (PARTITION BY DECODE(FORCE_MATCHING_SIGNATURE, 0, SQL_ID, TO_CHAR(FORCE_MATCHING_SIGNATURE)) ORDER BY ELAPSED_TIME_DELTA DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) MAX_PHV
                                                                       , FIRST_VALUE(MODULE)              OVER (PARTITION BY DECODE(FORCE_MATCHING_SIGNATURE, 0, SQL_ID, TO_CHAR(FORCE_MATCHING_SIGNATURE)) ORDER BY ELAPSED_TIME_DELTA DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) MAX_MOD
                                                                       , FIRST_VALUE(PARSING_SCHEMA_NAME) OVER (PARTITION BY DECODE(FORCE_MATCHING_SIGNATURE, 0, SQL_ID, TO_CHAR(FORCE_MATCHING_SIGNATURE)) ORDER BY ELAPSED_TIME_DELTA DESC ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) MAX_PSN
                                                                       , VERSION_COUNT
                                                                       , FETCHES_DELTA
                                                                       , SORTS_DELTA
                                                                       , EXECUTIONS_DELTA
                                                                       , LOADS_DELTA
                                                                       , INVALIDATIONS_DELTA
                                                                       , PARSE_CALLS_DELTA
                                                                       , DISK_READS_DELTA
                                                                       , BUFFER_GETS_DELTA
                                                                       , ROWS_PROCESSED_DELTA
                                                                       , CPU_TIME_DELTA
                                                                       , ELAPSED_TIME_DELTA
                                                                       , IOWAIT_DELTA
                                                                       , CLWAIT_DELTA
                                                                       , APWAIT_DELTA
                                                                       , CCWAIT_DELTA
                                                                    FROM DBA_HIST_SQLSTAT
                                                                   WHERE DBID = $gENV{'DBID'}
                                                                     AND INSTANCE_NUMBER = X.INST_NO
                                                                     AND SNAP_ID BETWEEN X.BEGIN_SNAP AND X.END_SNAP
                                                                     AND EXECUTIONS_DELTA > 0        -- Get Executed SQL
                                                                  )
                                                           GROUP BY FMS
                                                           ORDER BY NVL(ETIM,-1) DESC)
                                                   WHERE ROWNUM <= $gENV{'TOP_SQL'}
                                                     AND (ROWNUM <= 10 OR ET_PER_DBT > 1))
                                        LOOP
                                          IF L_FMS_LIST_SQLID.EXISTS(Y.FMS)
                                          THEN
                                             DBMS_OUTPUT.PUT_LINE(L_FMS_LIST_SQLID(Y.FMS)||'|'||X.INST_NO||',TO_TIMESTAMP('''||TO_CHAR(X.BTIME, 'YYYY-MM-DD HH24')||''',''YYYY-MM-DD HH24''),'||X.DBT||','''||Y.FMS||''','''||L_FMS_LIST_SQLID(Y.FMS)||''','||L_FMS_LIST_SQLCNT(Y.FMS)||','||Y.SQL_RESULT);
                                          ELSE
                                             DBMS_OUTPUT.PUT_LINE(Y.SQLID||'|'||X.INST_NO||',TO_TIMESTAMP('''||TO_CHAR(X.BTIME, 'YYYY-MM-DD HH24')||''',''YYYY-MM-DD HH24''),'||X.DBT||','''||Y.FMS||''','''||Y.SQLID||''',1,'||Y.SQL_RESULT);
                                          END IF;
                                        END LOOP;
                                      END LOOP;
                                    END;});

    # Fetch Result Data
    if($DBTools::dbError eq 'COMPLETED')
    {
        # Write Result to File
        my %sqlList;
        my $SQLSF = openResult('RD_DB_AWR_SQLSTAT');
        foreach (@sqlResult)
        {
            my ($sqlID, $sqlStat) = split(/\|/);

            # Add SQL ID to List
            if(not exists $sqlList{$sqlID})
            {
                $sqlList{$sqlID} = 1;
            }

            print $SQLSF $sqlStat."\n";
        }

        # Close Result File
        close $SQLSF;

        # Save Status
        addStatus('RD_DB_AWR_SQLSTAT', $DBTools::dbRows, 'COMPLETED');
        writeTime('RD_DB_AWR_SQLSTAT');

        # Make SQL ID Array
        my @sqlBatch;
        my $currSize  = $gENV{'SQL_BATCH_SIZE'} + 1;
        foreach (keys %sqlList)
        {
            if($currSize <= $gENV{'SQL_BATCH_SIZE'})
            {
                $sqlBatch[$#sqlBatch] = $sqlBatch[$#sqlBatch].",'$_'";
                $currSize ++;
            }
            else
            {
                push(@sqlBatch, "'$_'");
                $currSize = 1;
            }
        }
        foreach (@sqlBatch)
        {
            printLOG('cltAWRSqlS', "SQL Batch: [$_]", 'L');
        }

        # Collect SQL Text in AWR
        &cltAWRSqlT(@sqlBatch);

        # Collect SQL Plan in AWR
        &cltAWRSqlP(@sqlBatch);
    }
    else
    {
        addStatus('RD_DB_AWR_SQLSTAT', 0, $DBTools::dbError);
        writeTime('RD_DB_AWR_SQLSTAT');
    }
}

################################################################################
##                                                                            ##
## cltAWRSqlT: Collect AWR SQL Text                                           ##
##                                                                            ##
################################################################################
sub cltAWRSqlT()
{
    printLOG('cltAWRSqlT', 'Collect AWR SQL Text');
    my @sqlBatch = @_;
    writeTime('BEGINER');

    # Check Status
    if($gResult{'RD_DB_AWR_SQLTEXT'}->{'STATUS'} ne 'ENABLE')
    {
        printLOG('cltAWRSqlT', "Ignore Collection for [RD_DB_AWR_SQLTEXT], due to status [$gResult{'RD_DB_AWR_SQLTEXT'}->{'STATUS'}]");
        addStatus('RD_DB_AWR_SQLTEXT', 0, "Ignore by Status [$gResult{'RD_DB_AWR_SQLTEXT'}->{'STATUS'}]");
        writeTime('RD_DB_AWR_SQLTEXT');
        return 1;
    }

    # Set Long Read Length for CLOB
    $DBTools::dbFH->{LongReadLen} = 10485760;

    # Open Result File
    my $TEXTF = openResult('RD_DB_AWR_SQLTEXT');

    foreach (@sqlBatch)
    {
        my $sqlRes = queryDB("SELECT SQL_ID,NVL(COMMAND_TYPE, -1) COMMAND_TYPE,SQL_TEXT FROM DBA_HIST_SQLTEXT WHERE DBID = $gENV{'DBID'} AND SQL_ID IN ($_)");
        foreach my $sqlLine (@{$sqlRes})
        {
            # Write SQL ID and Command Type
            print $TEXTF "$sqlLine->[0]\n$sqlLine->[1]\n";

            # Write SQL Text
            foreach my $txtLine (split(/\r?\n/, $sqlLine->[2]))
            {
                while($txtLine =~ m/\A(.{2000})([^\s,]*)(\s|,)(.*)\z/)
                {
                    print $TEXTF decodeDB("$1$2$3\n");
                    $txtLine = $4;
                }
                print $TEXTF decodeDB("$txtLine\n");
            }

            # Write Split Line
            print $TEXTF "-----[BMRobot_New_Line]-----\n";
        }

        # Add Collection Status
        addStatus('RD_DB_AWR_SQLTEXT', $DBTools::dbRows, $DBTools::dbError);
    }
    close $TEXTF;

    # re-Set Long Read Length for CLOB
    $DBTools::dbFH->{LongReadLen} = 1048576;
    writeTime('RD_DB_AWR_SQLTEXT');
}

################################################################################
##                                                                            ##
## cltAWRSqlP: Collect AWR SQL Plan                                           ##
##                                                                            ##
################################################################################
sub cltAWRSqlP()
{
    printLOG('cltAWRSqlP', 'Collect AWR SQL Plan');
    my @sqlBatch = @_;
    writeTime('BEGINER');

    # Get SQL Plan
    foreach (@sqlBatch)
    {
        $gENV{'SQL_LIST'} = $_;
        collectDB('RD_DB_AWR_SQLPLAN');
    }
    $gENV{'SQL_LIST'} = '';
    writeTime('RD_DB_AWR_SQLPLAN');

    # Collect Objects in SQL Plan
    if(-f "$gFName{'RESULT_DIR'}/$gResult{'RD_DB_AWR_SQLPLAN'}->{'FILE'}")
    {
        &cltAWRSqlO;
    }
    else
    {
        printLOG('cltAWRSqlO', 'No Plan Found, Ignore Objects (in SQL) Collection');
    }
}

################################################################################
##                                                                            ##
## cltAWRSqlO: Collect AWR SQL Objects                                        ##
##                                                                            ##
################################################################################
sub cltAWRSqlO()
{
    printLOG('cltAWRSqlO', 'Collect AWR SQL Objects');
    writeTime('BEGINER');

    # ==========================================================================
    # Collect Objects in AWR SQL Plan
    #   1. Open Plan File for Read
    #   2. Skip First Header Line
    #   3. Read Plan Data, Make Table List, Index List, Object List
    #   4. Close Plan File
    #   5. Print Original List Size
    #   6. Add More to Table List According to Index List
    #   7. Print Again List Size
    #   8. Add More to Index List According to Table List
    #   9. Print Final List Size
    #  10. Convert Hash List to Array List
    #  11. Get Table-Related Data
    #  12. Get Index-Related Data
    #  13. Get Object/Segment/Part_Key Data
    # ==========================================================================

    # 1. Open Plan File for Read
    # --------------------------------------------------------------------------
    open PLANF, '<:unix:encoding(UTF8)', "$gFName{'RESULT_DIR'}/$gResult{'RD_DB_AWR_SQLPLAN'}->{'FILE'}"
    or die "Cannot Read File [$gFName{'RESULT_DIR'}/$gResult{'RD_DB_AWR_SQLPLAN'}->{'FILE'}], Reason [$!]";


    # 2. Skip First Header Line
    # --------------------------------------------------------------------------
    <PLANF>;


    # 3. Read Plan Data, Make Table List, Index List, Object List
    # --------------------------------------------------------------------------
    my %tLst;
    my %iLst;
    my %oLst;
    while (<PLANF>)
    {
        # Remove Newline and Single Quote;
        s/\r|\n|'//g;
        my @pLine = split(/,/);

        # Get Object Information
        if($pLine[10] =~ m/TABLE/ && $pLine[7] ne 'VECSYS'  && $pLine[7] ne 'SYS')
        {
            $tLst{$pLine[7]}->{$pLine[8]} = 1;
            $oLst{$pLine[7]}->{$pLine[8]} = 1;
        }
        elsif($pLine[10] =~ m/INDEX/ && $pLine[7] ne 'VECSYS'  && $pLine[7] ne 'SYS')
        {
            $iLst{$pLine[7]}->{$pLine[8]} = 1;
            $oLst{$pLine[7]}->{$pLine[8]} = 1;
        }
    }


    # 4. Close Plan File
    # --------------------------------------------------------------------------
    close PLANF;


    # 5. Print Original List Size
    # --------------------------------------------------------------------------
    printLOG('cltAWRSqlO', "===============================[ Original Size ]================================", 'L');
    foreach (keys %tLst)
    {
        printLOG('cltAWRSqlO', "Table Count for [$_] is [".(keys(%{$tLst{$_}}) + 1)."]", 'L');
    }
    foreach (keys %iLst)
    {
        printLOG('cltAWRSqlO', "Index Count for [$_] is [".(keys(%{$iLst{$_}}) + 1)."]", 'L');
    }
    printLOG('cltAWRSqlO', "================================================================================", 'L');


    # 6. Add More to Table List According to Index List
    # --------------------------------------------------------------------------
    my @uLst = keys %iLst;
    for(my $x = 0; $x <= $#uLst; $x ++)
    {
        my @nLst = keys %{$iLst{$uLst[$x]}};
        for(my $y = 0; $y <= $#nLst; $y += $gENV{'SQL_BATCH_SIZE'})
        {
            # Get SQL List for Current Batch
            my $inList = "'$nLst[$y]'";
            my $maxNum = $y + $gENV{'SQL_BATCH_SIZE'} > $#nLst ? $#nLst : $y + $gENV{'SQL_BATCH_SIZE'};
            for(my $z = $y + 1; $z <= $maxNum; $z ++)
            {
                $inList = "$inList,'$nLst[$z]'"
            }

            # Get Table Data
            my $sqlRes = queryDB("SELECT OWNER, TABLE_NAME FROM DBA_TABLES WHERE OWNER = '$uLst[$x]' AND TABLE_NAME IN ($inList)");
            foreach my $rLine (@{$sqlRes})
            {
                $tLst{$rLine->[0]}->{$rLine->[1]} = 1;
                $oLst{$rLine->[0]}->{$rLine->[1]} = 1;
            }
        }
    }


    # 7. Print Again List Size
    # --------------------------------------------------------------------------
    printLOG('cltAWRSqlO', "=================================[ Again Size ]=================================", 'L');
    foreach (keys %tLst)
    {
        printLOG('cltAWRSqlO', "Table Count for [$_] is [".(keys(%{$tLst{$_}}) + 1)."]", 'L');
    }
    foreach (keys %iLst)
    {
        printLOG('cltAWRSqlO', "Index Count for [$_] is [".(keys(%{$iLst{$_}}) + 1)."]", 'L');
    }
    printLOG('cltAWRSqlO', "================================================================================", 'L');


    # 8. Add More to Index List According to Table List
    # --------------------------------------------------------------------------
    @uLst = keys %tLst;
    for(my $x = 0; $x <= $#uLst; $x ++)
    {
        my @nLst = keys %{$tLst{$uLst[$x]}};
        for(my $y = 0; $y <= $#nLst; $y += $gENV{'SQL_BATCH_SIZE'})
        {
            # Get SQL List for Current Batch
            my $inList = "'$nLst[$y]'";
            my $maxNum = $y + $gENV{'SQL_BATCH_SIZE'} > $#nLst ? $#nLst : $y + $gENV{'SQL_BATCH_SIZE'};
            for(my $z = $y + 1; $z <= $maxNum; $z ++)
            {
                $inList = "$inList,'$nLst[$z]'"
            }

            # Get Table Data
            my $sqlRes = queryDB("SELECT OWNER, INDEX_NAME FROM DBA_INDEXES WHERE TABLE_OWNER = '$uLst[$x]' AND TABLE_NAME IN ($inList)");
            foreach my $rLine (@{$sqlRes})
            {
                $iLst{$rLine->[0]}->{$rLine->[1]} = 1;
                $oLst{$rLine->[0]}->{$rLine->[1]} = 1;
            }
        }
    }


    # 9. Print Final List Size
    # --------------------------------------------------------------------------
    printLOG('cltAWRSqlO', "=================================[ Final Size ]=================================", 'L');
    foreach (keys %tLst)
    {
        printLOG('cltAWRSqlO', "Table Count for [$_] is [".(keys(%{$tLst{$_}}) + 1)."]", 'L');
    }
    foreach (keys %iLst)
    {
        printLOG('cltAWRSqlO', "Index Count for [$_] is [".(keys(%{$iLst{$_}}) + 1)."]", 'L');
    }
    printLOG('cltAWRSqlO', "================================================================================", 'L');


    # 10. Get Table-Related Data
    # --------------------------------------------------------------------------
    printLOG('cltAWRSqlO', "Collect Table-Related Informations");
    @uLst = keys %tLst;
    for(my $x = 0; $x <= $#uLst; $x ++)
    {
        my @nLst = keys %{$tLst{$uLst[$x]}};
        $gENV{'OBJ_SCHEMA'} = $uLst[$x];
        printLOG('cltAWRSqlO', "Collect Table for [$uLst[$x]], Size [".($#nLst + 1)."]");

        for(my $y = 0; $y <= $#nLst; $y += $gENV{'SQL_BATCH_SIZE'})
        {
            # Get SQL List for Current Batch
            $gENV{'SQL_LIST'} = "'$nLst[$y]'";
            my $maxNum = $y + $gENV{'SQL_BATCH_SIZE'} > $#nLst ? $#nLst : $y + $gENV{'SQL_BATCH_SIZE'};
            for(my $z = $y + 1; $z <= $maxNum; $z ++)
            {
                $gENV{'SQL_LIST'} = "$gENV{'SQL_LIST'},'$nLst[$z]'"
            }

            # Collect Table Stats
            collectDB('RD_DB_TABLES');

            # Collect Column Stats
            collectDB('RD_DB_COLUMNS');

            # Collect Table Partitions
            collectDB('RD_DB_TABPART');

            # Collect Table subPartition
            collectDB('RD_DB_TABSUBPART');
        }
    }


    # 11. Get Index-Related Data
    # --------------------------------------------------------------------------
    printLOG('cltAWRSqlO', "Collect Index-Related Informations");
    @uLst = keys %iLst;
    for(my $x = 0; $x <= $#uLst; $x ++)
    {
        my @nLst = keys %{$iLst{$uLst[$x]}};
        $gENV{'OBJ_SCHEMA'} = $uLst[$x];
        printLOG('cltAWRSqlO', "Collect Index for [$uLst[$x]], Size [".($#nLst + 1)."]");

        for(my $y = 0; $y <= $#nLst; $y += $gENV{'SQL_BATCH_SIZE'})
        {
            # Get SQL List for Current Batch
            $gENV{'SQL_LIST'} = "'$nLst[$y]'";
            my $maxNum = $y + $gENV{'SQL_BATCH_SIZE'} > $#nLst ? $#nLst : $y + $gENV{'SQL_BATCH_SIZE'};
            for(my $z = $y + 1; $z <= $maxNum; $z ++)
            {
                $gENV{'SQL_LIST'} = "$gENV{'SQL_LIST'},'$nLst[$z]'"
            }

            # Collect Index Stats
            collectDB('RD_DB_INDEXES');

            # Collect Index Columns
            collectDB('RD_DB_INDCOL');

            # Collect Index Partition
            collectDB('RD_DB_INDPART');

            # Collect Index subPartition
            collectDB('RD_DB_INDSUBPART');

            # Collect Index Expression
            collectDB('RD_DB_INDEXP');
        }
    }


    # 13. Get Object/Segment/Part_Key Data
    # --------------------------------------------------------------------------
    printLOG('cltAWRSqlO', "Collect Object-Related Informations");
    @uLst = keys %oLst;
    for(my $x = 0; $x <= $#uLst; $x ++)
    {
        my @nLst = keys %{$oLst{$uLst[$x]}};
        $gENV{'OBJ_SCHEMA'} = $uLst[$x];
        printLOG('cltAWRSqlO', "Collect Object for [$uLst[$x]], Size [".($#nLst + 1)."]");

        for(my $y = 0; $y <= $#nLst; $y += $gENV{'SQL_BATCH_SIZE'})
        {
            # Get SQL List for Current Batch
            $gENV{'SQL_LIST'} = "'$nLst[$y]'";
            my $maxNum = $y + $gENV{'SQL_BATCH_SIZE'} > $#nLst ? $#nLst : $y + $gENV{'SQL_BATCH_SIZE'};
            for(my $z = $y + 1; $z <= $maxNum; $z ++)
            {
                $gENV{'SQL_LIST'} = "$gENV{'SQL_LIST'},'$nLst[$z]'"
            }

            # Collect Object Data
            collectDB('RD_DB_OBJECT');

            # Collect Segment Data
            collectDB('RD_DB_SEGMENT');

            # Collect Segment Data
            collectDB('RD_DB_PARTKEY');

            # Collect Segment Data
            collectDB('RD_DB_SUBPARTKEY');
        }
    }

    writeTime('cltAWRSqlO');
}

################################################################################
##                                                                            ##
## cltRACSta: Collect RAC crs_stat                                            ##
##                                                                            ##
################################################################################
sub cltRACSta()
{
    printLOG('cltRACSta', 'Collect RAC crs_stat');
    writeTime('BEGINER');

    # Check Status
    if($gResult{'RD_DB_CRSSTAT'}->{'STATUS'} ne 'ENABLE')
    {
        printLOG('cltRACSta', "Ignore Collection for [RD_DB_CRSSTAT], due to status [$gResult{'RD_DB_CRSSTAT'}->{'STATUS'}]");
        addStatus('RD_DB_CRSSTAT', 0, "Ignore by Status [$gResult{'RD_DB_CRSSTAT'}->{'STATUS'}]");
        writeTime('RD_DB_CRSSTAT');
        return 1;
    }

    # Open Result File
    my $RESF = openResult('RD_DB_CRSSTAT');

    # Initial Variables
    my $crsExe = '';
    my $cNum   = 0;
    my $cMsg   = 'COMPLETED';

    # Get CRS Executable Program (crs_stat)
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {

        $crsExe = execOS('sc qc OracleOHService | find "BINARY_PATH_NAME"');
        if($crsExe ne '')
        {
            $crsExe =~ s/\A\s+BINARY_PATH_NAME[\:\s]+|\\ohasd\.exe.*\z//g;
            $crsExe = $crsExe.'\\crs_stat.exe';
            printLOG('cltRACSta', "CRS Command is [$crsExe]", 'L');
        }
    }
    else
    {
        foreach my $cssLine (getProc('ocssd.bin'))
        {
            printLOG('cltRACSta', "Get CRS Executable [$cssLine]", 'L');
            $cssLine =~ s@\A[^/]+|ocssd.+\z@@g;
            $crsExe = $cssLine.'crs_stat';
            printLOG('cltRACSta', "CRS Command is [$crsExe]", 'L');
            last;
        }
    }

    # Check CRS Executable
    if($crsExe eq '')
    {
        printLOG('cltRACSta', 'no CRS instance running');
    }
    elsif(not -x $crsExe)
    {
        printLOG('cltRACSta', "Failed to get CRS Executable Program [$crsExe]");
        $cMsg = 'Error CRS Executable Program [$crsExe]';
    }
    else
    {
        printLOG('cltRACSta', "Get CRS Executable Program [$crsExe]");
        # Get CRS Resource Name
        my %resNam;
        my $maxLen = 14;
        foreach my $nam (execOS("$crsExe -p", 'ARRAY'))
        {
            if($nam =~ m/\ANAME=/)
            {
                $nam =~ s/\A.*=//;
                my $resLen = length($nam);
                my $breN = $nam;
                if($resLen > $maxLen)
                {
                    $breN = 'ora....'.substr($nam, $resLen - 7, 7)
                }
                $resNam{$breN} = $nam;
            }
        }

        # Get CRS Resource
        my @crsRes = execOS("$crsExe -t", 'ARRAY');
        for(my $x = 2; $x <= $#crsRes; $x ++)
        {
            my @resItm = split(/\s+/, $crsRes[$x]);
            push(@resItm, '');
            print $RESF "'$resNam{$resItm[0]}','$resItm[3]','$resItm[2]','$resItm[4]'\n";
            $cNum ++;
        }
    }

    # Add Collection Status
    addStatus('RD_DB_CRSSTAT', $cNum, $cMsg);
    writeTime('RD_DB_CRSSTAT');

    # Close Result File
    close $RESF;
}

################################################################################
##                                                                            ##
## cltDGDat: Collect Data Guard Related Data                                  ##
##                                                                            ##
################################################################################
sub cltDGDat()
{
    printLOG('cltDGDat', 'Collect DG Data');

    # Check if Skip DG Option Used
    if(not $gENV{'COLLECT_DG'})
    {
        printLOG('cltDGDat', 'User Request not Collect DG Data');

        # Add Not Collect Status to Collection Status
        foreach my $type ('RD_DB_MANSTANDBY', 'RD_DB_LOG', 'RD_DB_EXTINST', 'RD_DB_BAKFILE', 'RD_DB_BAKSET', 'RD_DB_BAKSPFILE')
        {
            addStatus($type, 0, "User Request not Collect DG Data");
        }

        # Quit DG Collection
        return 1;
    }

    # Discover DG Sites
    my $dgPar = queryDB(q{SELECT VALUE FROM V$PARAMETER WHERE NAME = 'log_archive_config' AND INSTR(UPPER(VALUE), 'DG_CONFIG') > 0});

    if(defined $dgPar and scalar @{$dgPar})
    {    # Found DG Sites
        printLOG('cltDGDat', "Found DG for Current System");
        $dgPar->[0]->[0] =~ s/\A.*DG_CONFIG=\(//i;
        $dgPar->[0]->[0] =~ s/\).*\z//i;
        printLOG('cltDGDat', 'DG System List : '.$dgPar->[0]->[0]);

        # Get DG Related Parameters
        $dgPar = queryDB(q{SELECT VALUE FROM V$PARAMETER WHERE REGEXP_LIKE(NAME, 'log_archive_dest_\d+') AND VALUE IS NOT NULL AND NAME IN (SELECT REPLACE(NAME, 'state_', '') FROM V$PARAMETER WHERE REGEXP_LIKE(NAME, 'log_archive_dest_state_\d+') AND UPPER(VALUE) = 'ENABLE')});

        # Parse DG Parameters
        my %dgServ;
        foreach my $par (@{$dgPar})
        {
            $par->[0] =~ s/'|"|\n|\r//g;
            printLOG('cltDGDat', 'Found Parameter : '.$par->[0], 'L');
            if($par->[0] =~ m/SERVICE=([^\s,]+).+DB_UNIQUE_NAME=(\w+)/i)
            {
                $dgServ{$2} = $1;
                printLOG('cltDGDat', "DG Service [$1] for Unique DB [$2]");
            }
        }

        # Open Network Socket
        my ($mSocket, $mSelect) = openSocket($gENV{'LISTEN_PORT'});

        # Get Host Mapping
        my %ipToName;
        my %nameToIP;
        if(open HOSTF, '<', '/etc/hosts'
        or open HOSTF, '<', 'C:\Windows\System32\Drivers\etc\hosts')
        {
            while(<HOSTF>)
            {
                s/\A\s+|\r|\n|\s+\z|#.*\z//g;        # chomp; Remove Blanks at the Begin/End; Remove Comments
                if($_ =~ m/\A127.0.0.1/)
                {
                    printLOG('cltDGDat', "Ignore Loopback IP Address [$_]", 'L');
                }
                elsif($_ =~ m/\A([\d\.]+)\s+(.+)\z/)
                {
                    my $lIP  = $1;
                    my $lNam = $2;
                    printLOG('cltDGDat', "Read Host Line [$lIP <=> $lNam]", 'L');
                    foreach(split(/\s+/, $lNam))
                    {
                        if(not defined $ipToName{$lIP})
                        {
                            $ipToName{$lIP} = $_;
                        }
                        if(not defined $nameToIP{$_})
                        {
                            $nameToIP{$_} = $lIP;
                        }
                    }
                }
            }
            close HOSTF;
        }
        else
        {
            printLOG('cltDGDat', "Cannot Read Host File to Build [IP <-> NAME] Mapping, Reason [$!]\n");
        }

        # Get DG Hosts
        my %dgRmt;
        printLOG('cltDGDat', '+==================== [ DG Information ] ====================+');
        printLOG('cltDGDat', "|  ".rPad('DG Name', 20).' '.rPad('Remote Host', 20).' '.rPad('Remote IP', 15)." |");
        printLOG('cltDGDat', "|  ".rPad('-', 20, '-').' '.rPad('-', 20, '-').' '.rPad('-', 15, '-')." |");
        foreach my $dgNam (keys %dgServ)
        {
            foreach (execOS(qq{tnsping "$dgServ{$dgNam}"}, 'ARRAY'))
            {
                if(m/\(\s*HOST\s*=\s*([^\)]+)\)/i)
                {
                    my $lIP  = $1;
                    my $lNam = $1;
                    if($lIP =~ m/\A[\d\.]+\z/)
                    {
                        $lNam = '';
                        $lNam = $ipToName{$lIP} if(defined $ipToName{$lIP});
                    }
                    else
                    {
                        $lIP = '';
                        $lIP = $nameToIP{$lNam} if(defined $nameToIP{$lNam});
                    }
                    printLOG('cltDGDat', "|  ".rPad($dgNam, 20).' '.rPad($lNam, 20).' '.rPad($lIP, 15)." |");
                    $dgRmt{uc($dgNam)} = 1;
                }
            }
        }
        printLOG('cltDGDat', '+============================================================+');
        if($gENV{'QUIET_MODE'} == 1)
        {
            print "REQUIRE_DG_DATA\n";
        }
        else
        {
            printLOG('cltDGDat', "Notes: You can skip DG Collection by [CTRL + C]");
            showCommand('DG_SCRIPT');
        }

        # Open Result File
        my %DGFH;
        foreach my $typ (keys %gResult)
        {
            if($gResult{$typ}->{'CLASS'} =~ m/(DG|CT)/)
            {
                $DGFH{$typ} = openResult($typ);
            }
        }

        # Collect Node Data
        $gENV{'SKIP_STEP'} = 1;
        while(scalar %dgRmt and $gENV{'SKIP_STEP'})
        {
            # Check can Read Data on Network
            foreach my $fHand ($mSelect->can_read(1))
            {
                if ($fHand == $mSocket)
                {            # Accept New Connection
                    my $new = $mSocket->accept();
                    $mSelect->add($new);
                }
                else
                {
                    while (defined (my $netLine = $fHand->getline))
                    {
                        $netLine =~ s/\r|\n//g;
                        my ($lTyp, $osNam, $lDat) = split(/\|/, $netLine, 3);

                        if(not defined $osNam)
                        {
                            printLOG('NODE_WARN', "Wrong Format [$netLine]");
                        }


                        # Process Network Data
                        if(exists $DGFH{$lTyp})
                        {
                            my $FH = $DGFH{$lTyp};
                            print $FH $lDat."\n";
                        }
                        elsif($lTyp eq 'GET_FILE')
                        {
                            # Sent DG Collection File
                            sendFile("$gFName{'LIB_DIR'}/$gFName{'DG_SCRIPT'}", $fHand);
                            sendFile("$gFName{'LIB_DIR'}/$gFName{'LIB_TOOLS'}", $fHand);
                            sendFile("$gFName{'LIB_DIR'}/$gFName{'LIB_DBTOOL'}", $fHand);
                            sendFile("$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}", $fHand);
                            $fHand->send("COMPLETED\n");
                            printLOG('DG_File', "$osNam -> All DG File have been sent Remote");
                            last;
                        }
                        elsif($lTyp eq 'GET_PARAMS')
                        {
                            $fHand->send("DB_PSWD|$gENV{'DB_PSWD'}\n");
                            $fHand->send("COMPLETED\n");
                            printLOG('DG_Params', "$osNam -> DG Parameters have been sent Remote");
                        }
                        elsif($lTyp eq 'COMPLETE')
                        {
                            $fHand->send("COMPLETED FOR CLOSE\n");
                            delete $dgRmt{uc($lDat)};
                            $mSelect->remove($fHand);
                            my $leftDG = '';
                            if(scalar %dgRmt)
                            {
                                $leftDG    = ", Left is [".join(',', (sort keys %dgRmt))."]";
                            }
                            printLOG('COMPLETE', "$osNam -> Completed for [$lDat]$leftDG");
                        }
                        elsif($lTyp eq 'CHECKER')
                        {
                            my ($rTyp, $uNam) = split(/\:/, $lDat);
                            if($rTyp ne 'PHYSICAL_DG')
                            {
                                printLOG('Checker', "$osNam -> Check Failed : Remote Script is not DGRobot [$rTyp]");
                                $fHand->send("Check Failed : Remote Script is not DGRobot [$rTyp]\n");
                            }
                            elsif(exists $dgRmt{uc($uNam)})
                            {
                                if($dgRmt{uc($uNam)} == -1)
                                {
                                    printLOG('Checker', "$osNam -> Check Failed : DG Node is Already in Collection");
                                    $fHand->send("Check Failed : DG Node is Already in Collection");
                                }
                                else
                                {
                                    $dgRmt{uc($uNam)} = -1;
                                    printLOG('Checker', "$osNam -> Check Passed for [$uNam]");
                                    $fHand->send("PASSED\n");
                                }
                            }
                            else
                            {
                                my $dgList = join(',', (sort keys %dgRmt));
                                printLOG('Checker', "$osNam -> Check Failed : [$uNam] not in Current DG List [$dgList]");
                                $fHand->send("Check Failed : [$uNam] not in Current DG List [$dgList]\n");
                            }
                        }
                        elsif($lTyp eq 'STATUS')
                        {
                            my ($kNam, $kLine, $kMsg) = split(/\|/, $lDat);
                            addStatus($kNam, $kLine, $kMsg);
                        }
                        elsif($lTyp eq 'LOG')
                        {
                            printLOG($lTyp, "$osNam -> $lDat", 'L');
                        }
                        else
                        {
                            printLOG($lTyp, "$osNam -> $lDat");
                        }
                    }
                }
            }
        }

        # Add Collection Status if User Skipped
        if($gENV{'SKIP_STEP'})
        {
            $gENV{'SKIP_STEP'} = 0;
        }
        else
        {
            # Add Skip Status to Collection Status
            foreach my $type ('RD_DB_MANSTANDBY', 'RD_DB_LOG', 'RD_DB_EXTINST', 'RD_DB_BAKFILE', 'RD_DB_BAKSET', 'RD_DB_BAKSPFILE')
            {
                addStatus($type, 0, "User Request Skip DG Collection");
            }
        }

        # close Result File
        foreach(keys %DGFH)
        {
            close $DGFH{$_};
        }
    }
    else
    {                    # No DG Found
        printLOG('cltDGDat', 'no DG Found for Current System');
    }
}

################################################################################
##                                                                            ##
## cltTopAWR: Collect Top AWR in Database                                     ##
##                                                                            ##
################################################################################
sub cltTopAWR()
{
    printLOG('cltTopAWR', 'Collect DB AWR Report');
    writeTime('BEGINER');

    # Check Status
    if($gResult{'RD_DB_AWR_REPORT'}->{'STATUS'} ne 'ENABLE')
    {
        printLOG('cltTopAWR', "Ignore Collection for [RD_DB_AWR_REPORT], due to status [$gResult{'RD_DB_AWR_REPORT'}->{'STATUS'}]");
        addStatus('RD_DB_AWR_REPORT', 0, "Ignore by Status [$gResult{'RD_DB_AWR_REPORT'}->{'STATUS'}]");
        writeTime('RD_DB_AWR_REPORT');
        return 1;
    }

    printLOG('cltTopAWR', "AWR Busy Section [$gENV{'BUSY_SECTIONS'}]", 'L');
    my $topInfo = queryDB(qq{SELECT ID, INSTANCE_NUMBER, BEGIN_TIME, BEGIN_ID, END_TIME, END_ID, STAT_VALUE, ROWNUM
                               FROM (SELECT INSTANCE_NUMBER, BEGIN_TIME, BEGIN_ID, END_TIME, END_ID, STAT_VALUE
                                          , ROW_NUMBER() OVER (PARTITION BY INSTANCE_NUMBER ORDER BY STAT_VALUE DESC) ID
                                       FROM (SELECT T.INSTANCE_NUMBER
                                                  , LAG(TO_CHAR(T.BEGIN_TIME, 'YYYYMMDDHH24MI')) OVER (PARTITION BY S.INSTANCE_NUMBER ORDER BY S.SNAP_ID) BEGIN_TIME
                                                  , LAG(T.SNAP_ID) OVER (PARTITION BY S.INSTANCE_NUMBER ORDER BY S.SNAP_ID) BEGIN_ID
                                                  , TO_CHAR(T.BEGIN_TIME, 'YYYYMMDDHH24MI') END_TIME
                                                  , T.SNAP_ID END_ID
                                                  , VALUE - LAG(VALUE) OVER (PARTITION BY S.INSTANCE_NUMBER ORDER BY S.SNAP_ID) STAT_VALUE
                                               FROM (SELECT TRUNC(END_INTERVAL_TIME, 'HH24') BEGIN_TIME
                                                          , INSTANCE_NUMBER
                                                          , MIN(SNAP_ID) SNAP_ID
                                                       FROM DBA_HIST_SNAPSHOT
                                                      WHERE DBID     = $gENV{'DBID'}
                                                      GROUP BY TRUNC(END_INTERVAL_TIME, 'HH24'), INSTANCE_NUMBER
                                                    ) T,
                                                    (SELECT INSTANCE_NUMBER
                                                          , SNAP_ID
                                                          , VALUE
                                                       FROM DBA_HIST_SYS_TIME_MODEL
                                                      WHERE STAT_NAME  = 'DB time'
                                                        AND DBID       = $gENV{'DBID'}
                                                    ) S
                                              WHERE S.SNAP_ID = T.SNAP_ID
                                                AND T.INSTANCE_NUMBER = S.INSTANCE_NUMBER
                                            )
                                      WHERE STAT_VALUE > 0
                                        AND BEGIN_ID  >= $gENV{'MIN_SNAP'}
                                        AND TO_NUMBER(SUBSTR(BEGIN_TIME, 9, 2)) IN ($gENV{'BUSY_SECTIONS'})
                                    )
                              WHERE ID <= $gENV{'TOP_AWR'}});
    #     ROWNUM INSTANCE_NUMBER BEGIN_TIME     BEGIN_ID END_TIME         END_ID STAT_VALUE ROWNUM
    # ---------- --------------- ------------ ---------- ------------ ---------- ---------- ------
    #          1               1 201605202200      12624 201605202300      12626 3220652716      1
    #          2               1 201605172200      12480 201605172300      12482 1318869025      2
    #          3               1 201605192200      12576 201605192300      12578 1280857592      3

    # Open Result File
    my $AWRF = openResult('RD_DB_AWR_REPORT');

    # Get Top AWR
    my $maxRPT = $gENV{'INSTANCE_COUNT'} * $gENV{'TOP_AWR'};
    foreach my $oneAWR (@{$topInfo})
    {
        printLOG('cltTopAWR', "Get Top AWR [$oneAWR->[7] of $maxRPT]");
        printLOG('cltTopAWR', "AWR Info [$oneAWR->[0] $oneAWR->[1] $oneAWR->[2] $oneAWR->[3] $oneAWR->[4] $oneAWR->[5] $oneAWR->[6]]", 'L');
        my $fNam = "awrrpt_$oneAWR->[1]_$oneAWR->[2]_$oneAWR->[4].html";

        # Save Report Control Info
        print $AWRF "$oneAWR->[0],$oneAWR->[1],TO_DATE($oneAWR->[2], 'YYYYMMDDHH24MI'),$oneAWR->[3],TO_DATE($oneAWR->[4], 'YYYYMMDDHH24MI'),$oneAWR->[5],'DB time',$oneAWR->[6],'$fNam'\n";

        # Collection AWR Report
        if(open AWRRPT, '>:unix:encoding(UTF8)', "$gFName{'RESULT_DIR'}/$fNam")
        {
            my $awrRPT = queryDB("SELECT OUTPUT FROM TABLE(DBMS_WORKLOAD_REPOSITORY.AWR_REPORT_HTML($gENV{'DBID'},$oneAWR->[1],$oneAWR->[3],$oneAWR->[5]))");
            foreach my $awrDat (@{$awrRPT})
            {
                if(defined $awrDat->[0])
                {
                    print AWRRPT decodeDB($awrDat->[0])."\n";
                }
            }
            close AWRRPT;
            addStatus('RD_DB_AWR_REPORT', 0, $DBTools::dbError);
        }
        else
        {
            printLOG('cltTopAWR', "Cannot Write AWR Report [$fNam], Reason [$!]");
            addStatus('RD_DB_AWR_REPORT', 0, "Cannot Write AWR Report [$fNam], Reason [$!]");
        }
    }

    # Close Result File
    close $AWRF;
    writeTime('cltTopAWR');

    printLOG('cltTopAWR', 'Complete DB AWR Report Collection');
}


################################################################################
##                                                                            ##
## cltSegStats: Collect AWR Segment Stats                                     ##
##                                                                            ##
################################################################################
sub cltSegStats()
{
    printLOG('cltSegStats', 'Collect AWR Segment Stats and Objects');
    writeTime('BEGINER');

    # Collec AWR Segments Stats
    collectDB('RD_DB_AWR_SEGSTATS');

    # Read Segment ID List
    if(open SEGSTATF, '<', "$gFName{'RESULT_DIR'}/$gResult{'RD_DB_AWR_SEGSTATS'}->{'FILE'}")
    {
        my %segClted;

        # Get Column Position
        $_ = <SEGSTATF>;
        chomp;
        my @colList = split(/,/);
        my $tsNo      = 0;
        my $objNo     = 0;
        my $dataObjNo = 0;
        for(my $x = 0; $x <= $#colList; $x ++)
        {
            $tsNo      = $x if($colList[$x] eq 'TS#');
            $objNo     = $x if($colList[$x] eq 'OBJ#');
            $dataObjNo = $x if($colList[$x] eq 'DATAOBJ#');
        }
        printLOG('cltSegStats', "Segment Obj Info Location [$tsNo/$objNo/$dataObjNo]");

        # Get Segment List
        while (<SEGSTATF>)
        {
            chomp;
            my ($tsInf, $objInf, $dataObjInf) = (split(/,/))[$tsNo, $objNo, $dataObjNo];
            $segClted{"($tsInf,$objInf,$dataObjInf)"} = 1 if (not defined $segClted{"($tsInf,$objInf,$dataObjInf)"})
        }
        close SEGSTATF;

        # Collect Segment Objects
        if(scalar %segClted)
        {
            my @segList = keys %segClted;
            for(my $x = 0; $x <= $#segList; $x += 100)
            {
                printLOG('cltSegStats', "Collect Segment Object for Batch [".(int($x/100) + 1)."]");
                $gENV{'SEGOBJ_LIST'} = $segList[$x];
                for(my $y = $x + 1; $y <= $x + 99; $y ++)
                {
                    $gENV{'SEGOBJ_LIST'} = "$gENV{'SEGOBJ_LIST'},$segList[$y]" if(defined $segList[$y]);
                }
                collectDB('RD_DB_AWR_SEGOBJ');
            }
        }
    }
    else
    {
        printLOG('cltSegStats', "Cannot Read Segment Stats File [$!]");
    }

    writeTime('cltSegStats');
    printLOG('cltSegStats', 'Complete AWR Segment Stats and Objects');
}


################################################################################
##                                                                            ##
## cltSCNCompat: Collect SCN Compat Version                                   ##
##                                                                            ##
################################################################################
sub cltSCNCompat()
{
    printLOG('cltSCNCompat', 'Collect SCN Compat Version');
    writeTime('cltSCNCompat');

    # Check Status
    if($gResult{'RD_DB_SCN_COMPAT'}->{'STATUS'} ne 'ENABLE')
    {
        printLOG('cltSCNCompat', "Ignore Collection for [RD_DB_SCN_COMPAT], due to status [$gResult{'RD_DB_SCN_COMPAT'}->{'STATUS'}]");
        addStatus('RD_DB_SCN_COMPAT', 0, "Ignore by Status [$gResult{'RD_DB_SCN_COMPAT'}->{'STATUS'}]");
        writeTime('cltSCNCompat');
        return 1;
    }

    my $scnSQL =q{DECLARE
                      V_DATE DATE;
                      V_COMPAT NUMBER;
                      V_ENABLE BOOLEAN;
                  BEGIN
                      DBMS_SCN.GETSCNAUTOROLLOVERPARAMS(V_DATE, V_COMPAT, V_ENABLE);
                      IF V_ENABLE THEN
                          DBMS_OUTPUT.PUT_LINE( 'TO_DATE('''
                                             || TO_CHAR(V_DATE, 'YYYY-MM-DD HH24:MI:SS')
                                             || ''',''YYYY-MM-DD HH24:MI:SS''),'
                                             || V_COMPAT
                                             || ',''ENABLE'''
                                              );
                      ELSE
                          DBMS_OUTPUT.PUT_LINE( 'TO_DATE('''
                                             || TO_CHAR(V_DATE, 'YYYY-MM-DD HH24:MI:SS')
                                             || ''',''YYYY-MM-DD HH24:MI:SS''),'
                                             || V_COMPAT
                                             || ',''DISABLE'''
                                              );
                      END IF;
                  END;
                  };

    # Execute PL/SQL
    my @sqlResult = collectPLSQL($scnSQL);

    # Fetch Result
    my $scnFile = openResult('RD_DB_SCN_COMPAT');
    if($DBTools::dbError eq 'COMPLETED')
    {
        foreach (@sqlResult)
        {
            print $scnFile "$_\n";
        }
    }
    else
    {
        print $scnFile "TO_DATE('$gENV{'CLT_TIME'}','YYYYMMDDHH24MISS'),1,'DISABLE'\n";
    }
    close $scnFile;

    # Save Status
    addStatus('RD_DB_AWR_SQLSTAT', $DBTools::dbRows, $DBTools::dbError);
    writeTime('cltSCNCompat');
    printLOG('cltSCNCompat', 'Complete SCN Compat Version');
}


################################################################################
##                                                                            ##
## postProcess : Post Processes to Result File                                ##
##                                                                            ##
################################################################################
sub postProcess
{
    printLOG('postProcess', 'do Post Process');

    # Close Server Socket
    # --------------------------------------------------------------------------
    closeSocket();


    # Remove Duplicated Header [RD_DB_EXTINST]
    # --------------------------------------------------------------------------
    if(open EXTF, '<', "$gFName{'RESULT_DIR'}/$gResult{'RD_DB_EXTINST'}->{'FILE'}")
    {
        my @extAll = <EXTF>;
        close EXTF;

        if(not defined $extAll[1])
        {
            printLOG('postProcess', 'No Contents in Extra-Instance File', 'L');
        }
        elsif(open EXTF, '>:unix:encoding(UTF8)', "$gFName{'RESULT_DIR'}/$gResult{'RD_DB_EXTINST'}->{'FILE'}")
        {
            print EXTF $extAll[0];
            for(my $x = 1; $x <= $#extAll; $x ++)
            {
                if($extAll[$x] ne $extAll[0])
                {
                    print EXTF $extAll[$x];
                }
            }
            close EXTF;
        }
        else
        {
            printLOG('postProcess', "Cannot Write Extra-Instance File, Reason [$!]");
        }
    }
    else
    {
        printLOG('postProcess', "Cannot Read Extra-Instance File, Reason [$!]");
    }


    # Write Collection Status File
    # --------------------------------------------------------------------------
    my $RESF = openResult('BX_BATCH_STATUS');
    foreach my $kNam (keys %gStatus)
    {
        $gStatus{$kNam}->[1] = substr($gStatus{$kNam}->[1], 0, 3000);
        print $RESF "'$kNam',$gStatus{$kNam}->[0],'$gStatus{$kNam}->[1]'\n";
    }
    close $RESF;


    # Calculate Summary Information, Remove Empty Result
    # --------------------------------------------------------------------------
    my $tLen = 20;
    my $fLen = 35;
    my $sLen = 8;
    my @linS;
    my $FSZF = openResult('RD_OS_FILESIZE');
    foreach my $tNam (keys %gResult)
    {
        my $fNam = "$gFName{'RESULT_DIR'}/$gResult{$tNam}->{'FILE'}";

        # Convert to Absolute File Name
        if($fNam =~ m/\A\./)
        {
            $fNam =~ s/\A\.//;
            if(defined $ENV{'PWD'})
            {
                $fNam = "$ENV{'PWD'}$fNam";
            }
            else
            {
                my $fPWD = getcwd;
                $fPWD =~ s/\r|\n//g;
                $fNam = "$fPWD/$fNam";
            }
        }

        # Get File Size if Exists
        if(-f $fNam)
        {
            # Get File Size
            my $fSiz = (stat $fNam)[7];
            my $fSzH = $fSiz;
            my $unit = ' B';
            if($fSzH > 1048576)
            {
                $fSzH = $fSzH/1048576;
                $unit = 'MB';
            }
            elsif($fSzH > 1024)
            {
                $fSzH = $fSzH/1024;
                $unit = 'KB';
            }

            # Remove Empty File
            if($fSzH == 0)
            {
                printLOG('postProcess', "Remove Empty File [$fNam]", 'L');
                unlink($fNam);
            }
            else
            {
                $fSzH = substr($fSzH, 0, 5);
                $fSzH =~ s/\.\z//g;
                print $FSZF $osInst{$gENV{'HOSTNAME'}}->{'ID'}.",'RESULT','$fNam',$fSiz\n";
                push(@linS, lPad($fSiz, 15).'  '.rPad($tNam, $tLen).' '.rPad($gResult{$tNam}->{'FILE'}, $fLen).' '.lPad($fSzH, 5).' '.$unit);
            }
        }
        else
        {
            printLOG('postProcess', 'File not Found for ['.$fNam.']', 'L');
        }
    }
    close $FSZF;


    # Print Summary Information
    # --------------------------------------------------------------------------
    if($gENV{'QUIET_MODE'} == 0)
    {
        printLOG('postProcess', '');
        printLOG('postProcess', '+====================== [ Summary Information ] ======================+');
        printLOG('postProcess', '|  '.rPad('Table Name', $tLen).' '.rPad('File Name', $fLen).' '.lPad('Size', $sLen).'  |');
        printLOG('postProcess', '|  '.rPad('-', $tLen, '-').' '.rPad('-', $fLen, '-').' '.lPad('-', $sLen, '-').'  |');
        foreach(sort @linS)
        {
            printLOG('postProcess', '|'.substr($_, 15).'  |');
        }
        printLOG('postProcess', '+=====================================================================+');
    }


    # Zip Result Directory
    # --------------------------------------------------------------------------
    # Check Result Directory
    if( defined $gFName{'RESULT_DIR'} and $gFName{'RESULT_DIR'} ne '.' and $gFName{'RESULT_DIR'} ne '/')
    {
        # Check Zip Need and Global Error
        if ($gENV{'RESULT_ZIP'} and $gENV{'GLOBAL_ERROR'} eq '')
        {
            # Split Zip Name
            if($gFName{'RESULT_DIR'} =~ m@\A(.+)/(\w+)\z@)
            {
                # print "Zip Result from [$1], Result Name [$2.zip]\n";

                # Zip Result Directory
                my $zipResult = `cd $1 && zip -r -q $2.zip $2`;

                # Remove Files and Directory
                if($zipResult eq '')
                {
                    opendir RESDIR, $gFName{'RESULT_DIR'};
                    while(my $fNam = readdir RESDIR)
                    {
                        chomp $fNam;
                        unlink "$gFName{'RESULT_DIR'}/$fNam";
                    }
                    rmdir $gFName{'RESULT_DIR'};
                    closedir(RESDIR);
                }
            }
        }
    }
    else
    {
        printLOG('postProcess', "Wrong Directory [$gFName{'RESULT_DIR'}]");
    }


    # Stop Monitor Process
    # --------------------------------------------------------------------------
    if($gENV{'MONITOR_PID'} > 1)
    {
        printLOG('postProcess', "Stop Monitor Process [$gENV{'MONITOR_PID'}]");
        kill 9, $gENV{'MONITOR_PID'};
    }


    # Close Logfile
    # --------------------------------------------------------------------------
    logADM('CLOSE');


    # Show Result File
    # --------------------------------------------------------------------------
    print "\nCollection Tasks all Completed, Result File:\n";
    if (-f "$gFName{'RESULT_DIR'}.zip")
    {
        if($gENV{'QUIET_MODE'} == 1)
        {
            print "BETHUNE_SERVER_RESULT:$gFName{'RESULT_DIR'}.zip\n";
        }
        else
        {
            print " [ Bethune ] --> $gFName{'RESULT_DIR'}.zip\n\n";
        }
    }
    elsif($gENV{'GLOBAL_ERROR'} eq '')
    {
        print " [ Bethune ] --> $gFName{'RESULT_DIR'}\n\n";
    }
    else
    {
        if($gENV{'QUIET_MODE'} == 1)
        {
            print "BETHUNE_SERVER_ERROR:$gENV{'GLOBAL_ERROR'}\n";
        }
        else
        {
            print " [ Bethune ] --> Result: Current package cannot be used !!!\n";
            print " [ Bethune ] -->  Error: $gENV{'GLOBAL_ERROR'}\n\n";
        }
    }
}


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################

# 1. Pre-Process for Collecting
# ------------------------------------------------------------------------------
logADM('OPEN', "$gFName{'LOGFILE'}");
$gENV{'GLOBAL_ERROR'} = '';
writeTime('BEGINER');
parseArgs;
checkENV;
getBasic;
checkEncode;
checkDIR;
checkASM;
checkSSH;
# Start Self-Monitor
selfMonitor;


# 2. Collect Metadata
# ------------------------------------------------------------------------------
collectDB('BX_MD_DB_SYSTEM');
my $MDFILE = openResult('BX_MD_DB_SYSTEM');
print $MDFILE "$gENV{'DB_NAME'}_$gENV{'DBID'}_$gENV{'CLT_TIME'}\n";
print $MDFILE "$gENV{'SCRIPT_VERSION'}\n";
print $MDFILE "$gENV{'CLT_TIME'}\n";
close $MDFILE;


# 3. Collect Node Resouces
# ------------------------------------------------------------------------------
getALoc;
cltNodRes;


# 4. Collect DG Information
# ------------------------------------------------------------------------------
cltDGDat;


# 5. Make Top Event Variable
# ------------------------------------------------------------------------------
if($gENV{'DB_VERSION'} >= 11)
{
    $gENV{'SQL_LIST'} = 'CASE WHEN TOTAL_WAITS_FG>0 THEN TOTAL_WAITS_FG ELSE TOTAL_WAITS END TOTAL_WAITS,CASE WHEN TIME_WAITED_MICRO_FG>0 THEN TIME_WAITED_MICRO_FG ELSE TIME_WAITED_MICRO END TIME_WAITED_MICRO';
}
else
{
    $gENV{'SQL_LIST'} = 'TOTAL_WAITS,TIME_WAITED_MICRO';
}


# 6. Collect DB Data
# ------------------------------------------------------------------------------
foreach my $resNam (keys %gResult)
{
    if($gResult{$resNam}->{'CLASS'} =~ m/DB/)
    {
        writeTime('BEGINER');
        collectDB($resNam);
        writeTime($resNam);
    }
}


# 7. Collect DB Data - Others
# ------------------------------------------------------------------------------
cltAWRSqlS;   # Collect SQL Stat in AWR
cltRACSta;    # Collect RAC Information
cltASMDat;    # Collect ASM Data
cltTopAWR;    # Collect Top AWR Report
cltSegStats;  # Collect Top Segment Stats/Obj
cltSCNCompat; # Collect SCN Compat Version


# 8. Write Collection Control Data
# ------------------------------------------------------------------------------
my $CDFILE = openResult('BX_BATCH_CONTROL');
if($gENV{'CLT_TIME'} =~ m/\A(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\z/)
{
    $gENV{'CLT_TIME'} = "$1-$2-$3 $4:$5:$6"
}
foreach my $varName (keys %gENV)
{
    if($varName eq 'EXTINST_TYPE'
    or $varName eq 'INST_TYPE'
    or $varName eq 'OBJ_SCHEMA'
    or $varName eq 'SQL_LIST')
    {
        next;
    }
    else
    {
        my $varValue =  $gENV{$varName};
        $varValue    =~ s/'/''/g;
        print $CDFILE "'$gENV{'HOSTNAME'}','VAR_P','$varName','$varValue'\n";
    }
}
foreach my $envName (keys %ENV)
{
    my $envValue =  $ENV{$envName};
    $envValue    =~ s/'/''/gm;
    $envValue    =~ s/[\n\r]+/'||CHR(10)||'/gm;
    print $CDFILE "'$gENV{'HOSTNAME'}','ENV_P','$envName','$envValue'\n";
}
close $CDFILE;


# 9. Post Process for the Collector
# ------------------------------------------------------------------------------
writeTime('BTRobot');
postProcess;
