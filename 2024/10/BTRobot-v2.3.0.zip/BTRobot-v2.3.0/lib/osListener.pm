#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 13/09/16 | Modify Listener Status Collection into Multi-Lines     ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 27/09/16 | Fix Endless Loop Bug in Listener Status Collection     ##
##         | 21/10/16 | Ignore not Recognized Line in Listener Log             ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 12/01/17 | Fix Bug in OraNet (' to ‘’ and length max 2000)        ##
## 1.1.4   | 12/01/17 | Version [1.1.4] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 09/02/17 | Set Default Return Code to 0                           ##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 01/04/17 | Set Listener Log Encoding Threshold to 10%             ##
##         | 01/04/17 | Set Local Warn Code, Only Write first 100 Warn         ##
## 2.2.0   | 05/05/17 | Version [2.2.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osListener;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


# Global Variable of Current Module
# ------------------------------------------------------------------------------
our %gLSNR;   # Listener Name => {HOME = Listener Home, LOG = Listener Log}


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    &cltStatus;    # Collect Listener Status
    &cltLsnr;      # Collect Listener Log
    &cltConfig;    # Collect Listener Config
}


################################################################################
##                                                                            ##
## cltStatus : Oracle Listener Status                                         ##
##                                                                            ##
################################################################################
sub cltStatus
{
    printLOG("cltStatus", "Begin Listener Status Collection");

    printLOG("cltStatus", "Get Running Listener Info");
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        foreach my $lsnInfo (execOS('sc query state= all | find  "SERVICE_NAME" | find "TNS"', 'ARRAY'))
        {
            $lsnInfo =~ s/\A\s*SERVICE_NAME[\s\:]+//gi;

            # Get Service Status
            my $lsnStatus = execOS(qq{sc query $lsnInfo | find "STATE"});
            if($lsnStatus =~ m/RUNNING/)
            {
                printLOG("cltStatus", "Listener Service [$lsnInfo] is RUNNING");
            }
            else
            {
                printLOG("cltStatus", "Skip Listener Service [$lsnInfo] due to Status [$lsnStatus]");
                next;
            }

            # a. Get Listener Name/Home
            my $name = $lsnInfo;
            $name =~ s/\A.+TNSListener//i;
            if((not defined $name) or $name eq '')
            {
                $name = 'LISTENER';
            }
            my $home = execOS(qq{sc qc "$lsnInfo" | find "BINARY_PATH_NAME"});
            # BINARY_PATH_NAME   : C:\oracle\product\10.2.0\db_1\BIN\TNSLSNR
            $home =~ s/\A\s*BINARY_PATH_NAME[\s\:]+|.BIN.+//gi;
            printLOG("cltStatus", "Get listener [$name], Home [$home]", 'L');

            $gLSNR{$name}->{'HOME'} = $home;
            $gLSNR{$name}->{'LOG'} = '';
            printLOG("cltStatus", "Get Listener [$name] PATH [$home]");
        }
    }
    else
    {
        foreach my $name (getProc('tnslsnr'))
        {
            # a. Get Listener Name/Home
            $name =~ s#\A[^/]+|\s\-inherit\z|/bin/tnslsnr##g;
            my ($home, $name) = split(/\s+/, $name);

            $gLSNR{$name}->{'HOME'} = $home;
            $gLSNR{$name}->{'LOG'} = '';
            printLOG("cltStatus", "Get Listener [$name] PATH [$home]");
        }
    }

    printLOG("cltStatus", "Collect Listener Status");
    foreach my $lNam (keys %gLSNR)
    {
        $ENV{'ORACLE_HOME'} = $gLSNR{$lNam}->{'HOME'};
        printLOG("cltStatus", "Get Listener Logfile by Status Command", 'L');
        my $statusMSG = '';
        if($gENV{'OS_TYPE'} eq 'MSWin32')
        {
            # execOS("set ORACLE_HOME=$gLSNR{$lNam}->{'HOME'}&$gLSNR{$lNam}->{'HOME'}/bin/lsnrctl status $lNam >status_$lNam.txt");
            foreach my $statLine (execOS("set ORACLE_HOME=$gLSNR{$lNam}->{'HOME'}&$gLSNR{$lNam}->{'HOME'}/bin/lsnrctl status $lNam", 'ARRAY'))
            {
                $statusMSG = $statusMSG."\n".$statLine;
                if($statLine =~ m/\s+([^\s]+\.(log|xml))\z/gi)
                {
                    $gLSNR{$lNam}->{'LOG'} = $1;
                    printLOG("cltStatus", "Found Logfile [$gLSNR{$lNam}->{'LOG'}]", 'L');
                }
            }
        }
        else
        {
            # execOS("ORACLE_HOME=$gLSNR{$lNam}->{'HOME'};export ORACLE_HOME;$gLSNR{$lNam}->{'HOME'}/bin/lsnrctl status $lNam >status_$lNam.txt");
            my @statLines = execOS("ORACLE_HOME=$gLSNR{$lNam}->{'HOME'};export ORACLE_HOME;$gLSNR{$lNam}->{'HOME'}/bin/lsnrctl status $lNam", 'ARRAY');
            if($#statLines < 20)
            {
                @statLines = execOS("setenv ORACLE_HOME $gLSNR{$lNam}->{'HOME'};$gLSNR{$lNam}->{'HOME'}/bin/lsnrctl status $lNam", 'ARRAY');
            }
            for(my $x = 0; $x <= $#statLines; $x ++)
            {
                $statusMSG = $statusMSG."\n".$statLines[$x];
                if($statLines[$x] =~ m/\s+([^\s]+\.(log|xml))\z/gi)
                {
                    $gLSNR{$lNam}->{'LOG'} = $1;
                    printLOG("cltStatus", "Found by Status Command [$gLSNR{$lNam}->{'LOG'}]", 'L');
                }
            }
        }
        $ENV{'ORACLE_HOME'} = $gENV{'ORACLE_HOME'};

        # Save Status Message
        my $lineNo = 1;
        $statusMSG =~ s/[\r\n]+/'||CHR(10)||'/gm;
        while(length($statusMSG) > 3000)
        {
            my $cutLoc = rindex($statusMSG, " ", 3000);
            if($cutLoc <= 0)
            {
                $cutLoc = 3000;
            }
            printLOG("RD_OS_LSN_STATUS","'$lNam',$lineNo,'".substr($statusMSG, 0, $cutLoc)."'");
            $statusMSG = substr($statusMSG, $cutLoc);
            $lineNo ++;
        }
        if($statusMSG ne '')
        {
            printLOG("RD_OS_LSN_STATUS","'$lNam',$lineNo,'$statusMSG'");
        }

        # if(open LSNF, "<:encoding($gENV{'OS_CHARSET'})", "status_$lNam.txt")
        # {
        #     while(<LSNF>)
        #     {
        #         chomp;
        #         printLOG("cltStatus", "Status File [$_]", 'L');
        #     }
        # }
        # else
        # {
        #     printLOG("cltStatus", "Cannot Read Status File, Reason [$!]", 'L');
        # }
    }

    printLOG("STATUS", "RD_OS_LSN_STATUS|COMPLETED");
    printLOG("cltStatus", "Complete Listener Status Collection");
}


################################################################################
##                                                                            ##
## fmtLTime : Format Listener Time                                            ##
##                                                                            ##
################################################################################
sub fmtLTime
{
    my $lBuff = shift;
    $lBuff =~ s/\r|\n//g;

    if ($lBuff =~ m/\A(\d{2})-(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC|1月|2月|3月|4月|5月|6月|7月|8月|9月|10月|11月|12月)[-\s]+(\d{4})\s+(\d{2}):(\d{2}):(\d{2})\s+\*\s+(.*)/i)
    {
        # 07-SEP-2014 09:07:39 * service_update * zData1 * 0
        # 27-JUL-2015 17:12:45 * (CONNECT_DATA=(SID=BXDB)(CID=(PROGRAM=JDBC Thin Client)(HOST=__jdbc__)(USER=Administrator))) * (ADDRESS=(PROTOCOL=tcp)(HOST=1.204.7.89)(PORT=6682)) * establish * BXDB * 0

        my $lTim;

        # Get Date
        if    ($2 eq 'JAN' or $2 eq '1月')
        {
            $lTim = $3.'-01-'.$1;
        }
        elsif ($2 eq 'FEB' or $2 eq '2月')
        {
            $lTim = $3.'-02-'.$1;
        }
        elsif ($2 eq 'MAR' or $2 eq '3月')
        {
            $lTim = $3.'-03-'.$1;
        }
        elsif ($2 eq 'APR' or $2 eq '4月')
        {
            $lTim = $3.'-04-'.$1;
        }
        elsif ($2 eq 'MAY' or $2 eq '5月')
        {
            $lTim = $3.'-05-'.$1;
        }
        elsif ($2 eq 'JUN' or $2 eq '6月')
        {
            $lTim = $3.'-06-'.$1;
        }
        elsif ($2 eq 'JUL' or $2 eq '7月')
        {
            $lTim = $3.'-07-'.$1;
        }
        elsif ($2 eq 'AUG' or $2 eq '8月')
        {
            $lTim = $3.'-08-'.$1;
        }
        elsif ($2 eq 'SEP' or $2 eq '9月')
        {
            $lTim = $3.'-09-'.$1;
        }
        elsif ($2 eq 'OCT' or $2 eq '10月')
        {
            $lTim = $3.'-10-'.$1;
        }
        elsif ($2 eq 'NOV' or $2 eq '11月')
        {
            $lTim = $3.'-11-'.$1;
        }
        elsif ($2 eq 'DEC' or $2 eq '12月')
        {
            $lTim = $3.'-12-'.$1;
        }
        else {
            printLOG("fmtLTime", "Cannot Format Month [$2], Use [12]");
            $lTim = $3.'-12-'.$1;
        }

        # Get Hour
        if (length($4) == 1)
        {
            $lTim = $lTim.' 0'.$4.':00:00';
        }
        else
        {
            $lTim = $lTim.' '.$4.':00:00';
        }

        # 5. Return Left Buffer
        return ($lTim, $7);
    }
    else
    {
        # Return Left Buffer
        return ('', $lBuff);
    }
}


################################################################################
##                                                                            ##
## cltLsnr : Collect Listener Infomations                                     ##
##                                                                            ##
################################################################################
sub cltLsnr
{

    printLOG("osListener", "Begin Listener Collection");

    # Get Listener Name and Program Mapping
    my %lsnLog;
    foreach my $name (keys %gLSNR)
    {
        my $home = $gLSNR{$name}->{'HOME'};
        my $fNam = $gLSNR{$name}->{'LOG'};


        # c. Get Listener Logfile - [Found by Default PATH]
        # ----------------------------------------------------------------------
        if($fNam eq'')
        {              # 11g RAC Above
            # Get Listener Log
            my $gridH = '';
            if($gENV{'OS_TYPE'} ne 'MSWin32')
            {
                foreach (getProc('ocssd.bin'))
                {
                    $gridH = $_;
                    $gridH =~ s/\A[^\/]+|\/bin\/ocssd.+\z//g;
                    printLOG("osListener", "Get Grid Home [$gridH]", 'L');
                    last;
                }
            }

            if(-f "$gENV{'ASM_DIAG'}/diag/tnslsnr/$gENV{'HOSTNAME'}/".lc($name)."/trace/".lc($name).".log")
            {
                $fNam = "$gENV{'ASM_DIAG'}/diag/tnslsnr/$gENV{'HOSTNAME'}/".lc($name)."/trace/".lc($name).".log";
                printLOG("osListener", "Found by Default PATH [$fNam]", 'L');
            }
            elsif(-f "$gridH/log/diag/tnslsnr/$gENV{'HOSTNAME'}/".lc($name)."/trace/".lc($name).".log")
            {
                $fNam = "$gridH/log/diag/tnslsnr/$gENV{'HOSTNAME'}/".lc($name)."/trace/".lc($name).".log";
                printLOG("osListener", "Found by Default PATH [$fNam]", 'L');
            }
            elsif(-f "$gridH/network/log/".lc($name).".log")
            {
                $fNam = "$gridH/network/log/".lc($name).".log";
                printLOG("osListener", "Found by Default PATH [$fNam]", 'L');
            }
            elsif(-f "$gENV{'ORACLE_HOME'}/network/log/".lc($name).".log")
            {
                $fNam = "$gENV{'ORACLE_HOME'}/network/log/".lc($name).".log";
                printLOG("osListener", "Found by Default PATH [$fNam]", 'L');
            }
        }
        elsif($fNam =~ m/xml\z/)
        {    # 11g Single Instance
            printLOG("osListener", "Transform XML log to TXT log", 'L');
            printLOG("osListener", "From XML [$fNam]", 'L');
            $fNam =~ s#alert.*\z##;
            $fNam = $fNam."trace/".lc($name).".log";
            printLOG("osListener", "  To TXT [$fNam]", 'L');
        }


        # d. Save Listener Log
        # ----------------------------------------------------------------------
        if(-f $fNam)
        {
            $lsnLog{$name} = $fNam;
            printLOG("osListener", "Get Listener Logfile [$fNam]", 'L');
        }
        else
        {
            printLOG("Warn", "Cannot Get Listener [$name] Logfile [$fNam], Reason [$!]");
            printLOG("STATUS", "RD_DB_LSNR|Cannot Get Listener [$name] Logfile [$fNam], Reason [$!]");
        }
    }

    # Loop to Collect Log Contents
    # undef %lsnLog;
    # $lsnLog{'LISTENER'} = '/home/oracle/hongye/aaa.log';
    foreach my $lsn (keys %lsnLog)
    {
        my $fNam = $lsnLog{$lsn};
        printLOG("osListener", "Collect listener log [$fNam]");

        # Open Listener Logfile for Read
        if (not open LSNF, "<:encoding($gENV{'LSN_CHARSET'})", $fNam)
        {
            printLOG("Warn", "Cannot Read Listener Logfile [$fNam], Reason [$!]");
            printLOG("STATUS", "RD_DB_LSNR|Cannot Read Listener Logfile [$fNam], Reason [$!]");
            next;
        }

        # Test Listener Log Encoding by Last 1MB
        printLOG("osListener", "Check File Encoding");
        my $fSiz = (stat LSNF)[7];
        seek(LSNF, $fSiz - 1048576, 0);
        <LSNF>;
        my $wCNT = 0;
        my $nCNT = 0;
        local $SIG{__WARN__} = sub { $wCNT ++; };
        while(<LSNF>)
        {
            chomp;
            fmtLTime($_);
            $nCNT ++;
        }

        printLOG("osListener", "Check Result: Lines = [$nCNT] Warns = [$wCNT]");
        if($wCNT >= $nCNT * 0.1)
        {
            if($gENV{'LSN_CHARSET'} eq 'UTF8')
            {
                $gENV{'LSN_CHARSET'} = 'GBK';
                printLOG("osListener", "Re-open with Encoding GBK");
                close LSNF;
                open LSNF, "<:encoding($gENV{'LSN_CHARSET'})", $fNam;
            }
            elsif($gENV{'LSN_CHARSET'} eq 'GBK')
            {
                $gENV{'LSN_CHARSET'} = 'UTF8';
                printLOG("osListener", "Re-open with Encoding UTF8");
                close LSNF;
                open LSNF, "<:encoding($gENV{'LSN_CHARSET'})", $fNam;
            }
        }

        # Define Local Warning Signal
        $gENV{'LSNR_WARNINGS'} = 0;
        local $SIG{__WARN__} = sub
        {
            if($gENV{'LSNR_WARNINGS'} < 100)
            {
                my $ErrMSG = shift;
                $ErrMSG =~ s/[\r\n]+//g;
                printLOG("LsnrWarn", $ErrMSG);
            }
            $gENV{'LSNR_WARNINGS'} ++;
        };

        # Find Begining Position
        printLOG("osListener", "Finding Position of [$gENV{'LSNR_TIME'}], File Size is [$fSiz]");
        my $serP = int($fSiz/2);
        my $incN = $serP;
        my $maxP = $fSiz;
        my $lTim = '9999-11-11 11:11:11';
        printLOG("RD_OS_FILESIZE", "'LISTENER','$fNam',$fSiz");
        until($incN <= 1)
        {
            # Get First Time
            seek(LSNF, $serP, 0);
            <LSNF>;
            while(<LSNF>)
            {
                $lTim = (fmtLTime($_))[0];
                if($lTim ne '')
                {
                    last;
                }
            }

            # Early then Expected Begin Time
            if($lTim lt $gENV{'LSNR_TIME'})
            {
                $incN = int(($maxP - $serP)/2);
                $serP += $incN;
                printLOG("osListener", "[$lTim] Next to [$serP] by [+$incN] ...", 'L');
            }
            else
            {
                $maxP = $serP;
                $incN = int(($incN + 1)/2);
                $serP -= $incN;
                printLOG("osListener", "[$lTim] Next to [$serP] by [-$incN] ...", 'L');
            }
        }

        # Show Log Read Position and Read Size
        my $rdSize;
        if($fSiz - $serP < 1024)
        {
            $rdSize = ($fSiz - $serP)." B";
        }
        elsif($fSiz - $serP < 1048576)
        {
            $rdSize = int(($fSiz - $serP)/1024)." KB";
        }
        else
        {
            $rdSize = int(($fSiz - $serP)/1048576)." MB";
        }

        # Move to Read Position
        if($serP <= 0)
        {
            printLOG("osListener", "Read All data of Logfile, Size is [$rdSize]");
            seek(LSNF, 0, 0);
        }
        else
        {
            seek(LSNF, $serP, 0);
            # Read Begin Line
            $serP = tell LSNF;
            if(<LSNF>)
            {
                chomp;
                printLOG("osListener", "Read Begin Line: ".$_, 'L');
                printLOG("osListener", "Read Log from [$serP], Size is [$rdSize]");
            }
            else
            {
                printLOG("osListener", "No Listener Data Need to Read");
            }
        }


        # 5. Loop to Read Listener File
        printLOG("osListener", "Reading Listener Log");
        my %lsnGrp;
        my $lPreT  = 'X';
        while(<LSNF>)
        {
            my ($lTim, $lBuff) = fmtLTime($_);

            # Format not recognised
            if($lTim eq '')
            {
                next;
            }
            # Write Pre-Hour Listener Info
            elsif($lPreT ne $lTim)
            {
                foreach my $x (sort keys %lsnGrp)
                {
                    printLOG("RD_DB_LSNR", "TO_DATE('$lPreT','YYYY-MM-DD HH24:MI:SS'),'$lsn',$x,$lsnGrp{$x}");
                }
                undef %lsnGrp;
                $lPreT = $lTim;
            }


            my @item = split(/\s*\*\s*/, $lBuff);
            # Example : (CONNECT_DATA=(SERVICE_NAME=db10g)(CID=(PROGRAM=oracle)(HOST=MyDB)(USER=oracle))) * (ADDRESS=(PROTOCOL=tcp)(HOST=192.168.111.10)(PORT=26501)) * establish * db10g * 12514
            # Example : (CONNECT_DATA=(SID=ORCL)(CID=(PROGRAM=)(HOST=__jdbc__)(USER=))) * (ADDRESS=(PROTOCOL=tcp)(HOST=121.15.14.17)(PORT=34809)) * establish * ORCL * 12505
            if(defined $item[2] and $item[2] eq 'establish')
            {
                # CONNECT DATA [* PROTOCOL INFO] * EVENT [* SID] * RETURN CODE
                my ($prog, $host, $ipAddr) = ('unknown', 'unknown', 'unknown');
                if($item[0] =~ m/\(PROGRAM=([^\)]*)\)\(HOST=([^\)]*)\)/)
                {
                    ($prog, $host) = ($1, $2);
                    $prog =~ s#\A.+[/\\]##g;          # Remove Program Path
                    $prog =~ s#\A[^\w]+|[^\w]+\z##g;  # Remove Host Char without Words in Begin/End
                    if($host =~ m/\A\s*\z/)
                    {
                        $host = 'unknown'             # Set Default Value
                    }
                    else
                    {
                        $host =~ s/'/''/g;            # Process Single Quota
                    }
                    if($prog =~ m/\A\s*\z/)
                    {
                        $prog = 'unknown'             # Set Default Value
                    }
                    else
                    {
                        $prog =~ s/'/''/g;            # Process Single Quota
                    }
                }
                if($item[1] =~ m/\(HOST=([^\)\s]+)\)/)
                {
                    $ipAddr = $1;
                }

                # Set Default Return Code to 0
                if($item[4] =~ m/[^\d]+/)
                {
                    $item[4] = 0;
                }
                my $lsnKey = "'$prog','$host','$ipAddr',$item[4]";
                if(not defined $lsnGrp{$lsnKey})
                {
                    $lsnGrp{$lsnKey} = 1;
                }
                else
                {
                    $lsnGrp{$lsnKey} ++;
                }
            }
        }

        # Write Last-Hour Listener Info
        foreach my $x (keys %lsnGrp)
        {
            printLOG("RD_DB_LSNR", "TO_DATE('$lPreT','YYYY-MM-DD HH24:MI:SS'),'$lsn',$x,$lsnGrp{$x}");
        }

        # Close Opened File
        close LSNF;
    }

    printLOG("STATUS", "RD_DB_LSNR|COMPLETED");
    printLOG("osListener", "Complete Listener Collection");
}


################################################################################
##                                                                            ##
## cltConfig : Oracle Network Config                                          ##
##                                                                            ##
################################################################################
sub cltConfig
{

    printLOG("cltConfig", "Begin Oracle Network Config Collection");
    my %fList;


    # 1. Add [listener.ora] [sqlnet.ora]
    # -------------------------------------------------------------------------
    foreach my $lNam (keys %gLSNR)
    {
        # Get Admin Location
        my $oraAdmin = "$gLSNR{$lNam}->{'HOME'}/network/admin";
        if(exists $ENV{'TNS_ADMIN'} and -d $ENV{'TNS_ADMIN'})
        {
            $oraAdmin = $ENV{'TNS_ADMIN'};
        }
        # Add Listener File
        if(-f "$oraAdmin/listener.ora")
        {
            printLOG("cltConfig", "Add File [$oraAdmin/listener.ora]", 'L');
            $fList{"$oraAdmin/listener.ora"} = 'listener.ora';
        }
        else
        {
            printLOG("Warn", "Cannot Read [$oraAdmin/listener.ora], Reason [$!]");
            printLOG("STATUS", "RD_OS_ORANET|Cannot Read [$oraAdmin/listener.ora], Reason [$!]");
        }
        # Add Sqlnet File
        if(-f "$oraAdmin/sqlnet.ora")
        {
            printLOG("cltConfig", "Add File [$oraAdmin/sqlnet.ora]", 'L');
            $fList{"$oraAdmin/sqlnet.ora"} = 'sqlnet.ora';
        }
        else
        {
            printLOG("cltConfig", "Cannot Read [$oraAdmin/sqlnet.ora], Reason [$!]", 'L');
        }
    }


    # 2. Add [tnsnames.ora]
    # -------------------------------------------------------------------------
    my $oraAdmin = "$gENV{'ORACLE_HOME'}/network/admin";
    if(exists $ENV{'TNS_ADMIN'} and -d $ENV{'TNS_ADMIN'})
    {
        $oraAdmin = $ENV{'TNS_ADMIN'};
    }
    # Add Tnsnames File
    if(-f "$oraAdmin/tnsnames.ora")
    {
        printLOG("cltConfig", "Add File [$oraAdmin/tnsnames.ora]", 'L');
        $fList{"$oraAdmin/tnsnames.ora"} = 'tnsnames.ora';
    }
    else
    {
        printLOG("cltConfig", "Cannot Read [$oraAdmin/tnsnames.ora], Reason [$!]", 'L');
    }
    # Add Sqlnet File
    # if(-f "$oraAdmin/sqlnet.ora")
    # {
    #     printLOG("cltConfig", "Add File [$oraAdmin/sqlnet.ora]", 'L');
    #     $fList{"$oraAdmin/sqlnet.ora"} = 'sqlnet.ora';
    # }
    # else
    # {
    #     printLOG("cltConfig", "Cannot Read [$oraAdmin/sqlnet.ora], Reason [$!]", 'L');
    # }


    # 3. Collect Oracle Network Data
    # -------------------------------------------------------------------------
    foreach my $fNam (keys %fList)
    {
        my $fCat = $fList{$fNam};

        printLOG("cltConfig", "Collect [$fCat] from [$fNam]", 'L');

        # Open Network Configuration File
        if(open NETF, '<', $fNam)
        {

            my $lNam = '';
            my $lDat = '';
            my $lLin;
            while (defined (my $nLine = <NETF>))
            {
                $nLine =~ s/(\r|\n|#.*)//g;
                printLOG("cltConfig", "Read [$nLine]", 'L');
                if($nLine eq '')
                {
                    next;
                }

                # New Item
                if ($nLine =~ m/\A\s*([^=\(\s]+)\s*=\s*(.*)\z/)
                {
                    $lNam = $1;
                    if(defined $2)
                    {
                        $lDat = $2;
                        $lDat =~ s/'/''/g;
                    }
                    $lLin = $.;
                }
                elsif ($lNam ne '')
                {
                    $nLine =~ s/'/''/g;
                    $lDat  = "$lDat'||CHR(10)||'$nLine";
                }
                else
                {
                    printLOG("Warn", "Unknown Line [$nLine]");
                }

                # Add to Prev Item
                my @lLst = split(/\(/, "$lDat ");
                my @rLst = split(/\)/, "$lDat ");
                if ((scalar @lLst) == (scalar @rLst) and $lDat ne '')
                {
                    while(length($lDat) > 2000)
                    {
                        my $cutLoc = rindex($lDat, " ", 2000);
                        $cutLoc = rindex($lDat, ",", 2000) if($cutLoc <=100);
                        printLOG("RD_OS_ORANET", "'$fCat',$lLin,'$lNam','".substr($lDat, 0, $cutLoc)."'");
                        $lDat = substr($lDat, $cutLoc);
                        $lLin ++;
                    }
                    if($lDat ne '')
                    {
                        printLOG("RD_OS_ORANET", "'$fCat',$lLin,'$lNam','$lDat'");
                    }
                    $lNam = '';
                    $lDat = '';
                }
            }

            # Close Network Configuration File
            close NETF;
        }
        else
        {
            printLOG("Warn", "Cannot Read [$fNam], Reason [$!]");
            printLOG("STATUS", "RD_OS_ORANET|Cannot Read [$fNam], Reason [$!]");
        }
    }


    printLOG("STATUS", "RD_OS_ORANET|COMPLETED");
    printLOG("cltConfig", "Complete Oracle Network Config Collection");
}


1;
