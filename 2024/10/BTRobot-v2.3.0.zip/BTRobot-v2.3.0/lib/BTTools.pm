#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 19/09/16 | [sendFile] Ignore Column Header When Sending Result    ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 27/09/16 | [showCommand] Change Remote Command Tips               ##
##         | 29/09/16 | [getDirFree] Add Function to Get Directory Free Space  ##
##         | 29/09/16 | [selfMonitor] Add Self-Monitor for non-Windows         ##
##         | 21/10/16 | [selfMonitor] Add Signal Capture for Monitor Process   ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 17/11/16 | [selfMonitor] Add Logfile for Primary Monitor Process  ##
##         | 17/11/16 | [printLOG] Add Monitor Log Condition                   ##
## 1.1.1   | 21/11/16 | Version [1.1.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 28/12/16 | [selfMonitor] Add More Message When Stopped            ##
##         | 04/01/17 | [getDirFree] Add Default Code for OS Type              ##
## 1.1.4   | 12/01/17 | Version [1.1.4] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 14/02/17 | [printLOG] Add Program Area Length                     ##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 15/03/17 | [selfMonitor] Change tip when quit in quiet mode       ##
##         | 27/03/17 | Add Time Func: timeAdd/timeAdd2/timeMinus/timeMinus2   ##
## 2.1.0   | 29/03/17 | Version [2.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 02/04/17 | Merge and keep two time function: timeAdd/timeMinus    ##
## 2.2.0   | 05/05/17 | Version [2.2.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 18/07/17 | Modification of time functions                         ##
## 2.2.2   | 18/07/17 | Version [2.2.2] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    # Add Current Library
    unshift(@INC, "./lib") if (-d './lib');
    unshift(@INC, "./conf") if (-d './conf');
    unshift(@INC, "/tmp")  if (-d '/tmp');
}
package BTTools;
require Exporter;
use warnings;
use strict;
use IO::Socket;
use IO::Select;
use PerlIO::encoding;
use Encode;
use utf8;
use BTConfig;
binmode STDOUT, ":utf8";

our @ISA = qw(Exporter);

# Will Import Automaticly
our @EXPORT = qw( logADM
                  printLOG
                  lPad
                  rPad
                  getProc
                  execOS
                  decodeData
                  openSocket
                  closeSocket
                  addStatus
                  sendFile
                  roundNum
                  showCommand
                  openResult
                  writeTime
                  getDirFree
                  selfMonitor
                  timeAdd
                  timeMinus
                );

# Will Import by User Required
# our @EXPORT_OK = qw('printLOG', 'lPad', 'rPad', 'getProc', 'execOS', 'decodeData');

# Cannot be Imported
# our @EXPORT_OK = qw('printLOG', 'lPad', 'rPad', 'getProc', 'execOS', 'decodeData');


# Global Parameters
# ------------------------------------------------------------------------------
our $LOGFH;
our $MONLOGFH;
our $mSocket;
our $mSelect;
our $mHandler;

our @timeArr;


################################################################################
##                                                                            ##
## 1. logADM: Logfile Administrator                                           ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. Logfile Oper : Input Logfile Operations (OPEN/CLOSE/MOVE)            ##
##    2. Logfile Name : Input Logfile Name in File System                     ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    1. $LOGFH                                                               ##
##                                                                            ##
################################################################################
sub logADM($;$)
{
    # Get Parameters
    my $logOper = uc($_[0]);
    my $logFile = $_[1];

    # Logfile is needed for Non-Close OP
    if($logOper ne 'CLOSE' and (not defined $logFile or $logFile eq ''))
    {
        die "Function logADM need a Logfile Name in Second Params\n";
    }
    elsif($logOper eq 'OPEN')
    {
        if(defined $LOGFH)
        {
            close $LOGFH;
        }
        open $LOGFH, ">>:unix:encoding(UTF8)", $logFile or die "Cannot Open [$logFile], Reason [$!]\n";
        $gENV{'LOGFILE'} = $logFile;
    }
    elsif($logOper eq 'CLOSE')
    {
        if(defined $LOGFH)
        {
            close $LOGFH or print "Cannot Close [$gENV{'LOGFILE'}], Reason [$!]\n";
            undef $LOGFH;
        }
    }
    elsif($logOper eq 'MOVE')
    {
        if(defined $LOGFH)
        {
            close $LOGFH or print "Cannot Close [$gENV{'LOGFILE'}], Reason [$!]\n";
        }
        rename($gENV{'LOGFILE'}, $logFile) or print "Cannot Move [$gENV{'LOGFILE'}], Reason [$!]\n";
        open $LOGFH, ">>:unix:encoding(UTF8)", $logFile or die "Cannot Open [$logFile], Reason [$!]\n";
        $gENV{'LOGFILE'} = $logFile;
    }
    else
    {
        print "Cannot Identified Log Operator [$logOper]\n";
    }
}


################################################################################
##                                                                            ##
## 2. printLOG: Log Printer                                                   ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. Function Name : Input Function Name where Log Printed                ##
##    2. Log Message   : Input Fully Log Message to Show                      ##
##    3. New Line      : (N/L) Means NewLine and Logfile                      ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    1. $LOGFH                                                               ##
##                                                                            ##
################################################################################
sub printLOG($$;$)
{
    # Get Log Parameters
    # --------------------------------------------------------------------------
    my ($logFunc, $logMesg, $logType)  = @_;
    if($gENV{'OS_CHARSET'} eq 'GBK')
    {
        $logMesg = Encode::encode('GBK', $logMesg);
    }else{
        $logMesg = Encode::encode('UTF8', $logMesg);
    }
    if(not defined $logType)
    {
        $logType = 'Y';
    }


    # Make Log Time
    # --------------------------------------------------------------------------
    # my ($sec,$min,$hour,$day,$month,$year,$wday,$yday,$isdst) = localtime();
    # $year += 1900;
    # $month += 1;
    # $dateNow = sprintf("%4d%02d%02d_%02d%02d", $year, $month, $day, $hour, $min);
    my ($sec, $min, $hour)=(localtime)[0..2];
    my $logDate = sprintf("%02d:%02d:%02d", $hour, $min, $sec);


    # [Script Monitor] Write Log to Monitor Logfile
    # --------------------------------------------------------------------------
    if(defined $MONLOGFH)
    {
        printf $MONLOGFH "%8s%16s: %s\n", $logDate, $logFunc, $logMesg;

        # Write Log to Screen
        if($logType eq 'N')
        {
            printf "%8s%16s: %s", $logDate, $logFunc, $logMesg;
        }
        elsif($logType ne 'L')
        {
            printf "%8s%16s: %s\n", $logDate, $logFunc, $logMesg;
        }
    }
    # [Script Caller] Write Log to Logfile
    # --------------------------------------------------------------------------
    elsif(defined $LOGFH)
    {
        printf $LOGFH "%8s%16s: %s\n", $logDate, $logFunc, $logMesg;

        # Write Log to Screen
        if($logType eq 'N')
        {
            printf "%8s%16s: %s", $logDate, $logFunc, $logMesg;
        }
        elsif($logType ne 'L')
        {
            printf "%8s%16s: %s\n", $logDate, $logFunc, $logMesg;
        }
    }
    # [Other Nodes] Write Log to Primary Node
    # --------------------------------------------------------------------------
    elsif(defined $mHandler)
    {
        if($logType eq 'L')      # Log
        {
            $mHandler->send("LOG|$gENV{'HOSTNAME'}|$logMesg\n");
        }
        elsif($logType eq 'T' or exists $gResult{$logFunc})
        {
            $mHandler->send("$logFunc|$gENV{'HOSTNAME'}|$logMesg\n");
        }
        else
        {
            $mHandler->send("$logFunc|$gENV{'HOSTNAME'}|$logMesg\n");
            printf "%8s%16s: %s\n", $logDate, $logFunc, $logMesg;
        }
    }
    else
    {
        printf "%8s%16s: %s\n", $logDate, $logFunc, $logMesg;
    }
}


################################################################################
##                                                                            ##
## 3. lPad: Left Padding                                                      ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Orignal String to do Padding                             ##
##    2. Length    : Target Length in Padding                                 ##
##    3. Char      : Charecters be Padding to the String                      ##
## Output Params                                                              ##
##    1. Result    : String in Target Length                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub lPad($$;$)
{

    my $retString = $_[0];
    my $tgtLength = $_[1];
    my $padChar   = $_[2];
    if (not defined $padChar)
    {
        $padChar = ' ';
    }

    for(my $nowLen = length($retString); $nowLen < $tgtLength; $nowLen ++)
    {
        $retString = $padChar.$retString;
    }

    return $retString;
}


################################################################################
##                                                                            ##
## 4. rPad: Right Padding                                                     ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Orignal String to do Padding                             ##
##    2. Length    : Target Length in Padding                                 ##
##    3. Char      : Charecters be Padding to the String                      ##
## Output Params                                                              ##
##    1. Result    : String in Target Length                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub rPad($$;$)
{

    my $retString = $_[0];
    my $tgtLength = $_[1];
    my $padChar   = $_[2];
    if (not defined $padChar)
    {
        $padChar = ' ';
    }

    for(my $nowLen = length($retString); $nowLen < $tgtLength; $nowLen ++)
    {
        $retString = $retString.$padChar;
    }

    return $retString;
}


################################################################################
##                                                                            ##
## 5. getProc: Get Matched Process                                            ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Keyword in Searching Process List                        ##
## Output Params                                                              ##
##    1. Array     : Matched Processes                                        ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub getProc($)
{

    # Get Keyword
    my $kC = $_[0];
    printLOG('getProc', "Get Unix Process Infomation with [$kC]", 'L');

    # Get Matched Process List
    my @matchedProc;
    foreach(`ps -ef`)
    {
        s/\r|\n//g;  # chomp;

        if(index($_, $kC) >= 0)
        {
            push(@matchedProc, $_);
            printLOG('getProc', "Pro Matched --> [$_]", 'L');
        }
        elsif($gENV{'PRINT_PROCESS'})
        {
            printLOG('getProc', "Not Matched --> [$_]", 'L');
        }
    }

    # Reduce Process Printor
    $gENV{'PRINT_PROCESS'} --;

    # Return Match Process List
    return @matchedProc;
}


################################################################################
##                                                                            ##
## 6. execOS: Execute Node OS Scripts/Command                                 ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Command to be Executed on OS                             ##
##    2. String    : Execution Type [Background/Array/Monitor]                ##
## Output Params                                                              ##
##    1. String    : Command Output                                           ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub execOS($;$)
{
    # Get OS Command
    my $osCMD = shift;
    my $bMode = shift;

    # Execute Foreground - Return Single Line
    if(not defined $bMode)
    {
        printLOG('execOS', "Execute Single: $osCMD", 'L');
        my $osRes = `$osCMD`;
        $osRes =~ s/\r|\n//g;
        # if($gENV{'OS_CHARSET'} eq 'GBK')
        # {
        #     Encode::from_to($osRes, 'GBK', 'UTF8');
        # }
        $osRes = decodeData($gENV{'OS_CHARSET'}, $osRes);

        # Write Result into Logfile
        printLOG('execOS', "Command Result: $osRes", 'L');
        return $osRes;
    }
    # Execute Foreground - Return Array
    elsif(uc($bMode) eq 'ARRAY')
    {
        printLOG('execOS', "Execute Array: $osCMD", 'L');
        my @osRes = `$osCMD`;
        chomp @osRes;

        # Write Result into Logfile
        printLOG('execOS', "================================================================================", 'L');
        printLOG('execOS', "Array Result:", 'L');
        for(my $x = 0; $x <= $#osRes; $x ++)
        {
            $osRes[$x] = decodeData($gENV{'OS_CHARSET'}, $osRes[$x]);
            printLOG('execOS', $osRes[$x], 'L');
        }
        printLOG('execOS', "================================================================================", 'L');
        return @osRes;
    }
    # Execute Background - Win
    elsif($^O eq 'MSWin32')
    {
        printLOG('execOS', "Execute Background: $osCMD", 'L');
        system("START /B $osCMD 1>/nul 2>\&1");
        return '';
    }
    # Execute Background - Linux/Unix
    else
    {
        printLOG('execOS', "Execute Background: $osCMD", 'L');
        system("nohup $osCMD 1>/dev/null 2>\&1 \&");
        return '';
    }
}


################################################################################
##                                                                            ##
## 7. decodeData: Decode Strings Result                                       ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Original Character Set                                   ##
##    2. String    : Original String to be Decoded                            ##
## Output Params                                                              ##
##    1. String    : Decoded String                                           ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub decodeData($$)
{

    my ($origSet, $origStr) = @_;

    if($origSet eq 'GBK' or $origSet eq 'UTF8')
    {
        # 1. Backup and Re-Set DIE Signal
        # my $oldDIE = $SIG{__DIE__};
        local $SIG{__DIE__} = sub
        {
            foreach(@_)
            {
                chomp;
                printLOG('decodeData', "Prevent Decode Die : $_", 'L');
            }
        };

        # 2. Decode String to Perl Internal Format
        eval
        {
            #$origStr = decode($origSet, $origStr);
            $origStr = Encode::decode($origSet, $origStr);
        };

        # 3. Re-Set DIE Signal
        # $SIG{__DIE__} = $oldDIE;
    }
    else
    {
        printLOG('decodeData', "unKnow Charset [$origSet]", 'L');
    }

    return $origStr;
}


################################################################################
##                                                                            ##
## 8. addStatus: Add Collection Status                                        ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Collection Name                                          ##
##    2. Number    : Result Number                                            ##
##    3. Number    : Result Message                                           ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub addStatus($$$)
{
    # Get Params
    my ($name, $num, $mesg) = @_;
    printLOG('addStatus', "Add Collection Status for [$name] [$num] [$mesg]", 'L');

    # Convert Message Text
    $mesg =~ s/'/''/g;
    $mesg =~ s/[\r\n]+/'||CHR(10)||'/g;

    # Add Message Text to List
    if(exists $gStatus{$name})
    {
        # Add Number
        $gStatus{$name}->[0] += $num;

        # Add Message
        if($gStatus{$name}->[1] eq 'COMPLETED')
        {
            $gStatus{$name}->[1] = $mesg;
        }
        elsif($mesg ne 'COMPLETED')
        {
            $gStatus{$name}->[1] = $gStatus{$name}->[1]."'||CHR(10)||'".$mesg;
        }
    }
    else
    {
        # New Status
        $gStatus{$name} = [$num, $mesg];
    }
}


################################################################################
##                                                                            ##
## 9. openSocket: Open Server/Client Socket                                   ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Server Listening Port                                    ##
## Output Params                                                              ##
##    1. String    : Connected Socket                                         ##
##    2. String    : Socket Selector                                          ##
##    3. String    : Socket Handler                                           ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub openSocket($;$)
{
    # Get Parameters
    # --------------------------------------------------------------------------
    my ($servIP, $servPort);
    if(defined $_[1])
    {
        ($servIP, $servPort) = @_;
    }
    else
    {
        $servPort = $_[0];
    }


    # Open Socket
    # --------------------------------------------------------------------------
    if(defined $mSocket)
    {
        printLOG('openSocket', "Socket Already Started on Port [$gENV{'LISTEN_PORT'}]");
    }
    elsif(defined $servIP)
    {
        # Open Socket
        printLOG('openSocket', "Connect to [$servIP] on Port [$servPort]");
        $mSocket = IO::Socket::INET->new( PeerAddr => $servIP
                                        , PeerPort => $servPort
                                        , Type     => SOCK_STREAM
                                        , Timeout  => 60
                                        , Proto    => 'tcp')
        or die "Failed to Connect to Remote Lieten Node [$servIP], Reason: [$@]\n";

        # Set Properties
        # binmode($mSocket, ':encoding(UTF8)');
        $mSocket->autoflush(1);
        $mSocket->blocking(1);
        $mSelect  = IO::Select->new($mSocket);
        $mHandler = ($mSelect->handles)[0];

        # Socket Opened
        printLOG('openSocket', "Connected to Node [$servIP]");
    }
    else
    {
        # Open Socket
        printLOG('openSocket', 'Open Socket to Collect Node Resources');
        $mSocket = IO::Socket::INET->new( Proto     => 'tcp',
                                        , Listen    => 16
                                        , LocalPort => $gENV{'LISTEN_PORT'})
        or die "Failed to Start Lieten on Port [$gENV{'LISTEN_PORT'}], Reason: [$@]\n";

        # Set Properties
        # binmode($mSocket, ':encoding(UTF8)');
        $mSocket->autoflush(1);
        $mSocket->blocking(1);
        $mSelect = IO::Select->new($mSocket);

        # Socket Opened
        printLOG('openSocket', "Started Listen on Port [$gENV{'LISTEN_PORT'}]");
    }


    # Return Handlers
    # --------------------------------------------------------------------------
    if(defined $servIP)
    {
        return $mHandler;
    }
    else{
        return ($mSocket, $mSelect);
    }
}


################################################################################
##                                                                            ##
## 10. closeSocket: Close Server Socket                                       ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    <None>                                                                  ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub closeSocket
{
    if(defined $mSocket)
    {
        printLOG('closeSocket', "Close Socket on Port [$gENV{LISTEN_PORT}]");

        # Close Handlers
        foreach my $fHand ($mSelect->handles)
        {
            if($fHand ne $mSocket)
            {
                $fHand->close
            }
        }

        # Close Socket
        $mSocket->close;
    }
    else
    {
        printLOG('closeSocket', "No Socket on Port [$gENV{LISTEN_PORT}]");
    }
}


################################################################################
##                                                                            ##
## 11. sendFile: Open Client Socket                                           ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : File Name to be Sent                                     ##
##    2. String    : Result Name or Net Handler Name                          ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub sendFile($;$)
{
    # Get Parameters
    # --------------------------------------------------------------------------
    my ($fileName, $resName) = @_;


    # Sending File Contents
    # --------------------------------------------------------------------------
    if(open SDFH, '<', $fileName)
    {
        # Send Result File [Remote -> Local]
        if(defined $gResult{$resName})
        {
            printLOG('sendFile', "Sending Result File [$fileName]");

            # Remove Column Header
            <SDFH>;

            # Send File
            while(<SDFH>)
            {
                $mHandler->send("$resName|$gENV{'HOSTNAME'}|$_");
            }

            # Send Collection Status
            $mHandler->send("STATUS|$gENV{'HOSTNAME'}|$resName|$gStatus{$resName}->[0]|$gStatus{$resName}->[1]\n");

            # Remove Result File
            unlink($fileName);
        }
        # Send Script File [Local -> Remote]
        else
        {
            printLOG('sendFile', "Sending Script File [$fileName]");

            # Parse File Name
            my $nameOnly = $fileName;
            $nameOnly =~ s@\A.*[/\\]@@g;
            $resName->send("$nameOnly\n");

            # Send File
            while(<SDFH>)
            {
                $resName->send($_);
            }

            # Send Ending Tips
            $resName->send("<-EOF->\n");
        }

        printLOG('sendFile', "File Sending Completed");
    }
    else
    {
        printLOG('sendFile', "Cannot Sent File [$fileName], Reason [$!]");
    }
}


################################################################################
##                                                                            ##
## 12. roundNum: Round a Number                                               ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. Number    : Source Number                                            ##
##    2. Number    : Precision                                                ##
## Output Params                                                              ##
##    1. Number    : Rounded Number                                           ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub roundNum($$)
{

    # Get Input Params
    my ($sN, $sP) = @_;
    my $tN = $sN;

    # Check Validation of Precision
    if((not defined $sP) or $sP !~ m/\A\d+\z/)
    {
        $sP = 0;
    }

    # Round the Number with Decimal Point
    if($sN =~ m/\A(\d+\.\d{$sP})(\d)\d*\z/)
    {
        $tN = $1;
        if($2 >= 5)
        {
            my $aN = '';
            for(my $x = 1; $x < $sP; $x ++)
            {
                $aN = $aN.'0';
            }

            # Add 1 in Last
            if($sP == 0)
            {
                $tN += 1;
            }
            else
            {
                $tN += "0.".$aN."1";
            }
        }
    }
    elsif($sP !~ m/\A\d*(\.\d+)*\z/)
    {
        printLOG('roundNum', "Not a Valid Source Number [$sN]", 'L');
    }

    return $tN;
}


################################################################################
##                                                                            ##
## 13. showCommand: Show Remote Command                                       ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Command Type                                             ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub showCommand($)
{
    # Get Parameter
    my $type = shift;

    # Get Host IP/Name
    my $cNode = $gENV{'HOSTNAME'};
    if($gENV{'HOSTIP'} ne '127.0.0.1')
    {
        $cNode = $gENV{'HOSTIP'};
    }

    # Show Command

    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {

        print qq{# ----------------[ Please Run Following Command on Remote CMD ]----------------\n};
        print qq{\n};
        print q#perl -e "use IO::Socket;use IO::Select;" ^#."\n";
        print q{-e "$OH=$ENV{ORACLE_HOME};my ($PN,$PP)=('}.$cNode.q{',}.$gENV{'LISTEN_PORT'}.q{); # Primary" ^}."\n";
        print q#-e "my $SK=IO::Socket::INET->new(PeerAddr=>$PN,PeerPort=>$PP,Proto=>TCP," ^#."\n";
        print q#-e "Timeout=>60) or die 'Connect ['.$!.']';$SL=IO::Select->new($SK);my @FL;" ^#."\n";
        print q#-e "$NH=($SL->handles)[0];$NH->send(qq{GET_FILE|X\n});die 'No Reply'" ^#."\n";
        print q#-e "if(not $SL->can_read(60));print 'Files :';while(1){my $ND=$NH->getline;" ^#."\n";
        print q#-e "chomp $ND;last if($ND eq 'COMPLETED');push(@FL,$ND);open FH,'>',$ND;" ^#."\n";
        print q#-e "print $ND;while(1){chomp($ND=$NH->getline);last if($ND eq '<-EOF->');" ^#."\n";
        print q#-e "print FH qq{$ND\n};}close FH;print '[OK] ';}print qq{\n\n};" ^#."\n";
        print q#-e "$ENV{'LD_LIBRARY_PATH'}=$ENV{'SHLIB_PATH'}=qq{$OH/lib32:$OH/lib};" ^#."\n";
        print q#-e "$ENV{'LIBPATH'}=$ENV{'SHLIB_PATH'};system(qq{perl #.$gFName{$type}.q# $PN $PP});" ^#."\n";
        print q#-e "foreach(@FL){unlink}"#."\n";
        print qq{\n};
        print qq{# -------------------------------[ Command End ]--------------------------------\n};
    }
    else
    {
        print qq{# ---------[ Please Run Following Command on Remote Server by Oracle ]----------\n};
        print qq{\n};
        print q#perl -e 'use IO::Socket;use IO::Select;#."\n";
        print q{$OH=$ENV{ORACLE_HOME};my ($PN,$PP)=("}.$cNode.q{",}.$gENV{'LISTEN_PORT'}.q{); # Primary}."\n";
        print q#my $SK=IO::Socket::INET->new(PeerAddr=>$PN,PeerPort=>$PP,Proto=>TCP,Timeout=>60)#."\n";
        print q#or die "Connect [$!]";$SL=IO::Select->new($SK);$NH=($SL->handles)[0];my @FL;#."\n";
        print q#print "Files :";$NH->send("GET_FILE|X\n");die "No Reply"#."\n";
        print q#if(! $SL->can_read(60));while(1){my $ND;chomp($ND=$NH->getline);last if($ND eq#."\n";
        print q#"COMPLETED");print $ND;push(@FL,$ND);open FH,">",$ND;while(1){chomp($ND=#."\n";
        print q#$NH->getline);last if($ND eq "<-EOF->");print FH "$ND\n";}close FH;#."\n";
        print q#print "[OK] ";}print "\n";$ENV{"LIBPATH"}="$OH/lib32:$OH/lib";#."\n";
        print q#$ENV{"SHLIB_PATH"}=$ENV{"LD_LIBRARY_PATH"}=$ENV{"LIBPATH"};#."\n";
        print q#$ENV{"PERL5LIB"}="$OH/perl/lib:$OH/perl/lib/site_perl";#."\n";
        print q{system("$OH/perl/bin/perl }.$gFName{$type}.q{ $PN $PP");foreach(\@FL){unlink}'}."\n";
        print qq{\n};
        print qq{# -------------------------------[ Command End ]--------------------------------\n};
    }
}


################################################################################
##                                                                            ##
## 14. openResult: Open Result File                                           ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Result File Name                                         ##
## Output Params                                                              ##
##    1. Ref.      : Opened File Descriptor                                   ##
## Ref. Function                                                              ##
##    1. printLOG                                                             ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub openResult($)
{
    # Get Parameter
    my $name = shift;

    # Get Result File
    if(exists $gResult{$name})
    {
        # Get Size Size
        my $fSize = 0;
        if(-f "$gFName{'RESULT_DIR'}/$gResult{$name}->{'FILE'}")
        {
            $fSize = (stat("$gFName{'RESULT_DIR'}/$gResult{$name}->{'FILE'}"))[7];
        }

        # Get Definition
        my $resDefine = "";
        if($fSize == 0 and defined $gResult{$name}->{'DEFINE'})
        {
            $resDefine = $gResult{$name}->{'DEFINE'}."\n";
        }

        # Open File
        my $RESF;
        open $RESF, ">>:unix", "$gFName{'RESULT_DIR'}/$gResult{$name}->{'FILE'}"
        or
        die "Cannot Write Result File [$gFName{'RESULT_DIR'}/$gResult{$name}->{'FILE'}], Reason [$!]\n";
        # binmode($RESF, ":encoding(UTF8)");

        # Write Definition
        print $RESF $resDefine;

        # Return Open File Descriptor
        return $RESF;
    }
    else
    {
        printLOG('openResult', "No Result File Named [$name]", 'L');
    }
}


################################################################################
##                                                                            ##
## 15. writeTime: Save Execution Time                                         ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Type for the Time                                        ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub writeTime($)
{
    my $tType = shift;

    if((not defined $tType) or $tType eq '')
    {
        printLOG('writeTime', 'Type is Needed as 1st in Parameter List')
    }
    elsif($tType eq 'BEGINER')
    {
        my $timeNow = time();
        push(@timeArr, $timeNow);
    }
    elsif(scalar @timeArr)
    {
        my $RESF = openResult('BX_BATCH_CONTROL');
        print $RESF "'$gENV{'HOSTNAME'}','TIME','$tType','".((time()) - (pop @timeArr))."'\n";
        close $RESF;
    }
    else
    {
        my $RESF = openResult('BX_BATCH_CONTROL');
        print $RESF "'$gENV{'HOSTNAME'}','TIME','$tType',''\n";
        close $RESF;
    }
}


################################################################################
##                                                                            ##
## 16. getDirFree: Get Directory Free Space                                   ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    1. String    : Directory Name                                           ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub getDirFree($)
{
    # Get Arguments
    my $dirName = shift;
    my $dirFree = 0;

    # get Free Space
    if($gENV{'OS_TYPE'} eq "MSWin32")
    {
        my $dirInfo = execOS(qq{dir /-C "$dirName"});
        if($dirInfo =~ m/(\d+)[^\d]+\z/)
        {
            $dirFree = int($1/1048576);
        }
    }
    elsif($gENV{'OS_TYPE'} eq "aix")
    {
        my $dirInfo = execOS("df -m $dirName | tail -1");
        $dirFree = (split(/\s+/, $dirInfo))[2];
    }
    elsif($gENV{'OS_TYPE'} eq "hpux")
    {
        my $dirInfo = execOS("bdf $dirName | tail -1");
        $dirFree = (split(/\s+/, $dirInfo))[3];
        $dirFree = int($dirFree/1024);
    }
    else
    {
        my $dirInfo = execOS("df -k $dirName | tail -1");
        $dirFree = (split(/\s+/, $dirInfo))[3];
        $dirFree = int($dirFree/1024);
    }

    # Return Directory Free Space
    return $dirFree;
}


################################################################################
##                                                                            ##
## 17. selfMonitor: Self Monitor sub-Process                                  ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    <None>                                                                  ##
## Output Params                                                              ##
##    <None>                                                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub selfMonitor()
{
    printLOG('selfMonitor', "Start Self-Monitor [$$]");

    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {
    }
    else
    {
        $gENV{'MONITOR_PID'} = fork();

        if(not defined $gENV{'MONITOR_PID'})
        {
            printLOG('Monitor', "Cannot Folk Monitor Process [$!]");
        }
        # Monitor Process
        elsif($gENV{'MONITOR_PID'} == 0)
        {
            # Define Signal Capture
            $SIG{__DIE__}  = sub
            {
                my $msgALL = join("\n", @_);
                foreach my $errMSG (split(/[\r\n]+/, $msgALL))
                {
                    printLOG('Signal', "Monitor Error: [$errMSG]");
                }
                exit 1;
            };
            $SIG{__WARN__}  = sub
            {
                my $msgALL = join("\n", @_);
                foreach my $errMSG (split(/[\r\n]+/, $msgALL))
                {
                    printLOG('Signal', "Monitor Wanr: [$errMSG]");
                }
            };
            $SIG{'INT'}  = sub
            {
                print "\r";
                printLOG('Signal', "Monitor Interruptted");
                exit 1;
            };

            # Open Monitor Logfile
            if(defined $LOGFH)
            {
                open $MONLOGFH, ">>:unix:encoding(UTF8)", "$gFName{'RESULT_DIR'}/$gFName{'MONITOR_LOG'}";
            }

            # HP-UX
            # ---------------------------------------------------------
            # procs memory page faults cpu
            # r b w avm free re at pi po fr de sr in sy cs us sy id
            # 2 0 0 52260 24324 9 4 0 0 0 0 1 109 427 81 2 1 97
            # 2 0 0 52260 24285 0 0 0 0 0 0 0 110 207 90 0 0 99

            # Linux
            # ---------------------------------------------------------
            # procs -----------memory---------- ---swap-- -----io---- --system-- -----cpu-----
            #  r  b   swpd   free   buff  cache   si   so    bi    bo   in   cs us sy id wa st
            #  0  0      0 7998564 421488 6269784    0    0     4     9    0    1  0  0 99  0  0
            #  0  0      0 7998672 421488 6269784    0    0     0     4 2666 4821  0  0 99  0  0

            # AIX
            # ---------------------------------------------------------
            # System configuration: lcpu=80 mem=327680MB
            #
            # kthr    memory              page              faults        cpu
            # ----- ----------- ------------------------ ------------ -----------
            #  r  b   avm   fre  re  pi  po  fr   sr  cy  in   sy  cs us sy id wa
            #  3 10 13571029 62069606   0   0   0 16128 16113   0 10430 34931 59857  4  4 83  9
            #  5 12 13571029 62069683   0   0   0 14717 14718   0 10950 30401 63021  3  4 83 10

            # Get Parent Process ID
            my $parentPID = getppid();
            if($parentPID > 1)
            {
                printLOG('Monitor', "Monitor Get Parent Process [$parentPID]");
            }
            else
            {
                die "Cannot Get Valid Parent Process ID [$parentPID]";
            }

            # Get CPU Idle Location in [vmstat]
            my @vmInfo = execOS('vmstat 1 2', 'ARRAY');
            $vmInfo[$#vmInfo - 2] =~ s/\A\s+|\s+\z//g;
            my $idleLoc = 0;
            foreach(split(/\s+/, $vmInfo[$#vmInfo - 2]))
            {
                if($_ eq 'id')
                {
                    last;
                }
                else
                {
                    $idleLoc ++;
                }
            }
            printLOG('selfMonitor', "Get CPU Idle Location [$idleLoc]", 'L');

            # do Monitor
            my $CPU_MIN_COUNT = 0;
            my $START_TIME = time;
            while($gENV{'SM_INTERVAL'} > 0 and sleep $gENV{'SM_INTERVAL'})
            {
                # Monitor check for CPU
                if($gENV{'CPU_MIN_IDLE'} >= 0)
                {
                    # Get Current CPU Usage
                    my $cpuIdle = execOS('vmstat 1 2 | tail -1');
                    $cpuIdle =~ s/\A\s+|\s+\z//g;
                    $cpuIdle = (split(/\s+/, $cpuIdle))[$idleLoc];
                    printLOG('selfMonitor', "Get CPU Idle [$cpuIdle]", 'L');

                    # Killed Parent Process when CPU Idle less than 10
                    if($cpuIdle <= $gENV{'CPU_MIN_IDLE'})
                    {
                        $CPU_MIN_COUNT ++;
                    }
                    else
                    {
                        $CPU_MIN_COUNT = 0;
                    }

                    if($CPU_MIN_COUNT > 3)
                    {
                        if($gENV{'QUIET_MODE'})
                        {
                            print "BETHUNE_SERVER_ERROR:Collection stopped due to CPU Busy (Idle = $cpuIdle)\n\n";
                        }
                        else
                        {
                            printLOG('selfMonitor', "");
                            printLOG('selfMonitor', "================================================================================");
                            printLOG('selfMonitor', "!!! Collection stopped due to CPU busy (Idle = $cpuIdle) !!!");
                            printLOG('selfMonitor', "Solutions (Choose one):");
                            printLOG('selfMonitor', "  1. Re-run the script at free time (recommendation)");
                            printLOG('selfMonitor', "  2. Modify Config [$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}], set [CPU_MIN_IDLE] from [$gENV{'CPU_MIN_IDLE'}] to [-1]");
                            printLOG('selfMonitor', "  3. Modify Config [$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}], set [SM_INTERVAL] to to [0] which will disable monitor");
                            printLOG('selfMonitor', "================================================================================");
                            printLOG('selfMonitor', "");
                        }
                        kill 9, $parentPID;
                        last;
                    }
                }

                # Monitor check for free space
                if($gENV{'DIR_MIN_SIZE'} > 0)
                {
                    # Get Directory Free Space
                    my $dirFree = getDirFree($gFName{'RESULT_DIR'});
                    printLOG('selfMonitor', "Get Dir Free [$dirFree]", 'L');

                    if($dirFree <= $gENV{'DIR_MIN_SIZE'})
                    {
                        if($gENV{'QUIET_MODE'})
                        {
                            print "BETHUNE_SERVER_ERROR:Collection stopped due to Directory almost full (Free Space = $dirFree MB)\n\n";
                        }
                        else
                        {
                            printLOG('selfMonitor', "");
                            printLOG('selfMonitor', "================================================================================");
                            printLOG('selfMonitor', "!!! Collection stopped due to directory almost full (Free Space = $dirFree MB) !!!");
                            printLOG('selfMonitor', "Solutions (Choose one):");
                            printLOG('selfMonitor', "  1. Move scripts to a space which has more than 1GB free space (recommendation)");
                            printLOG('selfMonitor', "  2. Delete some garbage file in current device, and then re-run the scripts");
                            printLOG('selfMonitor', "  3. Modify Config [$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}], set [DIR_MIN_SIZE] from [$gENV{'DIR_MIN_SIZE'}] to [-1]");
                            printLOG('selfMonitor', "  4. Modify Config [$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}], set [SM_INTERVAL] to to [0] which will disable monitor");
                            printLOG('selfMonitor', "================================================================================");
                            printLOG('selfMonitor', "");
                        }
                        kill 9, $parentPID;
                        last;
                    }
                }

                # Monitor check for running time
                if($gENV{'MAX_RUN_TIME'} > 0)
                {
                    # Get Running Time
                    my $runTime = time - $START_TIME;
                    printLOG('selfMonitor', "Get Running Time [$runTime]", 'L');

                    if($runTime > $gENV{'MAX_RUN_TIME'})
                    {
                        if($gENV{'QUIET_MODE'})
                        {
                            print "BETHUNE_SERVER_ERROR:Collection stopped due to max running time (Runing time = $runTime seconds)\n\n";
                        }
                        else
                        {
                            printLOG('selfMonitor', "");
                            printLOG('selfMonitor', "================================================================================");
                            printLOG('selfMonitor', "!!! Collection stopped due to max running time (Runing time = $runTime seconds) !!!");
                            printLOG('selfMonitor', "Solutions (Choose one):");
                            printLOG('selfMonitor', "  1. Tuning steps which costs most time (recommendation)");
                            printLOG('selfMonitor', "  2. Contact developers for help");
                            printLOG('selfMonitor', "  3. Modify Config [$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}], set [MAX_RUN_TIME] from [$gENV{'MAX_RUN_TIME'}] to [-1]");
                            printLOG('selfMonitor', "  4. Modify Config [$gFName{'CONFIG_DIR'}/$gFName{'LIB_CONFIG'}], set [SM_INTERVAL] to to [0] which will disable monitor");
                            printLOG('selfMonitor', "================================================================================");
                            printLOG('selfMonitor', "");
                        }
                        kill 9, $parentPID;
                        last;
                    }
                }
            }

            exit 0;
        }
        # Parent Process
        else
        {
            sleep 3;
        }
    }
}


################################################################################
##                                                                            ##
## 18. timeAdd: Add Some Seconds to a Time String/Array                       ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    Type 1:                                                                 ##
##       1. Number : Year                                                     ##
##       2. Number : Month                                                    ##
##       3. Number : Day                                                      ##
##       4. Number : Hour                                                     ##
##       5. Number : Minute                                                   ##
##       6. Number : Second                                                   ##
##       7. Number : Seconds to be added                                      ##
##    Type 2:                                                                 ##
##       1. String : Time String format YYYY-MM-DD HH24:MI:SS                 ##
##       2. Number : Seconds to be added                                      ##
## Output Params                                                              ##
##    Type 1:                                                                 ##
##       1. Array  : A Formatted Time Array                                   ##
##    Type 2:                                                                 ##
##       1. String : A Formatted Time String                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub timeAdd($$;$$$$$)
{
    my ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond, $tAdd);
    if($#_ == 6)
    {
        ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond, $tAdd) = @_;
    }
    elsif($#_ == 1)
    {
        $tAdd = $_[1];
        ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond) = split(/[^\d]+/, $_[0]);
    }
    else
    {
        printLOG('timeAdd', 'Invalid argvs ['.join('] [', @_).']')
    }

    $tSecond += $tAdd;

    if($tSecond >= 60)
    {
        $tMinute += int($tSecond / 60);
        $tSecond = $tSecond % 60;
    }
    if($tMinute >= 60)
    {
        $tHour  += int($tMinute / 60);
        $tMinute = $tMinute % 60;
    }
    if($tHour >= 24)
    {
        $tDay += int($tHour / 24);
        $tHour = $tHour % 24;
    }

    while(1)
    {
        if($tDay > 31 and ($tMonth == 1 or $tMonth == 3 or $tMonth == 5 or $tMonth == 7 or $tMonth == 8 or $tMonth == 10))
        {
            $tMonth ++;
            $tDay   -= 31;
        }
        elsif($tDay > 31 and $tMonth == 12)
        {
            $tYear  ++;
            $tMonth  = 1;
            $tDay   -= 31;
        }
        elsif($tDay > 30 and ($tMonth == 4 or $tMonth == 6 or $tMonth == 9 or $tMonth == 11))
        {
            $tMonth ++;
            $tDay   -= 30;
        }
        elsif($tMonth == 2 and $tDay > 28)
        {
            if(($tYear % 100 == 0 and ($tYear % 400) == 0)
            or ($tYear % 100 > 0  and ($tYear % 4) == 0))
            {
                if($tDay > 29)
                {
                    $tDay   -= 29;
                    $tMonth  = 3;
                }
                else
                {
                    last;
                }
            }
            else
            {
                $tDay   -= 28;
                $tMonth  = 3;
            }
        }
        else
        {
            last;
        }
    }

    if(wantarray)
    {
        return ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond);
    }
    else
    {
        return sprintf("%04d-%02d-%02d %02d:%02d:%02d", $tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond);
    }
}


################################################################################
##                                                                            ##
## 18. timeMinus: Minus Some Seconds to a Time String/Array                   ##
## -------------------------------------------------------------------------- ##
## Input Params                                                               ##
##    Type 1:                                                                 ##
##       1. Number : Year                                                     ##
##       2. Number : Month                                                    ##
##       3. Number : Day                                                      ##
##       4. Number : Hour                                                     ##
##       5. Number : Minute                                                   ##
##       6. Number : Second                                                   ##
##       7. Number : Seconds to be minuend                                    ##
##    Type 2:                                                                 ##
##       1. String : Time String format YYYY-MM-DD HH24:MI:SS                 ##
##       2. Number : Seconds to be minuend                                    ##
## Output Params                                                              ##
##    Type 1:                                                                 ##
##       1. Array  : A Formatted Time Array                                   ##
##    Type 2:                                                                 ##
##       1. String : A Formatted Time String                                  ##
## Ref. Function                                                              ##
##    <None>                                                                  ##
## Ref. Parameter                                                             ##
##    <None>                                                                  ##
##                                                                            ##
################################################################################
sub timeMinus($$;$$$$$)
{
    my ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond, $tMinus);
    if($#_ == 6)
    {
        ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond, $tMinus) = @_;
    }
    elsif($#_ == 1)
    {
        $tMinus = $_[1];
        ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond) = split(/[^\d]+/, $_[0]);
    }
    else
    {
        printLOG('timeMinus', 'Invalid argvs ['.join('] [', @_).']')
    }

    $tSecond -= $tMinus;

    if($tSecond < 0)
    {
        $tMinute -= int((60 - $tSecond) / 60);
        $tSecond  = 60 - (60 - $tSecond) % 60;
    }
    if($tMinute < 0)
    {
        $tHour   -= int((60 - $tMinute) / 60);
        $tMinute  = 60 - (60 - $tMinute) % 60;
    }
    if($tHour < 0)
    {
        $tDay  -= int((24 - $tHour) / 24);
        $tHour  = 24 - (24 - $tHour) % 24;
    }

    while($tDay < 1)
    {
        #  $tMonth == 1 or $tMonth == 3 or $tMonth == 5 or $tMonth == 7 or $tMonth == 8 or $tMonth == 10
        if($tMonth == 2 or $tMonth == 4 or $tMonth == 6 or $tMonth == 8 or $tMonth == 9 or $tMonth == 11)
        {
            $tMonth --;
            $tDay   += 31;
        }
        #     $tMonth == 12
        elsif($tMonth == 1)
        {
            $tYear  --;
            $tMonth  = 12;
            $tDay   += 31;
        }
        #     $tMonth == 4 or $tMonth == 6 or $tMonth == 9 or $tMonth == 11
        elsif($tMonth == 5 or $tMonth == 7 or $tMonth == 10 or $tMonth == 12)
        {
            $tMonth --;
            $tDay   += 30;
        }
        #     $tMonth == 2
        elsif($tMonth == 3)
        {
            $tMonth  = 2;
            if(($tYear % 100 == 0 and ($tYear % 400) == 0)
            or ($tYear % 100 > 0  and ($tYear % 4) == 0))
            {
                $tDay   += 29;
            }
            else
            {
                $tDay   += 28;
            }
        }
    }

    if(wantarray)
    {
        return ($tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond);
    }
    else
    {
        return sprintf("%04d-%02d-%02d %02d:%02d:%02d", $tYear, $tMonth, $tDay, $tHour, $tMinute, $tSecond);
    }
}


1;
