#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 29/09/16 | Shield some internal used variable in result           ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 17/11/16 | Add Monitor for Node Robot                             ##
## 1.1.1   | 21/11/16 | Version [1.1.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 26/04/17 | Add Exception Capture when Calling sub-Tasks           ##
## 2.2.0   | 05/05/17 | Version [2.2.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use Sys::Hostname;
use BTTools;
use BTConfig;


# 1. Global Variable
# ------------------------------------------------------------------------------
our $startTime = time();
$gFName{'RESULT_DIR'} = '.';


# 2. Get Server Listen Info
# ------------------------------------------------------------------------------
$gENV{'LISTEN_NODE'}  = shift @ARGV;
$gENV{'LISTEN_PORT'}  = shift @ARGV;


# 3. Connect to Server
# ------------------------------------------------------------------------------
our $netFH = openSocket($gENV{'LISTEN_NODE'}, $gENV{'LISTEN_PORT'});


# 4. Get Host Basic (Type/Hostname)
# ------------------------------------------------------------------------------
$gENV{'OS_TYPE'} = $^O;
printLOG("NodeRobot", "OS Type [$gENV{'OS_TYPE'}]", 'L');
$gENV{'HOSTNAME'} = hostname;
if($gENV{'OS_TYPE'} eq 'MSWin32')
{
    $gENV{'HOSTNAME'} = uc($gENV{'HOSTNAME'});
}
elsif($gENV{'OS_TYPE'} eq 'aix' and (not defined $ENV{'AIX_VERSION'}))
{
    $ENV{'AIX_VERSION'} = execOS('oslevel -s 2>/dev/null');
    printLOG('NodeRobot', "Set AIX Version [$ENV{'AIX_VERSION'}]");
}
printLOG("NodeRobot", "Host Name [$gENV{'HOSTNAME'}]");


# 5. Get Node Parameters
# ------------------------------------------------------------------------------
printLOG("GET_PARAMS", $gENV{'HOSTNAME'});
while(1)
{
    # Read Parameters
    my ($parName, $parValue);
    $parName = $netFH->getline;
    $parName =~ s/\r|\n//g;

    # Exit when get COMPLETED
    if($parName eq 'COMPLETED')
    {
        last;
    }

    # Set Parameters
    ($parName, $parValue) = split(/\|/, $parName);
    $gENV{$parName} = $parValue;
    printLOG("NodeRobot", "Get Parameter [$parName] = [$parValue]", 'L');
}


# 6. Set PATH in Remote Node
# ------------------------------------------------------------------------------
$ENV{'PATH'} = $gENV{'PATH'};
printLOG("NodeRobot", "Set PATH [$ENV{'PATH'}]", 'L');


# 7. Signal Capture : Capture Some Signal by %SIG Var
# ------------------------------------------------------------------------------
sub ExceptionWarn
{
    my $ErrMSG = shift;
    $ErrMSG =~ s/[\r\n]+//g;
    printLOG("NodeWarn", $ErrMSG);
}
sub ExceptionOut
{
    my $ErrMSG = shift;
    $ErrMSG =~ s/[\r\n]+//g;
    printLOG("NodeError", $ErrMSG);
    exit 1;
}
$SIG{__DIE__}  = \&ExceptionOut;
$SIG{'INT'}    = \&ExceptionOut;
$SIG{__WARN__} = \&ExceptionWarn;
# Start Monitor
selfMonitor;

# 8. Check Node Script
# ------------------------------------------------------------------------------
printLOG("NodeRobot", "Collect Node Resources for [$gENV{'HOSTNAME'}]");
printLOG("CHECKER", "NODE_RESOURCE:$gENV{'HOSTNAME'}");
my $pReply = $netFH->getline;
$pReply =~ s/\r|\n//g;
printLOG("NodeRobot", "Received Primary Node Reply [$pReply]", 'L');
if($pReply eq 'PASSED')
{
    printLOG("NodeRobot", "Node Check Passed in Primary Node");
}
else
{
    printLOG("NodeRobot", $pReply);
    exit 1;
}


# 9. doing Collection Task
# ------------------------------------------------------------------------------
# Doing Task
foreach my $cltItem (keys %gOSCollect)
{
    if($gOSCollect{$cltItem} ne 'ENABLE')
    {
        printLOG("Warn", "Collection Task [$cltItem] Skip due to Status [$gOSCollect{$cltItem}]");
    }
    elsif(-f "$cltItem.pm"
    or -f "/tmp/$cltItem.pm"
    or -f "$gFName{'LIB_DIR'}/$cltItem.pm")
    {
        printLOG("NodeRobot", "Calling Task [$cltItem]", 'L');
        eval
        {
            require "$cltItem.pm" or require "/tmp/$cltItem.pm" or require "$gFName{'LIB_DIR'}/$cltItem.pm";
            my $taskTime = time();
            $cltItem->main;
            printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','TIME','$cltItem','".(time() - $taskTime)."'");
        };
        if ($@)
        {
            printLOG("BX_BATCH_CONTROL", "Failed to Call Task [$@]");
            printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','TIME','$cltItem','0'");
        }
    }
    else
    {
        printLOG("Warn", "Task Module not Found [$cltItem]");
    }
}


# 10. Send Var and Env
# ------------------------------------------------------------------------------
if(not exists $ENV{'BTROBOT_LOCAL'})
{
    printLOG("NodeRobot", "Sending Remote Variable and Environments");
    $gENV{'CLT_TIME'} = "$1-$2-$3 $4:$5:$6" if($gENV{'CLT_TIME'} =~ m/\A(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\z/);
    my $veNum = 0;
    foreach my $varName (keys %gENV)
    {
        if($varName eq 'EXTINST_TYPE'
        or $varName eq 'INST_TYPE'
        or $varName eq 'OBJ_SCHEMA'
        or $varName eq 'SQL_LIST')
        {
            next;
        }
        else
        {
            $veNum ++;
            my $varValue =  $gENV{$varName};
            $varValue    =~ s/'/''/g;
            printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','VAR_R','$varName','$varValue'");
        }
    }
    foreach my $envName (keys %ENV)
    {
        $veNum ++;
        my $envValue =  $ENV{$envName};
        $envValue    =~ s/'/''/gm;
        $envValue    =~ s/[\r\n]+/'||CHR(10)||'/gm;
        printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','ENV_R','$envName','$envValue'");
    }
    printLOG("STATUS", "BX_BATCH_CONTROL|$veNum|COMPLETED");
}


# 11. Send Completed Tips
# ------------------------------------------------------------------------------
printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','TIME','NodeRobot','".(time() - $startTime)."'");
printLOG("COMPLETE", "");
# Stop Monitor Process
if($gENV{'MONITOR_PID'} > 1)
{
    printLOG('Monitor', "Stop Monitor Process [$gENV{'MONITOR_PID'}]");
    kill 9, $gENV{'MONITOR_PID'};
}
