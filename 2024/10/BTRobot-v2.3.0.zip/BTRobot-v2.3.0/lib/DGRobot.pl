#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 19/09/16 | Move SQL Statement to Config File                      ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 29/09/16 | Shield some internal used variable in result           ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 17/11/16 | Add Monitor for DG Robot                               ##
## 1.1.1   | 21/11/16 | Version [1.1.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 30/11/16 | Fix bug in v1.1.1, Lead to DG collection error         ##
## 1.1.2   | 01/12/16 | Version [1.1.2] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 04/01/17 | Get os type in the begining of collection              ##
## 1.1.4   | 12/01/17 | Version [1.1.4] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use Sys::Hostname;
use utf8;
use BTTools;
use DBTools;
use BTConfig;



# 1. Global Parameters
# ------------------------------------------------------------------------------
our $startTime = time();
$gFName{'RESULT_DIR'} = '.';


# 2. Get Server Listen Info
# ------------------------------------------------------------------------------
$gENV{'LISTEN_NODE'} = shift @ARGV;
$gENV{'LISTEN_PORT'} = shift @ARGV;


# 3. Connect to Server
# ------------------------------------------------------------------------------
our $netFH = openSocket($gENV{'LISTEN_NODE'}, $gENV{'LISTEN_PORT'});


# 4. Get OS Hostname
# ------------------------------------------------------------------------------
$gENV{'HOSTNAME'} = hostname;
$gENV{'OS_TYPE'}  = $^O;
if($gENV{'OS_TYPE'} eq 'MSWin32')
{
    $gENV{'HOSTNAME'} = uc($gENV{'HOSTNAME'});
}
printLOG("DGRobot", "OS Hostname : [$gENV{'HOSTNAME'}]");


# 5. Get Node Parameters
# ------------------------------------------------------------------------------
printLOG("GET_PARAMS", $gENV{'HOSTNAME'});
while(1)
{
    # Read Parameters
    my ($parName, $parValue);
    $parName = $netFH->getline;
    $parName =~ s/\r|\n//g;

    # Exit if Get COMPLETED
    if($parName eq 'COMPLETED')
    {
        last;
    }

    # Set Parameters
    ($parName, $parValue) = split(/\|/, $parName);
    $gENV{$parName} = $parValue;
    printLOG("DGRobot", "Get Parameter [$parName] = [$parValue]", 'L');
}


# 6. Signal Capture : Capture Some Signal by %SIG Var
# ------------------------------------------------------------------------------
sub ExceptionWarn
{
    my $ErrMSG = shift;
    $ErrMSG =~ s/[\r\n]+//g;
    printLOG("DGWarn", $ErrMSG);
}
sub ExceptionOut
{
    my $ErrMSG = shift;
    $ErrMSG =~ s/[\r\n]+//g;
    printLOG("DGError", $ErrMSG);
    exit 1;
}
$SIG{__WARN__} = \&ExceptionWarn;
$SIG{__DIE__}  = \&ExceptionOut;
$SIG{'INT'}    = \&ExceptionOut;
# Start Monitor
selfMonitor;


# 7. Check Environment
# ------------------------------------------------------------------------------
$gENV{'ORACLE_SID'}  = $ENV{'ORACLE_SID'};
$gENV{'ORACLE_HOME'} = $ENV{'ORACLE_HOME'};
printLOG("DGRobot", "  Oracle SID: [$ENV{'ORACLE_SID'}]");
printLOG("DGRobot", " Oracle Home: [$ENV{'ORACLE_HOME'}]");
printLOG("DGRobot", "Perl Version: [$]]"                   , 'L');
printLOG("DGRobot", " DBI Version: [$DBI::VERSION]"        , 'L');
printLOG("DGRobot", " DBD Version: [$DBD::Oracle::VERSION]", 'L');
if(defined $ENV{'PERL5LIB'})
{
    printLOG("DGRobot", "Perl Library: [$ENV{'PERL5LIB'}]" , 'L');
}


# 8. Check Running User
# ------------------------------------------------------------------------------
if(defined $ENV{'USER'})
{
    $gENV{'OS_USER'} = $ENV{'USER'};
    printLOG("DGRobot", "OS Login User (ENV:USER): [$gENV{'OS_USER'}]");
}
elsif(defined $ENV{'USERNAME'})
{
    $gENV{'OS_USER'} = $ENV{'USERNAME'};
    printLOG("DGRobot", "OS Login User (ENV:USERNAME): [$gENV{'OS_USER'}]");
}
else
{
    $gENV{'OS_USER'} = execOS('whoami 2>/dev/null');
    printLOG("DGRobot", "OS Login User (whoami): [$gENV{'OS_USER'}]");
}
if($gENV{'OS_USER'} eq 'root')
{
    die "Cannot Execute Script with root User, Please Switch to Oracle!\n";
}


# 9. Test Login Oracle
# ------------------------------------------------------------------------------
printLOG("DGRobot", "Test DB Login");
if(not connDB('DB', 'SYS', $gENV{'DB_PSWD'}, ''))
{
    foreach(split(/[\r\n]+/, $DBTools::dbError))
    {
        printLOG("DGRobot", "Connect Error: ".$_);
    }
    die "Cannot Connect to Current DB Instance";
}


# 10. Check Oracle Running, Get DB Basic Information
# ------------------------------------------------------------------------------
printLOG("DGRobot", "Get DB Basic Information");
my $sqlRes = queryDB(q{SELECT DBID, NAME, DB_UNIQUE_NAME, DATABASE_ROLE FROM V$DATABASE});
($gENV{'DBID'}, $gENV{'DB_NAME'}, $gENV{'UNIQUE_NAME'}, $gENV{'DB_ROLE'}) = @{$sqlRes->[0]};
printLOG("DGRobot", "       DBID: [$gENV{'DBID'}]");
printLOG("DGRobot", "    DB Name: [$gENV{'DB_NAME'}]");
printLOG("DGRobot", "Unique Name: [$gENV{'UNIQUE_NAME'}]");
printLOG("DGRobot", "       Role: [$gENV{'DB_ROLE'}]");
printLOG("DGRobot", "   Language: [$ENV{'NLS_LANG'}]");


# 11. Check whether DG is Valid
# ------------------------------------------------------------------------------
printLOG("DGRobot", "Collect Physical Standby Data for Unique DB Name [$gENV{'UNIQUE_NAME'}]");
printLOG("CHECKER", "PHYSICAL_DG:$gENV{'UNIQUE_NAME'}");
my $pReply = $netFH->getline;
$pReply =~ s/\r|\n//g;
printLOG("DGRobot", "Received Primary Node Reply [$pReply]", 'L');
if($pReply eq 'PASSED')
{
    printLOG("DGRobot", "DG Check Passed in Primary Node");
}
else
{
    printLOG("DGRobot", $pReply);
    exit 1;
}


# 12. Collect Physical DG Data
# ------------------------------------------------------------------------------
$gENV{'EXTINST_TYPE'} = 'DG';
foreach my $resNam (keys %gResult)
{
    if($gResult{$resNam}->{'CLASS'} =~ m/DG/)
    {
        collectDB($resNam);
    }
}


# 13. Send Collected Data to Remote
# ------------------------------------------------------------------------------
foreach my $resNam (keys %gResult)
{
    if($gResult{$resNam}->{'CLASS'} =~ m/DG/)
    {
        sendFile("$gFName{'RESULT_DIR'}/$gResult{$resNam}->{'FILE'}", $resNam);
    }
}


# 14. Send Var and Env
# ------------------------------------------------------------------------------
printLOG("DGRobot", "Sending Robot Var/Env Data");
my $veNum = 0;
foreach my $varName (keys %gENV)
{
    if($varName eq 'EXTINST_TYPE'
    or $varName eq 'INST_TYPE'
    or $varName eq 'OBJ_SCHEMA'
    or $varName eq 'SQL_LIST')
    {
        next;
    }
    else
    {
        my $varValue =  $gENV{$varName};
        $varValue    =~ s/'/''/g;
        printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','VAR_G','$varName','$varValue'");
        $veNum ++;
    }
}
foreach my $envName (keys %ENV)
{
    my $envValue =  $ENV{$envName};
    $envValue    =~ s/'/''/gm;
    $envValue    =~ s/[\r\n]+/'||CHR(10)||'/gm;
    printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','ENV_G','$envName','$envValue'");
    $veNum ++;
}
printLOG("BX_BATCH_CONTROL", "'$gENV{'HOSTNAME'}','TIME','DGRobot','".(time() - $startTime)."'");
printLOG("STATUS", "BX_BATCH_CONTROL|$veNum|COMPLETED");


# 15. Delete Logfile
# ------------------------------------------------------------------------------
unlink("$gFName{'RESULT_DIR'}/$gFName{'LOGFILE'}");
unlink("$gFName{'RESULT_DIR'}/$gFName{'DBI_TRACE_FILE'}");


# 16. Complete and Close
# ------------------------------------------------------------------------------
# Stop Monitor Process
if($gENV{'MONITOR_PID'} > 1)
{
    printLOG('Monitor', "Stop Monitor Process [$gENV{'MONITOR_PID'}]");
    kill 9, $gENV{'MONITOR_PID'};
}
printLOG("COMPLETE", "$gENV{'UNIQUE_NAME'}");
$netFH->flush;
$pReply = $netFH->getline;
$netFH->close;
