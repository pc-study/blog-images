#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 13/01/17 | Fix Bug in HP Collection (Command Option Error)        ##
## 1.1.5   | 13/01/17 | Version [1.1.5] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 13/07/17 | Add [processPar] to do parameter transform (16 to 10)  ##
## 2.2.2   | 18/07/17 | Version [2.2.2] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osParameter;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osParameter", "Begin OS Parameter Collection");

    if($gENV{'OS_TYPE'} eq 'linux')
    {
        printLOG("osParameter", "Read linux parameters from [/etc/sysctl.conf]", 'L');
        printLOG("osParameter", "==================== [ /etc/sysctl.conf ] ====================", 'L');
        if(open SYSCTLF, "<:encoding($gENV{'OS_CHARSET'})", '/etc/sysctl.conf')
        {
            while(<SYSCTLF>)
            {
                s/\r|\n//g;        # chomp;
                next if (not defined $_);
                printLOG("osParameter", $_, 'L');
                s/#.*\z//;         # Remove Ccoments at End of Line
                s/\A\s+|\s+\z//g;  # Remove Blanks at Begin/End
                &processPar($1, $2) if(m/\A(.+)\s*=\s*(.+)\z/);
            }
        }
        else
        {
            printLOG("Warn", "Cannot Read [/etc/sysctl.conf], Reason [$!]");
            printLOG("STATUS", "RD_OS_PAR|Cannot Read [/etc/sysctl.conf], Reason [$!]");
        }
        printLOG("osParameter", "==============================================================", 'L');
    }
    elsif($gENV{'OS_TYPE'} eq 'aix')
    {
        printLOG("osParameter", "Read AIX parameters by [/usr/sbin/no -a]", 'L');
        foreach (execOS('/usr/sbin/no -a', 'ARRAY'))
        {
            next if (not defined $_);
            s/#.*\z//;         # Remove Ccoments at End of Line
            s/\A\s+|\s+\z//g;  # Remove Blanks at Begin/End
            &processPar($1, $2) if(m/\A(.+)\s*=\s*(.+)\z/);
        }

        printLOG("osParameter", "Read AIX parameters by [lsattr -E -l sys0]", 'L');
        foreach (execOS('lsattr -E -l sys0', 'ARRAY'))
        {
            &processPar($1, $2) if(m/\A([^\s]+)\s+([^\s]+)\s+/);
        }

        printLOG("osParameter", "Read AIX parameters by [lsattr -E -l aio0]", 'L');
        foreach (execOS('lsattr -E -l aio0', 'ARRAY'))
        {
            &processPar($1, $2) if(m/\A([^\s]+)\s+([^\s]+)\s+/);
        }

        printLOG("osParameter", "Read AIX parameters by [ioo -o aio_maxreqs]", 'L');
        &processPar($1, $2) if(execOS('ioo -o aio_maxreqs 2>/dev/null') =~ m/\A(.+)\s*=\s*(.+)\z/);
    }
    elsif($gENV{'OS_TYPE'} eq 'solaris')
    {
        printLOG("osParameter", "Read Solaris parameters from [/etc/system]", 'L');
        printLOG("osParameter", "==================== [ /etc/system ] ====================", 'L');
        if(open SYSTEMF, "<:encoding($gENV{'OS_CHARSET'})", '/etc/system')
        {
            while(<SYSTEMF>)
            {
                s/\r|\n//g;        # chomp;
                next if (not defined $_);
                printLOG("osParameter", $_, 'L');
                s/#.*\z//;         # Remove Ccoments at End of Line
                s/\A\s+|\s+\z//g;  # Remove Blanks at Begin/End
                &processPar($1, $2) if(m/\A\s*set\s+([^=]+)\s*=\s*(.+)/);
            }
            close SYSTEMF;
        }
        else
        {
            printLOG("Warn", "Cannot Read [/etc/system], Reason [$!]");
            printLOG("STATUS", "RD_OS_PAR|Cannot Read [/etc/system], Reason [$!]");
        }
        printLOG("osParameter", "=========================================================", 'L');
    }
    elsif($gENV{'OS_TYPE'} eq 'hpux')
    {

        my $kcExists = execOS('which kctune 2>/dev/null');
        if($kcExists eq '')
        {
            my @HPPar = execOS('kmtune -l 2>/dev/null', 'ARRAY');
            if(not defined $HPPar[1])
            {
                @HPPar = execOS('kmtune 2>/dev/null', 'ARRAY');
            }
            # Remove Header
            shift @HPPar;
            foreach (@HPPar)
            {
                &processPar(split(/\s+/));
            }
        }
        else
        {
            my @HPPar = execOS('kctune 2>/dev/null', 'ARRAY');
            if(not defined $HPPar[1])
            {
                @HPPar = execOS('kctune -l 2>/dev/null', 'ARRAY');
            }
            # Remove Header
            shift @HPPar;
            foreach (@HPPar)
            {
                &processPar(split(/\s+/));
            }
        }
    }
    else
    {
        printLOG("Warn", "Unhandler OS Type [$gENV{'OS_TYPE'}] for Parameter Collection");
    }

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_PAR|COMPLETED");
    printLOG("osParameter", "Complete OS Parameter Collection");
}

sub processPar($$)
{
    my ($nam, $val) = @_;

    if($val =~ m/\A0x([\da-f]+)\z/i)
    {
        $val = hex($1);    # Convert 16 to 10
    }
    else
    {
        $val =~ s/'/''/g;   # Use Double Quote instead Single Quote
    }

    # Send OS Parameter
    printLOG("RD_OS_PAR", "'$nam','$val'");
}


1;
