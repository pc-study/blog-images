#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 26/12/16 | Fix Bug in Keyword Capture (Change ' to '')            ##
##         | 26/12/16 | Fix Bug in Content Split when Cut Position is 0        ##
##         | 30/12/16 | Split by Comma in Content when Space not Found         ##
##         | 10/01/17 | Close Log for Each Error Found                         ##
## 1.1.4   | 12/01/17 | Version [1.1.4] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osAlert;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use Encode;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Global Parameters                                                          ##
##                                                                            ##
################################################################################
our %trcCollected;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osAlert", "Begin Alert Collection");


    # Check Alert Readable, Build Alert List
    # --------------------------------------------------------------------------
    my @aN;
    foreach my $fNam ($gENV{'ORACLE_ALERT'}, $gENV{'ASM_ALERT'})
    {
        if (open ALERTF, "<:encoding($gENV{'ALT_CHARSET'})", $fNam)
        {
            close ALERTF;
            push(@aN, $fNam);
            printLOG("osAlert", "Alert Can be Read [$fNam]", 'L');
        }
        elsif($fNam ne 'NONE')
        {
            printLOG("Warn", "Cannot Read Alert [$fNam], Reason [$!]");
            printLOG("STATUS", "RD_DB_ALERT|Cannot Read Alert [$fNam], Reason [$!]");
        }
    }


    # =====================================================================
    # Loop to Collect Alert Contents for Each File in Following Steps:
    # ---------------------------------------------------------------------
    #   1. Parse Instance Name from File Name
    #   2. Find Begin Position to Read
    #   3. Read to Get Error Positions
    #   4. Read Alert Contents
    #   5. Transfer Trace File
    #   6. Close Alert File
    # =====================================================================
    foreach my $fN (@aN)
    {
        # 1. Parse Instance Name from File Name
        my $iN = $fN;
        $iN =~ s/\A.*alert\_|\.log\z//g;
        printLOG("osAlert", "Collect Alert [$fN] for Instance [$iN]");


        # ======================================================================================================
        # 2. Find Begin Position to Read
        # ------------------------------------------------------------------------------------------------------
        #    i. Init:
        #       Increment [Inc] = 50% * File Size [FS]
        #       Search Position [SP] = 50% * File Size [FS]
        #   ii. Exit When [Inc] Less Than 1
        #  iii. Seek to Search Position
        #   iv. Read First Time After Search Position
        #    v. If Time Read Less Than Expected Time, Set :
        #       [Inc] = 50% * ([FS] - [SP])
        #       [SP] = [SP] + [Inc]
        #   vi. If Time Read Big or Equal Than Expected Time, Set :
        #       [Inc] = 50% * [Inc]
        #       [SP] = [SP] - [Inc]
        #  vii. Show Read Position and Read Size
        # ======================================================================================================
        # i. Init: Increment [Inc] = 50% * File Size [FS], Search Position [SP] = 50% * File Size [FS]
        open ALERTF, "<:encoding($gENV{'ALT_CHARSET'})", $fN;
        my $fSiz  = (stat ALERTF)[7];
        my $serP  = int($fSiz / 2);
        my $incN  = $serP;
        my $maxP  = $fSiz;
        my $lDate = '9999-11-11 11:11:11';
        printLOG("RD_OS_FILESIZE", "'ALERT','$fN',$fSiz");

        # ii. Exit When [Inc] Less Than 1
        printLOG("osAlert", "Finding Position of [$gENV{'ALERT_TIME'}], File Size is [$fSiz]");
        until($incN <= 1)
        {

            # iii. Seek to Search Position
            seek(ALERTF, $serP, 0);
            <ALERTF>;

            # iv. Read First Time After Search Position
            while(<ALERTF>)
            {
                $lDate = (fmtATime($_))[0];
                if ($lDate ne '')
                {
                    last;
                }
            }

            # v. If Time Read Less Then Expected Time, Set [Inc] = 50% * [Inc] if [Inc] + [SP] > [FS]
            if($lDate lt $gENV{'ALERT_TIME'})
            {
                $incN  = int(($maxP - $serP) / 2);
                $serP += $incN;
                printLOG("osAlert", "[$lDate] Next to [$serP] by [+$incN] ...", 'L');
            }
            # vi. If Time Read Big or Equal Then Expected Time, Set [Inc] = 50% * [Inc], [SP] = [SP] - [Inc]
            else
            {
                $maxP  = $serP;
                $incN = int(($incN + 1)/2);
                $serP -= $incN;
                printLOG("osAlert", "[$lDate] back to [$serP] by [-$incN] ...", 'L');
            }
        }

        # vii. Show Read Position and Read Size
        # Loop to First Time Line
        printLOG("osAlert", "Loop to First Time Line", 'L');
        seek(ALERTF, $serP, 0);
        while (<ALERTF>)
        {
            if((fmtATime($_))[0] ne '')
            {
                last;
            }
            $serP = tell ALERTF;
        }
        if(<ALERTF>)
        {
            chomp;
            printLOG("osAlert", "Read Begin Line: ".$_, 'L');
        }
        else
        {
            printLOG("osAlert", "Read Begin Line: [No Data Need Read]", 'L');
        }
        close ALERTF;
        # Show Read Position and Read Size
        my $rdSiz = $fSiz - $serP;
        if($rdSiz > 1048576)
        {
            $rdSiz = $rdSiz / 1048576;
            $rdSiz = roundNum($rdSiz, 2)." MB";
        }
        elsif($rdSiz > 1024)
        {
            $rdSiz = $rdSiz / 1024;
            $rdSiz = roundNum($rdSiz, 2)." KB";
        }
        else
        {
            $rdSiz = $rdSiz." B";
        }
        printLOG("osAlert", "Read Alert from [$serP], Size is [$rdSiz]");


        # ======================================================================================================
        # 3. Read to Get Error Positions
        # ------------------------------------------------------------------------------------------------------
        #    i. Init Variables and Loop
        #   ii. Match and Format Log Time
        #       a. Format Time Line
        #       b. Compare Prev and Pending Error if Time Changed
        #       c. If Same Error (Time is Changed):
        #          Add Current Count to Pend Error
        #       d. If Diff Error (Time is Changed):
        #          Push Current Error Position to Position List
        #          Add Error Count, Replace Pending Info by Current
        #  iii. Match Error Code and Message
        #       a. Check whether the Error is Ignored
        #       b. If Same Error (Same Time): Add Error Count
        #       c. If Diff Error (Same Time): Init Error Count
        #       d. Save Error Position (Begin/End Line) Info
        #   iv. Match Startup
        #   vi. Match Shutdown
        #  vii. Match Mount Completed
        # viii. Match Open Completed
        #   ix. Match Shutdown Completed
        #    x. Process Last Error Info
        #       a. Same Error:
        #          Add Error Count to Pending Error Count
        #       b. Diff Error, Current Error Found:
        #          Add Current Position to List
        #          Add Current Error Count to List
        # ======================================================================================================
        # i. Init Variables and Loop
        open ALERTF, "<:encoding($gENV{'ALT_CHARSET'})", $fN;
        seek(ALERTF, $serP, 0);
        $lDate    = '1111-11-11 11:11:11';
        my $pendT = "";  # Pending Error Time
        my $pendE = "";  # Pending Error Code
        my $curT  = "";  # Current Error Time
        my %curC;        # Current Error Count    <Error Code> => Count
        my @curP;        # Current Error Position (Begining, Ending)
        my %errC;        # Error Count            <Time><Error Code> => Count
        my @erPos;       # Error Position List    <Err Begin>,<Err End>, <Err Begin>,<Err End>, ...
        my $timeNum  = 0;
        my $isUPDown = 1;
        my @datNum;
        my %datKey;
        while (<ALERTF>)
        {
            my ($time, $lBuff) = fmtATime($_);

            # ii. Match New Time
            if ($time ne '')
            {
                $lDate = $time;

                $timeNum  = ALERTF->input_line_number;
                $isUPDown = 1;

                # b. Compare Prev and Pending Error if Time Changed
                if($curT ne $lDate and scalar %curC)
                {
                    my $curE = join(',', sort keys %curC);

                    # c. If Same Error (Time is Changed):
                    if($pendE eq $curE)
                    {
                        printLOG("osAlert", "Same: $curE", 'L');

                        # Add Current Count to Pend Error
                        foreach my $x (keys %curC)
                        {
                            $errC{$pendT.$x} += $curC{$x};
                        }
                    }
                    # d. If New Error (Time is Changed):
                    else
                    {
                        printLOG("osAlert", "New: $curE", 'L');

                        # Push Current Error Position to Position List
                        push(@erPos, @curP);

                        # Add Error Count, Replace Pending Info by Current
                        foreach my $x (keys %curC)
                        {
                            $errC{$curT.$x} = $curC{$x};
                        }

                        # Move Current Info to Pending
                        $pendE = $curE;
                        $pendT = $curT;
                    }

                    undef %curC;
                    undef @curP;
                    $curT = '';
                }
            }

            # iii. Match Error Code and Message
            if ($lBuff =~ m/(\A|\s)([A-Z]{3,4}-\d{3,5})[:\s]+(.*)/i)
            {
                my $erCod = $2;
                $curT = $lDate;

                # a. Check whether the Error is Ignored
                if(index($gENV{'ALT_IGNORE'}, $erCod) == -1)
                {
                    # Write Error List
                    # printLOG("osAlert", "Found: [$curT] [$erCod]", 'L');

                    # b. If Same Error (Same Time): Add Error Count
                    if(defined $curC{$erCod})
                    {
                        $curC{$erCod} ++;
                    }
                    # c. If New Error (Same Time): Init Error Count
                    else
                    {
                        $curC{$erCod} = 1;
                    }

                    # d. Save Error Position (Begin/End Line) Info
                    if (not scalar @curP)
                    {
                        @curP = (ALERTF->input_line_number, ALERTF->input_line_number);
                    }
                    else
                    {
                        $curP[1] = ALERTF->input_line_number;
                    }
                }
                else
                {
                    # printLOG("osAlert", "Ignored: [$curT] [$erCod]", 'L');
                }
            }
            # iv. Match Startup Message
            elsif(  $isUPDown
                and $lBuff =~ m/Starting\s+ORACLE\s+instance/i)
            {
                push(@datNum, $timeNum);
                $datKey{$timeNum}->{'TYPE'} = 'Start';
                $datKey{$timeNum}->{'TIME'} = $lDate;
                $isUPDown = 0;
                printLOG("osAlert", "Find Startup [$timeNum]", 'L');
            }
            # vi. Match Shutdown Message
            elsif( $isUPDown
                and ($lBuff =~ m/Shutting\s+down\s+instance/i
                or   $lBuff =~ m/Instance\s+terminated/i
                or   $lBuff =~ m/terminating\s+the\s+instance/i))
            {
                push(@datNum, $timeNum);
                $datKey{$timeNum}->{'TYPE'} = 'Shutdown';
                $datKey{$timeNum}->{'TIME'} = $lDate;
                $isUPDown = 0;
                printLOG("osAlert", "Find Shutdown [$timeNum]", 'L');
            }
            # vii. Match Mount Completed
            elsif($lBuff =~ m/Completed[\:\s]+ALTER\s+DATABASE\s+MOUNT/i  )
            {
                push(@datNum, ALERTF->input_line_number);
                $datKey{ALERTF->input_line_number}->{'TYPE'} = 'MOUNT';
                $datKey{ALERTF->input_line_number}->{'TIME'} = $lDate;
                printLOG("osAlert", "Find Mount Completed [".ALERTF->input_line_number."]", 'L');
            }
            # viii. Match Open Completed
            elsif($lBuff =~ m/Completed[\:\s]+ALTER\s+DATABASE\s+OPEN/i  )
            {
                push(@datNum, ALERTF->input_line_number);
                $datKey{ALERTF->input_line_number}->{'TYPE'} = 'OPEN';
                $datKey{ALERTF->input_line_number}->{'TIME'} = $lDate;
                printLOG("osAlert", "Find Open Completed [".ALERTF->input_line_number."]", 'L');
            }
            # ix. Match Shutdown Completed
            elsif($lBuff =~ m/Instance\s+shutdown\s+complete/i)
            {
                push(@datNum, ALERTF->input_line_number);
                $datKey{ALERTF->input_line_number}->{'TYPE'} = 'SHUTDOWN_COMPLETE';
                $datKey{ALERTF->input_line_number}->{'TIME'} = $lDate;
                printLOG("osAlert", "Find Shutdown Completed [".ALERTF->input_line_number."]", 'L');
            }
        }
        # x. Process Last Error Info
        if(scalar %curC)
        {
            my $curE = join(',', sort keys %curC);

            # a. Same Error: Add Count to Error Count
            if($pendE eq $curE)
            {
                printLOG("osAlert", "Same for Last: $curE", 'L');

                # Add Error Count to Pending Error Count
                foreach my $x (keys %curC)
                {
                    $errC{$pendT.$x} += $curC{$x};
                }
            }
            # b. Diff Error, Current Error Found
            else
            {
                printLOG("osAlert", "New for Last: $curE", 'L');

                # Add Current Position to List
                push(@erPos, @curP);

                # Add Current Error Count to List
                foreach my $x (keys %curC)
                {
                    $errC{$curT.$x} = $curC{$x};
                }
            }
        }
        close ALERTF;

        printLOG("osAlert", "==================== [ Alert Error Summary ] ====================", 'L');
        foreach my $x (sort keys %errC)
        {
            printLOG("osAlert", "Error [$x] Count [$errC{$x}]", 'L');
        }
        printLOG("osAlert", "=================================================================", 'L');


        # Expand Error Message Range
        printLOG("osAlert", "Expand Error Message Range");
        if(scalar @erPos)
        {
            printLOG("osAlert", "Original Range is [".join(',', @erPos)."]", 'L');

            # Expand: Expand Alert Range to Cover First/Last 50 Lines
            for(my $x = 0; $x < $#erPos; $x += 2)
            {
                printLOG("osAlert", "Expand: Read [$x ~ ".($x+1)."] is [$erPos[$x] ~ $erPos[$x+1]]", 'L');
                $erPos[$x]   = $erPos[$x]   - $gENV{'ALERT_KEEP'};
                $erPos[$x+1] = $erPos[$x+1] + $gENV{'ALERT_KEEP'};
            }
            printLOG("osAlert", "Expand Range is [".join(',', @erPos)."]", 'L');

            # Merge: Merge if Ranges is Lapped
            my $x = 1;
            while($x < $#erPos)
            {
                printLOG("osAlert", "Merge: Read [$x ~ ".($x+1)."] is [$erPos[$x] ~ $erPos[$x+1]]", 'L');
                if($erPos[$x] >= $erPos[$x + 1] - 1)
                {
                    splice(@erPos, $x, 2);
                }
                else
                {
                    $x += 2;
                }
            }
            printLOG("osAlert", "Merge Range is [".join(',', @erPos)."]", 'L');
        }

        # Process Startup/Shutdown Data
        my %upDownBound;
        for(my $x = 0; $x <= $#datNum; $x ++)
        {
            # Record End Number for Startup/Shutdown
            my $endNum = 0;

            if($datKey{$datNum[$x]}->{'TYPE'} eq 'Start')
            {
                # Found Start End (MOUNT/OPEN)
                for(my $y = $x + 1; $y <= $#datNum; $y ++)
                {
                    if($datKey{$datNum[$y]}->{'TYPE'} eq 'MOUNT')
                    {
                        $endNum = $datNum[$y];
                    }
                    elsif($datKey{$datNum[$y]}->{'TYPE'} eq 'OPEN')
                    {
                        $endNum = $datNum[$y];
                        last;
                    }
                    elsif($datKey{$datNum[$y]}->{'TYPE'} eq 'Start' or $datKey{$datNum[$y]}->{'TYPE'} eq 'Shutdown')
                    {
                        printLOG("RD_DB_ALERT", "'$iN',TO_DATE('$datKey{$datNum[$y]}->{'TIME'}','YYYY-MM-DD HH24:MI:SS'),$datNum[$y] - 0.9,'','STARTUP COMPLETED',0");
                        $endNum = $datNum[$y] - 1;
                        last;
                    }
                }

                # No End Number    -->  2 * Keep Line
                if($endNum == 0)
                {
                    $endNum = $datNum[$x] + $gENV{'ALERT_KEEP'} * 2;
                }
                # Wrong End Number --> 10 * Keep Line
                elsif($endNum > $datNum[$x] + $gENV{'ALERT_KEEP'} * 10)
                {
                    $endNum = $datNum[$x] + $gENV{'ALERT_KEEP'} * 10;
                }
                elsif(defined $datKey{$endNum})
                {
                    printLOG("RD_DB_ALERT", "'$iN',TO_DATE('$datKey{$endNum}->{'TIME'}','YYYY-MM-DD HH24:MI:SS'),$endNum + 0.1,'','STARTUP COMPLETED',0");
                }
            }
            elsif($datKey{$datNum[$x]}->{'TYPE'} eq 'Shutdown')
            {
                # Found Shutdown End (SHUTDOWN_COMPLETE)
                for(my $y = $x + 1; $y <= $#datNum; $y ++)
                {
                    if($datKey{$datNum[$y]}->{'TYPE'} eq 'SHUTDOWN_COMPLETE')
                    {
                        $endNum = $datNum[$y];
                        last;
                    }
                    elsif($datKey{$datNum[$y]}->{'TYPE'} eq 'Start' or $datKey{$datNum[$y]}->{'TYPE'} eq 'Shutdown')
                    {
                        printLOG("RD_DB_ALERT", "'$iN',TO_DATE('$datKey{$datNum[$y]}->{'TIME'}','YYYY-MM-DD HH24:MI:SS'),$datNum[$y] - 0.9,'','SHUTDOWN COMPLETED',0");
                        $endNum = $datNum[$y] - 1;
                        last;
                    }
                }

                # No End Number    --> Keep Line
                if($endNum == 0)
                {
                    $endNum = $datNum[$x] + $gENV{'ALERT_KEEP'};
                }
                # Wrong End Number --> 2 * Keep Line
                elsif($endNum > $datNum[$x] + $gENV{'ALERT_KEEP'} * 2)
                {
                    $endNum = $datNum[$x] + $gENV{'ALERT_KEEP'} * 2;
                }
                elsif(defined $datKey{$endNum})
                {
                    printLOG("RD_DB_ALERT", "'$iN',TO_DATE('$datKey{$endNum}->{'TIME'}','YYYY-MM-DD HH24:MI:SS'),$endNum + 0.1,'','SHUTDOWN COMPLETED',0");
                }
            }

            # Add Number Range to ErPos - Startup/Shutdown
            if($endNum ne 0)
            {
                # Add UP/Down Boundary
                $upDownBound{$datKey{$datNum[$x]}->{'TYPE'}.$datKey{$datNum[$x]}->{'TIME'}}->[0] = $datNum[$x];
                $upDownBound{$datKey{$datNum[$x]}->{'TYPE'}.$datKey{$datNum[$x]}->{'TIME'}}->[1] = $endNum;
                printLOG('osAlert', "Found UP/Down Boundary [$datNum[$x] ~ $endNum]", 'L');

                # Merge to ErPos
                if(scalar @erPos)
                {
                    printLOG("osAlert", "Add ($datNum[$x], $endNum) to ErPos", 'L');

                    # New Range is the Biggest
                    if($datNum[$x] >= $erPos[$#erPos] + 2)
                    {
                        push(@erPos, $datNum[$x], $endNum);
                    }
                    else
                    {
                        for(my $y = 0; $y <= $#erPos; $y += 2)
                        {

                            # 1 10 20 30 40 50 100 200 300 400 500 1000 1111 10000
                            # Example 1:     3   200: ($datNum[$x] =     3, $endNum =   200)
                                # $y = 0: $erPos[0] = 1  , $beginNum = 1, $repCount = 2
                                # $z = 0: $erPos[0] = 1  , $repCount = 4
                                # $z = 2: $erPos[2] = 20 , $repCount = 6
                                # $z = 4: $erPos[4] = 40 , $repCount = 8
                                # $z = 6: $erPos[6] = 100, $repCount = 8, $endNum = 200
                                # (1 200) 300 400 500 1000 1111 10000
                            # Example 2:    44   444: ($datNum[$x] =    44, $endNum =   444)
                                # $y = 0 : $erPos[0] = 1   , $beginNum = 0 , $repCount = 2
                                # $y = 2 : $erPos[2] = 20  , $beginNum = 0 , $repCount = 2
                                # $y = 4 : $erPos[4] = 40  , $beginNum = 40, $repCount = 2
                                # $z = 4 : $erPos[4] = 40  , $repCount = 4
                                # $z = 6 : $erPos[6] = 100 , $repCount = 6
                                # $z = 8 : $erPos[8] = 300 , $repCount = 8
                                # $z = 10: $erPos[10] = 500, $repCount = 6, $endNum = 444
                                # 1 10 20 30 (40 444) 500 1000 1111 10000
                            # Example 3:   -10    -1: ($datNum[$x] =   -10, $endNum =    -1)
                                # $y = 0: $erPos[0] = 1  , $beginNum = -10 , $repCount = 2
                                # $z = 0: $erPos[0] = 1  , $repCount = 0   , $endNum   = -1
                                # (-10 -1) 1 10 20 30 40 50 100 200 300 400 500 1000 1111 10000
                            # Example 4: 20000 30000: ($datNum[$x] = 20000, $endNum = 30000)
                                # New Range is the Biggest
                                # 1 10 20 30 40 50 100 200 300 400 500 1000 1111 10000 (20000 30000)
                            # Example 5:   128   164: ($datNum[$x] =   222, $endNum =   278)
                                # $y = 0 : $erPos[0] = 1   , $beginNum = 0   , $repCount = 2
                                # $y = 2 : $erPos[2] = 20  , $beginNum = 0   , $repCount = 2
                                # $y = 4 : $erPos[4] = 40  , $beginNum = 0   , $repCount = 2
                                # $y = 6 : $erPos[6] = 100 , $beginNum = 100 , $repCount = 2
                                # $z = 6 : $erPos[6] = 100 , $beginNum = 100 , $repCount = 2, endNum = 200
                                # 1 10 20 30 40 50 (100 200) 300 400 500 1000 1111 10000

                            my $beginNum = 0;
                            my $repCount = 2;
                            if($datNum[$x] < $erPos[$y])
                            {
                                $beginNum = $datNum[$x];
                            }
                            elsif($datNum[$x] <= $erPos[$y + 1] + 1)
                            {
                                $beginNum = $erPos[$y];
                            }

                            if($beginNum > 0)
                            {
                                for(my $z = $y; $z <= $#erPos; $z += 2)
                                {
                                    if($endNum > $erPos[$z + 1])
                                    {
                                        $repCount += 2;
                                    }
                                    elsif($endNum >= $erPos[$z] - 1)
                                    {
                                        $endNum = $erPos[$z + 1];
                                        last;
                                    }
                                    else
                                    {
                                        $repCount -= 2;
                                        last;
                                    }
                                }

                                splice(@erPos, $y, $repCount, ($beginNum, $endNum));
                                last;
                            }
                        }
                        printLOG("osAlert", "Range is [".join(',', @erPos)."]", 'L');
                    }
                }
                else
                {
                    push(@erPos, $datNum[$x], $endNum);
                    printLOG("osAlert", "First ErPos for UP/Down ($datNum[$x], $endNum)", 'L');
                }
            }
        }


        # ======================================================================================================
        # 4. Read Alert Contents
        # ------------------------------------------------------------------------------------------------------
        #    i. Init Variables
        #   ii. Format Time Line
        #  iii. Match Startup Message
        #   iv. Match Shutdown Message
        #    v. Match Checkpoint not Complete
        #   vi. Match Error Line
        #  vii. Match Trace File
        # viii. Match Incident File
        #   ix. Send Alert Contents
        #    x. Get New Range
        #       a. Add Line Gap Tips is Next Begin > Current + 1
        #       b. Get New Log Range
        #       c. Write UP/Down Trace
        #       d. Init UP/Down Trace Data
        # ======================================================================================================
        printLOG("osAlert", "Read Alert Contents");
        if(scalar @erPos)
        {
            # Open File to Searched Position
            open ALERTF, "<:encoding($gENV{'ALT_CHARSET'})", $fN;
            seek(ALERTF, $serP, 0);

            # i. Init Variables
            $lDate        = '1111-11-11 11:11:11';              # Line Date
            $isUPDown     = 1;                                  # is Valid UP/Down Line? (Avoid Duplicate in Same Time)
            my @upDownInf = ('', '');                           # Up/Down Information (Type, Time)
            my %upDownTrc;                                      # UP/Down Trace List (Traces in UP/Down Range, Indexed by Line Number)
            my $preError  = '';                                 # Pre-Found Errors (for Incident File)
            my $trcFile   = '';                                 # Pre-Found Trace File (for Alert Error)
            my $bPos      = shift(@erPos);                      # Begin Position
            my $ePos      = shift(@erPos);                      # End Position
            my $yearMin   = substr($gENV{'ALERT_TIME'}, 0, 4);  # Minimum Collection Year (used to Check Time is Invalid)
            my $yearMax   = (localtime)[5] + 1900;              # Maximum Collection Year (used to Check Time is Invalid)
            printLOG("osAlert", "Alert Year Range is [$yearMin ~ $yearMax]", 'L');
            while(<ALERTF>)
            {
                my ($time, $lBuff) = fmtATime($_);
                # ii. Format Time Line
                if ($time ne '')
                {
                    $lDate = $time;
                    $isUPDown = 1;
                }

                # Define Variables
                my $logCNT = 0;
                my $logTyp = '';

                # Check capture keywords
                foreach my $capKey (keys %gALTCapture)
                {
                    if($lBuff =~ m/$gALTCapture{$capKey}/i)
                    {
                        $logCNT = 1;
                        $logTyp = $capKey;
                    }
                }

                # Message in Error Range
                if($logTyp ne '' or ($bPos <= ALERTF->input_line_number and ALERTF->input_line_number <= $ePos))
                {
                    # Convert Single Quote
                    $lBuff =~ s/'/''/g;

                    # iii. Match Startup Message
                    #      Starting ORACLE instance (normal)
                    if( $isUPDown
                    and $lBuff =~ m/Starting\s+ORACLE\s+instance/i)
                    {
                        $logTyp    = 'Start';
                        $logCNT    = 1;
                        @upDownInf = ('Start', $lDate);
                        $isUPDown  = 0;
                    }
                    # iv. Match Shutdown Message
                    #     Shutting down instance (immediate)
                    #     Shutting down instance (abort)
                    #     CKPT (ospid: 44672): terminating the instance
                    #     Instance terminated by USER, pid = 27395
                    elsif( $isUPDown
                    and (  $lBuff =~ m/Shutting\s+down\s+instance/i
                    or     $lBuff =~ m/Instance\s+terminated/i
                    or     $lBuff =~ m/terminating\s+the\s+instance/i))
                    {
                        $logTyp    = 'Shutdown';
                        $logCNT    = 1;
                        @upDownInf = ('Shutdown', $lDate);
                        $isUPDown  = 0;
                    }
                    # vi. Match Error Line
                    #     ORA-12012: error on auto execute of job 44
                    elsif($lBuff =~ m/(\A|\s)([A-Z]{3,4}-)(\d{3,5})[:\s]+(.*)/i)
                    {
                        my ($eTy, $eCd) = ($2, $3);

                        # Add Error and Mapping Trace
                        if(defined $errC{$lDate.$eTy.$eCd})
                        {
                            $logCNT   = $errC{$lDate.$eTy.$eCd};
                            delete $errC{$lDate.$eTy.$eCd};

                            # Make Error Code
                            if(length($eCd) == 3)
                            {
                                $logTyp = $eTy.'00'.$eCd;
                            }
                            elsif(length($eCd) == 4)
                            {
                                $logTyp = $eTy.'0'.$eCd;
                            }
                            else
                            {
                                $logTyp = $eTy.$eCd;
                            }
                            $preError = $logTyp;

                            # if Trace Exists and Trace for Error Code not Found, then Add to List
                            if($trcFile ne '')
                            {
                                getTrace('TRACE', $logTyp, $lDate, $iN, $trcFile);
                                $trcFile = '';
                            }
                        }
                    }
                    # vii. Match Trace File
                    #      Errors in file /oracle/app/oracle/diag/rdbms/crmdb2/crmdb22/trace/crmdb22_ora_16919.trc  (incident=1091452):
                    #     trace file /u01/app/oracle/diag/rdbms/rcdb/rcdb2/trace/rcdb2_diag_44592_20160402080844.trc
                    elsif( $lBuff =~ m@Errors\s+in\s+file\s+(.+\.trc)@i
                        or $lBuff =~ m@trace\s+file\s+(.+\.trc)@i)
                    {
                        $trcFile = $1;
                        printLOG("osAlert", "Get Trace [$trcFile]", 'L');

                        # Sending for Startup/Shutdown Trace
                        if( defined $upDownBound{$upDownInf[0].$upDownInf[1]}
                        and ALERTF->input_line_number > $upDownBound{$upDownInf[0].$upDownInf[1]}->[0]
                        and ALERTF->input_line_number < $upDownBound{$upDownInf[0].$upDownInf[1]}->[1])
                        {
                            getTrace('TRACE', $upDownInf[0], $upDownInf[1], $iN, $trcFile);
                        }
                    }
                    # viii. Match Incident File
                    #       Incident details in: /oracle/app/oracle/diag/rdbms/crmdb2/crmdb22/incident/incdir_1091452/crmdb22_ora_16919_i1091452.trc
                    elsif($lBuff =~ m@Incident\s+details\s+in[:\s]+(.+\.trc)@i)
                    {
                        my $incFile = $1;
                        printLOG("osAlert", "Get Incident [$incFile]", 'L');

                        # if Incident File Exists and Incident for Error Code not Found and pre-Error Defined, then Add to List
                        getTrace('INCIDENT', $preError, $lDate, $iN, $incFile);

                        # Sending for Startup/Shutdown Incident
                        if( defined $upDownBound{$upDownInf[0].$upDownInf[1]}
                        and ALERTF->input_line_number > $upDownBound{$upDownInf[0].$upDownInf[1]}->[0]
                        and ALERTF->input_line_number < $upDownBound{$upDownInf[0].$upDownInf[1]}->[1])
                        {
                            getTrace('INCIDENT', $upDownInf[0], $upDownInf[1], $iN, $incFile);
                        }
                    }

                    # ix. Send Alert Contents
                    while(length($lBuff) > 3000)
                    {
                        my $cutLoc = rindex($lBuff, " ", 3000);
                        $cutLoc = rindex($lBuff, ",", 3000) if($cutLoc == 0);
                        last if($cutLoc == 0);

                        printLOG("osAlert", "Cut Position is [$cutLoc]", 'L');
                        printLOG("RD_DB_ALERT", "'$iN',TO_DATE('$lDate','YYYY-MM-DD HH24:MI:SS'),".ALERTF->input_line_number.",'$logTyp','".substr($lBuff, 0, $cutLoc)."',$logCNT");

                        $lBuff = substr($lBuff, $cutLoc);
                        $logTyp = '';
                        $logCNT = 0;
                    }
                    if($lBuff !~ m/\A\s*\z/)
                    {
                        printLOG("RD_DB_ALERT", "'$iN',TO_DATE('$lDate','YYYY-MM-DD HH24:MI:SS'),".ALERTF->input_line_number.",'$logTyp','$lBuff',$logCNT");
                    }
                }

                # x. Get New Range
                if(ALERTF->input_line_number >= $ePos)
                {
                    # a. Get New Log Range
                    if(defined $erPos[1])
                    {
                        printLOG("RD_DB_ALERT", "'$iN',TO_DATE('$lDate','YYYY-MM-DD HH24:MI:SS'),".ALERTF->input_line_number." + 0.1,'','......',0");
                        $bPos = shift @erPos;
                        $ePos = shift @erPos;
                    }
                    else
                    {
                        last;
                    }

                    # b. Init UP/Down Information
                    @upDownInf = ('', '');
                }
            }
            close ALERTF;
        }
    }

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_DB_ALERT|COMPLETED");
    printLOG("osAlert", "Complete Alert Collection");
}


################################################################################
##                                                                            ##
## fmtATime: Format Alert Time                                                ##
##                                                                            ##
################################################################################
sub fmtATime
{
    my $lBuff = shift;
    $lBuff =~ s/\r|\n//g;

    if ($lBuff =~ m/\A(Mon|Tue|Wed|Thu|Fri|Sat|Sun)?\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|1月|2月|3月|4月|5月|6月|7月|8月|9月|10月|11月|12月)\s+([0-9]*)\s+([0-9]*:[0-9]*:[0-9]*)\s*[^\s]*\s+([0-9][0-9][0-9][0-9])(.*)/)
    {
        # Thu Mar 03 09:49:00 2011
        # Sat Mar 26 16:52:17 GMT+08:00 2016Thread 1 advanced to log sequence 232122 (LGWR switch)

        # 1. Get Year
        my $lDate = $5;

        # 1. Get Month
        if    ($2 eq 'Jan' or $2 eq '1月')
        {
            $lDate = $lDate.'-01-';
        }
        elsif ($2 eq 'Feb' or $2 eq '2月')
        {
            $lDate = $lDate.'-02-';
        }
        elsif ($2 eq 'Mar' or $2 eq '3月')
        {
            $lDate = $lDate.'-03-';
        }
        elsif ($2 eq 'Apr' or $2 eq '4月')
        {
            $lDate = $lDate.'-04-';
        }
        elsif ($2 eq 'May' or $2 eq '5月')
        {
            $lDate = $lDate.'-05-';
        }
        elsif ($2 eq 'Jun' or $2 eq '6月')
        {
            $lDate = $lDate.'-06-';
        }
        elsif ($2 eq 'Jul' or $2 eq '7月')
        {
            $lDate = $lDate.'-07-';
        }
        elsif ($2 eq 'Aug' or $2 eq '8月')
        {
            $lDate = $lDate.'-08-';
        }
        elsif ($2 eq 'Sep' or $2 eq '9月')
        {
            $lDate = $lDate.'-09-';
        }
        elsif ($2 eq 'Oct' or $2 eq '10月')
        {
            $lDate = $lDate.'-10-';
        }
        elsif ($2 eq 'Nov' or $2 eq '11月')
        {
            $lDate = $lDate.'-11-';
        }
        elsif ($2 eq 'Dec' or $2 eq '12月')
        {
            $lDate = $lDate.'-12-';
        }
        else {
            printLOG("fmtATime", "Cannot Format Month [$2], Use [12]");
            $lDate = $lDate.'-12-';
        }

        # 3. Get Day
        if (length($3) == 1)
        {
            $lDate = $lDate."0".$3;
        }
        else
        {
            $lDate = $lDate.$3
        }

        # 4. Get Time
        $lDate    = $lDate.' '.$4;

        # 5. Return Left Buffer
        return ($lDate, $6);
    } elsif ($lBuff =~ m/\A(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(\.\d+)?([+-]\d{2}:\d{2}|Z)?\s*(.*)/)
    {
        # 1. Get Year, Month, Day, Hour, Minute, Second
        my $year   = $1;
        my $month  = $2;
        my $day    = $3;
        my $hour   = $4;
        my $minute = $5;
        my $second = $6;

        # 2. Format the date
        my $lDate = "$year-$month-$day $hour:$minute:$second";

        return ($lDate, $9 // '');
    }
    else
    {
        # Return Left Buffer
        return ('', $lBuff);
    }
}


################################################################################
##                                                                            ##
## getTrace: Get Alert Trace File                                             ##
##                                                                            ##
################################################################################
sub getTrace($$$$)
{
    my ($trcType, $logType, $logTime, $instName, $logFile) = @_;

    # Get Pure File Name, Without Directory
    my $fileNam = $logFile;
    $fileNam =~ s@\A.+[/\\]@@;

    if(defined $trcCollected{$logFile})
    {
        printLOG("getTrace", "Skip $trcType File due to Already Collected");
        printLOG("RD_DB_ALERT_TRACE", "$logTime,$instName,$logType,$trcType,$fileNam");
    }
    elsif(open TRCFILE, "<:encoding($gENV{'ALT_CHARSET'})", $logFile)
    {
        # Sending Trace File Summary Info
        printLOG("osAlert", "Begin Transfer Trace [$fileNam]");
        printLOG("RD_DB_ALERT_TRACE", "$logTime,$instName,$logType,$trcType,$fileNam");

        # Send Trace File Data
        my $trcSize = (stat TRCFILE)[7];
        my $rdPos   = 0;
        # Read First Part (Big Trace) or All (Small Trace)
        while(<TRCFILE>)
        {
            s/\r|\n//g;  # chomp;
            printLOG($fileNam, $_, 'T');
            my $rdPos = tell TRCFILE;
            if($rdPos > $gENV{'TRACE_LIMIT'} and $rdPos < $trcSize - $gENV{'TRACE_LIMIT'})
            {
                printLOG($fileNam, "=================================[ Attention ]==================================", 'T');
                printLOG($fileNam, "==> 1. Only First and Last [$gENV{'TRACE_LIMIT'}] Bytes Collected", 'T');
                printLOG($fileNam, "==> 2. Other Trace Contents are Lost", 'T');
                printLOG($fileNam, "=================================[ Attention ]==================================", 'T');
                last;
            }
        }
        # Read Last Part (Big Trace)
        if(<TRCFILE>)
        {
            seek(TRCFILE, $trcSize - $gENV{'TRACE_LIMIT'}, 0);
            <TRCFILE>;
            while(<TRCFILE>)
            {
                s/\r|\n//g;  # chomp;
                printLOG($fileNam, $_, 'T');
            }
        }

        # End of Sending
        close TRCFILE;
        printLOG("TRACE_OVER", $fileNam);
        $trcCollected{$logFile} = 1;
    }
    else
    {
        printLOG("Warn", "Cannot Read [$logFile], Reason [$!] [$@]");
        printLOG("STATUS", "RD_DB_ALERT_TRACE|Cannot Read [$logFile], Reason [$!] [$@]");
    }
}


1;
