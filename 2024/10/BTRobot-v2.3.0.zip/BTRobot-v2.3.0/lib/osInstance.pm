#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 19/09/16 | Move SQL Statement to Config File                      ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 11/07/17 | Ignore current collected instance                      ##
##         | 10/11/17 | Remove blanks after instance name                      ##
#################################################################################
package osInstance;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use DBTools;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osInstance", "Begin Extra-Instance Collection");

    # Get Extra-Instance List
    my %extInst;
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        printLOG("osInstance", "Search Extra-Instance for Windows");

        foreach (execOS('WMIC PROCESS WHERE CAPTION="ORACLE.EXE" GET COMMANDLINE | find "ORACLE.EXE"', 'ARRAY'))
        {
            # c:\oracle\product\10.2.0\db_1\bin\ORACLE.EXE WINDB
            if($_ ne '')
            {
                printLOG("osInstance", "Get Running Instance [$_]", 'L');
                my ($oraHome, $iNam) = split(/\s+/);

                $oraHome =~ s/.bin.+\z//i;
                $extInst{$iNam} = $oraHome;
            }
        }
    }
    else
    {
        printLOG("osInstance", "Search Extra-Instance for Linux/Unix");
        foreach my $iNam (getProc('ora_ckpt'))
        {
            $iNam =~ s/\r|\n|\s//g;
            $iNam =~ s/\A.+ora\_ckpt\_//;
            my $oraHome = 'NONE';

            # Exclude ASM Instance
            if($iNam !~ m/\A\+\z/)
            {
                # Read Oracle Home from File
                printLOG("osInstance", "==================== [ Read OraHome from /etc/oratab ] ====================", 'L');
                if(open ORATABF, "<:encoding($gENV{'OS_CHARSET'})", '/var/opt/oracle/oratab'  # Get ASM Home for SunOS
                   or open ORATABF, "<:encoding($gENV{'OS_CHARSET'})", '/etc/oratab')
                   {        # Get ASM Home for Other Unix OS
                    while(<ORATABF>)
                    {                           # BXDB:/u01/app/oracle/product/11.2.0/db_1:Y
                        s/\r|\n//g;  # chomp;
                        printLOG("osInstance", "$_", 'L');
                        if(m/\A(\w+)\:([^\:]+)\:/)
                        {
                            if(uc($1) eq uc($iNam))
                            {
                                $oraHome = $2;
                            }
                        }
                    }
                    close ORATABF;
                }
                printLOG("osInstance", "===========================================================================", 'L');

                # Read Oracle Home from [/proc] - for Linux Only
                if((not -f "$oraHome/bin/sqlplus") and $gENV{'OS_TYPE'} eq 'linux')
                {   # Get Oracle Home from [/proc] in Linux
                    if(defined (my $pInfo = (getProc("ora_ckpt_$iNam"))[0]))
                    {
                        printLOG("osInstance", "Get Process [$pInfo]", 'L');

                        # Get Process ID
                        my $pInfo = (split(/\s+/, $pInfo))[1];
                        printLOG("osInstance", "Get Process ID [$pInfo]", 'L');

                        # Get Link Item
                        $pInfo = execOS("ls -l /proc/$pInfo/exe 2>/dev/null");

                        # Get Oracle Home
                        if($pInfo =~ m/\/exe\s+\-\>\s+(.+)\/bin\/oracle\z/)
                        {
                            $oraHome = $1;
                            printLOG("osInstance", "Get Home from Link [$oraHome]");
                        }
                    }
                }

                # Set Oracle Instance and Home
                if(-f "$oraHome/bin/sqlplus")
                {
                    $extInst{$iNam} = $oraHome;
                }
                else
                {
                    printLOG("osInstance", "Use Current Oracle Home for Instance [$iNam]");
                    $extInst{$iNam} = $gENV{'ORACLE_HOME'};
                }
            }
        }
    }
    printLOG("osInstance", "Extra-Instance List : ".join(',', keys %extInst)."");


    # Collect Database-Instance Summary Data
    foreach my $iNam (keys %extInst)
    {
        # Check if current instance
        printLOG("osInstance", "Checker for: [$iNam] [$extInst{$iNam}]");
        if(uc($iNam) eq uc($gENV{'INSTANCE_NAME'}))
        {
            printLOG("osInstance", "Ignore current collected instance");
            next;
        }

        printLOG("osInstance", "Collection for: [$iNam] [$extInst{$iNam}]");
        $ENV{'ORACLE_SID'}  = $iNam;
        $ENV{'ORACLE_HOME'} = $extInst{$iNam};

        # Try to Connect Instance
        if(not connDB('DB', $gENV{'DB_USER'}, $gENV{'DB_PSWD'}, ''))
        {
            foreach(split(/[\r\n]+/, $DBTools::dbError))
            {
                printLOG("osInstance", "Connect Error: ".$_);
            }
            printLOG("osInstance", "DB Login Error with [$gENV{'DB_USER'}], Try to Connect with [SYS]");
            if(not connDB('DB', 'sys', 'oracle', ''))
            {
                foreach(split(/[\r\n]+/, $DBTools::dbError))
                {
                    printLOG("osInstance", "Connect Error: ".$_);
                }
                next;
            }
        }

        # Collect Database-Instance Summary Data
        $gENV{'EXTINST_TYPE'} = 'OTHER';
        collectDB('RD_DB_EXTINST');

        # Check Result
        if($DBTools::dbError ne 'COMPLETED')
        {
            foreach(split(/[\r\n]+/, $DBTools::dbError))
            {
                printLOG("osInstance", "Detail Error: ".$_);
            }
            printLOG("STATUS", "RD_DB_EXTINST|".$gStatus{'RD_DB_EXTINST'}->[1]);
        }
    }

    # Remove DBI in current Directory
    unlink $gFName{'DBI_TRACE_FILE'};

    # Send Collected Data
    sendFile("$gFName{'RESULT_DIR'}/$gResult{'RD_DB_EXTINST'}->{'FILE'}", 'RD_DB_EXTINST');

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_DB_EXTINST|COMPLETED");
    printLOG("osInstance", "Complete Extra-Instance Collection");
}

1;
