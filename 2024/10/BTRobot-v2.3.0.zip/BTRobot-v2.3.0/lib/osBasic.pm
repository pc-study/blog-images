#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 26/09/16 | Add 3rd Condition in Windows Memory Collection         ##
##         | 26/09/16 | Fix Bug in Windows Swap Size Collection                ##
##         | 31/10/16 | Add Kernel Version Collection for Linux                ##
## 1.1.0   | 10/11/16 | Version [1.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 15/11/16 | Add More Collection for Linux OS Version               ##
## 1.1.1   | 21/11/16 | Version [1.1.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 26/12/16 | Compatiable with Chinese Chars in Uptime               ##
## 1.1.4   | 12/01/17 | Version [1.1.4] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 16/01/17 | Compatiable with Uptime in [AM/PM]                     ##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 08/03/17 | Compatiable with Uptime with Only Minutes              ##
##         | 21/03/17 | Compatiable More Situation in Uptime                   ##
##         | 23/03/17 | Rewrite uptime conversion method                       ##
## 2.1.0   | 29/03/17 | Version [2.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 13/04/17 | Change Match Mode for [uptime] Message                 ##
## 2.2.0   | 05/05/17 | Version [2.2.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 29/08/17 | Modify in HP-UX: machinfo location and Top format      ##
##         | 19/12/18 | Set LANG to en_US when collect Uptime info             ##
## 2.2.6   | 19/12/18 | Version Released                                       ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osBasic;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osBasic", "Begin OS Information Collection");

    my $cpuC = 0;
    my $cpuM = "";
    my $memT = 0;
    my $swpT = 0;
    my $oVer = "";
    my $kVer = "";
    my $upT  = "";
    my $clockSrc = '';

    if($gENV{'OS_TYPE'} eq 'linux')
    {
        # Get Information Data
        printLOG("osBasic", "Read linux info file", 'L');
        printLOG("osBasic", "==================== [ /proc/cpuinfo ] ====================", 'L');
        if (open CPUINFOF, "<:encoding($gENV{'OS_CHARSET'})", '/proc/cpuinfo')
        {
            while(<CPUINFOF>)
            {
                s/\r|\n//g;  # chomp;
                $_ = '' if (not defined $_);
                printLOG("osBasic", "$_", 'L');
                if (m/processor/i)
                {                  # processor       : 0
                    $cpuC ++;
                }
                elsif(m/model\s+name[:\s]+(.+)/i)
                {   # model name      :        Intel(R) Core(TM) i5-3230M CPU @ 2.60GHz
                    $cpuM = $1;
                }
            }
        }
        else{
            printLOG("Warn", "Cannot Read [/proc/cpuinfo], Reason [$!]");
            printLOG("STATUS", "RD_OS_INFO|Cannot Read [/proc/cpuinfo], Reason [$!]");
        }
        printLOG("osBasic", "===========================================================", 'L');
        printLOG("osBasic", "==================== [ /proc/meminfo ] ====================", 'L');
        if (open MEMINFOF, "<:encoding($gENV{'OS_CHARSET'})", '/proc/meminfo')
        {
            while(<MEMINFOF>)
            {
                s/\r|\n//g;  # chomp;
                $_ = '' if (not defined $_);
                printLOG("osBasic", "$_", 'L');
                if(m/MemTotal[:\s]+(.+)/i)     # MemTotal:        2043204 kB
                {
                    $memT = $1;
                }
                elsif(m/SwapTotal[:\s]+(.+)/i) # SwapTotal:       4095992 kB
                {
                    $swpT = $1;
                }
            }
        }
        else{
            printLOG("Warn", "Cannot Read [/proc/meminfo], Reason [$!]");
            printLOG("STATUS", "RD_OS_INFO|Cannot Read [/proc/meminfo], Reason [$!]");
        }
        printLOG("osBasic", "===========================================================", 'L');

        # Convert Memory and Swap Unit to MB
        if   ($memT =~ m/(\d+)\s+KB/i) {$memT = int($1/1024);    }
        elsif($memT =~ m/(\d+)\s+MB/i) {$memT = $1;              }
        elsif($memT =~ m/(\d+)\s+GB/i) {$memT = $1 * 1024;       }
        else                           {$memT = int($1/1048576); }
        if   ($swpT =~ m/(\d+)\s+KB/i) {$swpT = int($1/1024);    }
        elsif($swpT =~ m/(\d+)\s+MB/i) {$swpT = $1;              }
        elsif($swpT =~ m/(\d+)\s+GB/i) {$swpT = $1 * 1024;       }
        else                           {$swpT = int($1/1048576); }

        # Get System uptime
        # 11:33:44 up 19 days, 16:56,  2 users,  load average: 0.46, 0.31, 0.29
        # 15:18 已启动8 天21:55，4 个用户，平均负载：6.93 7.15 8.10
        $upT  = execOS('LANG=en_US; uptime');
        $upT  = execOS('uptime') if($upT =~ m/\A\s*\z/m);

        # Get OS Version
        foreach (execOS('lsb_release -a 2>/dev/null', 'ARRAY'))
        {
            if(m/Distributor\s+ID[:\s]+(\w+)/i)
            {
                $oVer = $1;
            }
            elsif(m/Release[:\s]+(.+)/)
            {
                $oVer = "$oVer $1";
            }
        }
        if ($oVer eq '')
        {
            $oVer = execOS('cat /etc/system-release');
        }
        if ($oVer eq '')
        {
            $oVer = execOS('cat /etc/redhat-release');
        }

        # Get Kernel Version
        $kVer = execOS('uname -r');

        # Get Clock Source
        $clockSrc = execOS('cat /sys/devices/system/clocksource/clocksource0/current_clocksource');
        if($clockSrc eq '')
        {
            $clockSrc = execOS('grep -i "Switching to clocksource" /var/log/dmesg /var/log/messages* 2>/dev/null | tail -1');
            $clockSrc =~ s/\A.*Switching\s+to\s+clocksource(.+)\z/$1/i;
        }
    }
    elsif($gENV{'OS_TYPE'} eq 'solaris')
    {
        # Get Information Data
        #netFH->print("$gENV{'HOSTNAME'}|LOG|Execute command [/usr/sbin/psrinfo | wc -l]\n");
        # Get CPU Count
        $cpuC = execOS('/usr/sbin/psrinfo | wc -l');

        # Get Memory Size
        foreach (execOS('prtconf', 'ARRAY'))
        {
            $_ = '' if (not defined $_);
            if (m/Memory\ssize[^\d]+(\d+)\s+G/i)
            {
                $memT = $1 * 1024;
            }
            elsif (m/Memory\ssize[^\d]+(\d+)/i)
            {
                $memT = $1;
            }
        }
        my %cpuModel;
        my $cHZ = '';
        # Get CPU Model
        foreach (execOS('/usr/sbin/psrinfo -vp', 'ARRAY'))
        {
            $_ = '' if (not defined $_);
            # The UltraSPARC-III+ physical processor has 1 virtual processor (16)
            # The physical processor has 16 cores and 128 virtual processors (256-383)
            if(m/\AThe\s+(.+)\s+physical\s+processor\s+has[\s\d]+virtual\s+processor/)
            {
                if(exists $cpuModel{"$1 $cHZ"})
                {
                    $cpuModel{"$1 $cHZ"} ++;
                }
                else{
                    $cpuModel{"$1 $cHZ"} = 1;
                }
            }
            #    SPARC-T5 (chipid 16, clock 3600 MHz)
            # SPARC64-VII+ (portid 1024 impl 0x7 ver 0xc1 clock 3000 MHz)
            elsif(m/\A\s*([^\s]+)\s+\(.*clock\s+([\.\d]+\s+[MG]Hz)/i)
            {
                if(exists $cpuModel{"$1 $2"})
                {
                    $cpuModel{"$1 $2"} ++;
                }
                else{
                    $cpuModel{"$1 $2"} = 1;
                }
            }
            elsif(m/([\.\d]+\s+[MG]HZ)/i)
            {
                $cHZ = $1;
            }
        }
        foreach my $cMod (keys %cpuModel)
        {
            $cpuM = "$cpuM/$cMod";
        }
        $cpuM =~ s#\A/+##g;
        foreach (execOS('/usr/sbin/swap -l', 'ARRAY'))
        {
            if (defined $_ and m/.+\s+.+\s+.+\s+(\d+)/)
            {
                printLOG("osBasic", "Get Swap Size [$1]", 'L');
                $swpT += $1;
            }
        }
        printLOG("osBasic", "Swap Size Total [$swpT]", 'L');
        $swpT = int($swpT/2048);      # $swpT = int($swpT*512/1048576);

        # Get System uptime
        $upT  = execOS('LANG=en_US; uptime');
        $upT  = execOS('uptime') if($upT =~ m/\A\s*\z/m);

        # Get OS Version
        foreach (execOS('showrev 2>/dev/null', 'ARRAY'))
        {
            $oVer = $1 if(m/Release[:\s]+(.+)/i);
        }
        if($oVer eq '')
        {
            # SunOS acctdb1 5.11 11.2 sun4v sparc sun4v
            $oVer = execOS('uname -a');
            $oVer =~ s/\A.+\s+.+\s+//;   # Remove [SunOS acctdb1 ]
            $oVer =~ s/\s+[a-z].+\z//i;  # Remove [ sun4v sparc sun4v]
        }
    }
    elsif($gENV{'OS_TYPE'} eq "aix")
    {
        # Get Information Data
        printLOG("osBasic", "Execute command [prtconf]", 'L');
        my $pTyp = '';
        my $cTyp = '';
        my $pClk = '';
        foreach (execOS('prtconf', 'ARRAY'))
        {
            $_ = '' if (not defined $_);
            if (m/Number\s+Of\s+Processors[^\d]+(\d+)/i)
            {      # Number Of Processors: 64
                $cpuC = $1;
            }
            elsif (m/Good\s+Memory\s+Size[^\d]+(\d+)/i)
            {       # Good Memory Size: 256512 MB
                $memT = $1;
            }
            elsif (m/Total\s+Paging\s+Space[^\d]+(\d+)/i)
            {     # Total Paging Space: 65536MB
                $swpT = $1;
            }
            elsif (m/Processor\s+Type[:\s]+(.+)/i)
            {            # Processor Type: PowerPC_POWER5
                $pTyp = $1;
            }
            elsif (m/CPU\s+Type[:\s]+(.+)/i)
            {                  # CPU Type: 64-bit
                $cTyp = $1;
            }
            elsif (m/Processor\s+Clock\s+Speed[:\s]+(.+)/i)
            {   # Processor Clock Speed: 2097 MHz
                $pClk = $1;
            }
        }
        $cpuM = "$pTyp $cTyp $pClk";

        # Get System uptime
        $upT  = execOS('LANG=en_US; uptime');
        $upT  = execOS('uptime') if($upT =~ m/\A\s*\z/m);

        # Get OS Version
        $oVer = execOS('oslevel -s');
        $oVer = $ENV{'AIX_VERSION'} if($oVer eq '');
        $oVer = execOS('oslevel')   if($oVer eq '');
        printLOG("osBasic", "Current AIX OS Version is [$oVer]", 'L');
    }
    elsif($gENV{'OS_TYPE'} eq "hpux")
    {
        # Get CPU Count, CPU Model and Memory Size
        my $cHZ = '';
        # Get CPU Count/CPU Model/Memory Size from [machinfo]
        # /usr/contrib/bin/machinfo
        my $CMD_MACHINFO = 'machinfo';
        if(-f '/usr/contrib/bin/machinfo')
        {
            $CMD_MACHINFO = '/usr/contrib/bin/machinfo';
        }

        foreach (execOS($CMD_MACHINFO, 'ARRAY'))
        {
            $_ = '' if (not defined $_);
            if (m/([\.\d]+\s+[MG]HZ)/i)
            {
                $cHZ = $1;
            }
            if (m/(\d+)\s+logical\s+processors/i)
            {
                $cpuC = $1;
            }
            elsif (m/Memory[^\d]+(\d+)/i)
            {
                $memT = $1;
            }
            elsif (m/Model[:=\s]+(.+)/i)
            {
                $cpuM = $1;
                $cpuM =~ s/\A[\s"]+|[\s"]+\z//g;
            }
        }
        if ($cpuM ne '')
        {
            $cpuM = "$cpuM $cHZ";
        }
        if($cpuC == 0 and $memT == 0)
        {
            foreach (execOS('top -d 1 -n 1', 'ARRAY'))
            {   # Get CPU Count/CPU Model/Memory Size from [top -d 1 -n 1]
                s/\A[^\w]*(B|2B)*//;
                if(m/\A\s+(\d+)\s+[\d\s\.%]+\z/)
                {
                    $cpuC ++;
                }
                elsif(m/Memory[:\s]+(\d+)K.+(\d+)K\s+free/i)
                {
                    $memT = $1 + $2;
                }
            }
            $memT = int($memT/1024);
        }

        # Get Swap Total
        foreach (execOS('swapinfo -atm', 'ARRAY'))
        {
            $_ = '' if (not defined $_);
            if(m/\Adev\s+(\d+)\s+/i)
            {
                $swpT += $1;
                printLOG("osBasic", "Get Swap Size [$swpT]", 'L');
            }
            if(m/\Amemory\s+(\d+)\s+/i and $memT == 0)
            {
                $memT  = $1;
                printLOG("osBasic", "Get Memory Size [$memT]", 'L');
            }
        }

        # Get System uptime
        $upT  = execOS('LANG=en_US; uptime');
        $upT  = execOS('uptime') if($upT =~ m/\A\s*\z/m);

        # Get OS Version
        $oVer = execOS('uname -r 2>/dev/null');
    }
    elsif($gENV{'OS_TYPE'} eq "MSWin32")
    {
        # Get Logical CPU
        # ----------------------------------------------------------------------
        $cpuC = 0;
        if(defined $ENV{'NUMBER_OF_PROCESSORS'})
        {
            $cpuC = $ENV{'NUMBER_OF_PROCESSORS'};
            printLOG("osBasic", "Get Logical CPU Count from ENV(NUMBER_OF_PROCESSORS) [$cpuC]", 'L');
        }
        else{
            foreach (execOS('WMIC CPU Get NumberOfLogicalProcessors /Format:List 2>nul', 'ARRAY'))
            {
                # NumberOfLogicalProcessors=4
                s/[^\d]+//g;
                if($_ ne '')
                {
                    $cpuC += $_;
                }
            }
        }


        # Get CPU Model
        # ----------------------------------------------------------------------
        my %modInfo;
        foreach (execOS('WMIC CPU Get Name /Format:List 2>nul', 'ARRAY'))
        {
            # Name=Quad-Core AMD Opteron(tm) Processor 8380
            if(m/\A\s*Name\s*=\s*(.+)\z/)
            {
                if(exists $modInfo{$1})
                {
                    $modInfo{$1} ++;
                }
                else{
                    $modInfo{$1} = 1;
                }
            }
        }
        foreach (keys %modInfo)
        {
            printLOG('osBasic', "Get CPU Info [$_], Count [$modInfo{$_}]", 'L');
            $cpuM = "/$_ ($modInfo{$_})";
        }
        $cpuM =~ s/\A\///;


        # Get Physical Memory Size
        # ----------------------------------------------------------------------
        $memT = execOS('WMIC OS GET TotalVisibleMemorySize /FORMAT:LIST 2>nul');
        if($memT eq '')
        {
            $memT = execOS('WMIC MEMLOGICAL GET TotalPhysicalMemory /Format:List 2>nul');
            # TotalPhysicalMemory=2096536
        }
        if($memT eq '')
        {
            $memT = execOS('WMIC COMPUTERSYSTEM GET TOTALPHYSICALMEMORY /FORMAT:LIST 2>nul');
        }
        if($memT eq '')
        {
            $memT = 0;
        }
        else
        {
            $memT =~ s/[^\d]+//g;
            $memT = $memT/1024;
            $memT = roundNum($memT, 2);
        }


        # Get Page File Size
        # ----------------------------------------------------------------------
        $swpT = execOS('WMIC PAGEFILE GET ALLOCATEDBASESIZE /FORMAT:LIST 2>nul');
        if($swpT eq '')
        {
            $swpT = execOS('WMIC MEMLOGICAL GET TotalPageFileSpace /Format:List 2>nul');
            # TotalPageFileSpace=1962908
            if($swpT eq '')
            {
                $swpT = execOS('WMIC OS GET TotalVirtualMemorySize /FORMAT:LIST 2>nul');
                if($swpT eq '')
                {
                    $swpT = 0;
                }
                else
                {
                    $swpT =~ s/[^\d]+//g;
                    $swpT = $swpT/1024 - $memT;
                }
            }
            else
            {
                $swpT =~ s/[^\d]+//g;
                $swpT = $swpT/1024;
                $swpT = roundNum($swpT, 2);
            }
        }
        else
        {
            $swpT =~ s/[^\d]+//g;
        }


        # Get OS Version
        # ----------------------------------------------------------------------
        $oVer = execOS('WMIC OS GET Caption /Format:List 2>nul');
        # Caption=Microsoft Windows 10 专业版
        # Caption=Microsoft(R) Windows(R) Server 2003 Enterprise x64 Edition
        $oVer =~ s/Caption=|Microsoft[^\s]*//gi;


        # Get OS Startup Time
        # ----------------------------------------------------------------------
        $upT = execOS('WMIC OS GET LastBootUpTime /Format:List 2>nul');
        # LastBootUpTime=20160307150542.375000+480
        $upT =~ s/LastBootUpTime=//gi;
        if($upT =~ m/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2}).*(\+\d+)/)
        {
            $upT ="$1-$2-$3 $4:$5:$6 ($7)";
        }
    }
    else{
        printLOG("Warn", "Unknown OS Type [$gENV{'OS_TYPE'}]");
    }

    # Convert UP time
    # -------------------------------------------------------------------------
    # 11:33:44 up 19 days, 16:56,  2 users,  load average: 0.46, 0.31, 0.29
    # 2:52pm  up 41 day(s),  5:48,  1 user,  load average: 4.29, 4.58, 4.96
    # 2:52pm  up 41 day(s),  5:48PM,  1 user,  load average: 4.29, 4.58, 4.96
    # 15:18 已启动8 天21:55上午，4 个用户，平均负载：6.93 7.15 8.10
    # 15:18 已启动8 天21:55，4 个用户，平均负载：6.93 7.15 8.10
    # 10:35:16 up 49 min,  5 users,  load average: 0.01, 0.11, 0.08
    # 2:32pm  up 131 days, 15 hrs,  2 users,  load average: 0.08, 0.06, 0.05
    # 16:12:43 up 67 days, 9 min,  4 users,  load average: 1.34, 1.26, 1.31
    # 10:51am  up 91 day(s), 6 min(s),  1 user,  load average: 1.77, 1.64, 2.16
    #
    # $upT =~ s/\A.*(up|已启动)|[\d\s]+(user|个用户).*\z//g;  # Remove Message before [up] and After [user]
    $upT =~ s/\A.*(up|已启动|运行)|\s*\d+\s*(user|个用户|用户).*\z//g;  # Remove Message before [up] and After [user]
    $upT =~ s/天/ days /g;                                 # Modify Chinese Word to days
    $upT =~ s/下午/ PM /g;                                 # Modify Chinese Word to PM
    $upT =~ s/(上午|AM)//g;                                # Modify Chinese Word to AM
    $upT =~ s/[,，]/ /g;                                   # Remove [,] and [，]
    $upT =~ s/\s{2,}/ /g;                                  # Keep only one space
    $upT =~ s/\A\s+|\s+\z//g;                              # Remove space at begining and ending
    if($upT =~ m/\A(.*)(\d+)[:：](\d+)\s*PM/i)             # Convert PM time
    {
        $upT = $1.($2 + 12).':'.$3;
    }

    $cpuM =~ s/'/''/g;
    $cpuC = 0 if ($cpuC eq '');
    $memT = 0 if ($memT eq '');
    $swpT = 0 if ($swpT eq '');
    printLOG("RD_OS_INFO", "'$gENV{'HOSTNAME'}','$gENV{'OS_TYPE'}',$cpuC,'$cpuM',$memT,$swpT,'$upT','$oVer','$kVer','$clockSrc'");

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_INFO|COMPLETED");
    printLOG("osBasic", "Complete OS Information Collection");
}

1;
