#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 15/03/17 | Continue collection when some server cannot login      ##
## 2.1.0   | 29/03/17 | Version [2.1.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use File::Copy;
use BTTools;
use BTConfig;
use Net::SSH::Expect;
use Net::SCP::Expect;

# Global Parameters
our %srvConfig;
our %clusterInfo;


# Sub : SCP Sending Files
# -----------------------------------------------------------------------------
sub scpFile($$;$)
{
    # Get Params
    my ($sourceFile, $targetFile, $remoteSCP)  = @_;

    # Sent by OS scp
    if($remoteSCP eq '')
    {
        printLOG('scpFile', 'Sending File ['.$sourceFile.'] to Remote ['.$targetFile.'] by [SCP]');
        system("scp $sourceFile $targetFile 1>/dev/null");
    }
    # Sent by Perl SCP Module
    else
    {
        printLOG('scpFile', 'Sending File ['.$sourceFile.'] to Remote ['.$targetFile.'] by [Module]');
        $remoteSCP->scp($sourceFile, $targetFile);
    }
}


# Sub : Show Servers in the Lists
# -----------------------------------------------------------------------------
sub showServers($)
{
    # Get Params
    my $srvList = $_[0];

    # Return if List is Empty
    if(not scalar %{$srvList})
    {
        return 0;
    }

    # Show Header
    printLOG('showServers', rPad('=', 33, '=').'[ Valid Servers ]'.rPad('=', 34, '='));
    printLOG('showServers', rPad('Cluster Name', 21).rPad('Node Type', 21).rPad('Server IP', 21).rPad('Login User', 11).rPad('Oracle SID', 10));
    printLOG('showServers', rPad('-', 20, '-').' '.rPad('-', 20, '-').' '.rPad('-', 20, '-').' '.rPad('-', 10, '-').' '.rPad('-', 10, '-'));

    # Show Server Info
    foreach my $sKey (keys %{$srvList})
    {
        my ($serverIP, $oracleSID)=split(/,/, $sKey);
        printLOG('showServers', rPad($srvList->{$sKey}->{'CLUSTER_NAME'}, 21).rPad($srvList->{$sKey}->{'NODE_TYPE'}, 21).rPad($serverIP, 21).rPad($srvList->{$sKey}->{'LOGIN_USER'}, 11).rPad($oracleSID, 10));
    }

    # Show End Line
    printLOG('showServers', rPad('=', 84, '='));
}


# Check Running Env.
# -----------------------------------------------------------------------------
sub checkENV
{
    # Get Config File
    $gFName{'SERVER_CONFIG'} = shift @ARGV;

    my ($sec, $min, $hour, $day, $mon, $year)=(localtime)[0..5];
    $year += 1900;
    $mon  += 1;
    my $logDate = sprintf("%04d%02d%02d%02d%02d%02d", $year, $mon, $day, $hour, $min, $sec);

    $gFName{'RESULT_DIR'} = $gFName{'DATA_DIR'}.'/Bundle_'.$logDate;
    mkdir $gFName{'RESULT_DIR'};

    logADM('MOVE', "$gFName{'RESULT_DIR'}/$gFName{'LOGFILE'}");
}


# Read Server Config File
# -----------------------------------------------------------------------------
sub readConfig
{
    printLOG('readConfig', "Begin Read Server Config File");

    # Check Config File
    die "Cannot Read Server Config File" if(not -r $gFName{'CONFIG_DIR'}.'/'.$gFName{'SERVER_CONFIG'});

    # Read and Parse Config File
    open SRVCFG, '<', $gFName{'CONFIG_DIR'}.'/'.$gFName{'SERVER_CONFIG'};
    while(<SRVCFG>)
    {
        chomp;                 # Remove Line Terminater
        s/\A\s+|#.*\z|\s+\z//; # Remove Comments
        next if(m/\A\s*\z/);   # Skip Empty Line
        $_ = $_.'|||||||||||';
        my($clusterName, $nodeType, $serverIP, $primaryIP, $sshPort, $loginUser, $loginPassword, $commandOptions, $configFile, $oracleSID, $oracleHome) = split(/\s*\|\s*/);
        if($nodeType   eq '')
        {
            $nodeType   = 'PRIMARY_MAIN';
        }
        else
        {
            $nodeType   = uc($nodeType);
        }
        $clusterName   = uc($clusterName);
        $loginUser  = 'oracle'              if($loginUser  eq '');
        $configFile = $gFName{'LIB_CONFIG'} if($configFile eq '');
        $sshPort    = 22                    if($sshPort    eq '');

        if($serverIP eq '')               # Check Servers without Connection IP or Name
        {
            printLOG('readConfig', "Server IP Field is needed in line [".SRVCFG->input_line_number."]");
            die "Server IP Field is needed in line [".SRVCFG->input_line_number."]";
        }
        elsif(exists $srvConfig{"$serverIP,$oracleSID"})  # Check Duplicated Servers
        {
            printLOG('readConfig', "[Previous] Line=".$srvConfig{"$serverIP,$oracleSID"}->{'LINE_NUMBER'}.", Cluster=".$srvConfig{"$serverIP,$oracleSID"}->{'CLUSTER_NAME'}.", Type=".$srvConfig{"$serverIP,$oracleSID"}->{'NODE_TYPE'}.", IP=$serverIP, User=".$srvConfig{"$serverIP,$oracleSID"}->{'LOGIN_USER'}.", SID=$oracleSID");
            printLOG('readConfig', "[Current ] Line=".SRVCFG->input_line_number.", Cluster=$clusterName, Type=$nodeType, IP=$serverIP, User=$loginUser, SID=$oracleSID");
            die "Duplicated Server/SID Found at Line [".$srvConfig{"$serverIP,$oracleSID"}->{'LINE_NUMBER'}."] and [".SRVCFG->input_line_number."]";
        }

        printLOG('readConfig', "Read Server Info:", 'L');
        printLOG('readConfig', "Line Number     : ".SRVCFG->input_line_number, 'L');
        printLOG('readConfig', "Cluster Name    : ".$clusterName             , 'L');
        printLOG('readConfig', "Node Type       : ".$nodeType                , 'L');
        printLOG('readConfig', "Server IP       : ".$serverIP                , 'L');
        printLOG('readConfig', "Primary IP      : ".$primaryIP               , 'L');
        printLOG('readConfig', "SSH Port        : ".$sshPort                 , 'L');
        printLOG('readConfig', "Login User      : ".$loginUser               , 'L');
        printLOG('readConfig', "Login Password  : ".$loginPassword           , 'L');
        printLOG('readConfig', "Command Options : ".$commandOptions          , 'L');
        printLOG('readConfig', "Config File     : ".$configFile              , 'L');
        printLOG('readConfig', "Oracle SID      : ".$oracleSID               , 'L');
        printLOG('readConfig', "Oracle Home     : ".$oracleHome              , 'L');

        # Add to Cluster Info
        if($clusterName ne '')
        {
            printLOG('readConfig', "Add Cluster [$clusterName] [$nodeType] [$serverIP] [$oracleSID]");
            if($nodeType eq 'PRIMARY_MAIN')
            {
                if(defined $clusterInfo{$clusterName}->{'MAIN_SERVER'})    # Check Duplicate Main Server in one Cluster
                {
                    die "Duplicated Main Server in One Cluster at Line [".$srvConfig{$clusterInfo{$clusterName}->{'MAIN_SERVER'}}->{'LINE_NUMBER'}."] and [".SRVCFG->input_line_number."]";
                }
                else
                {
                    $clusterInfo{$clusterName}->{'MAIN_SERVER'} = "$serverIP,$oracleSID";
                }
            }
            elsif($nodeType eq 'PRIMARY_SUB')
            {
                if(defined $clusterInfo{$clusterName}->{'SUB_LIST'})
                {
                    $clusterInfo{$clusterName}->{'SUB_LIST'} = $clusterInfo{$clusterName}->{'SUB_LIST'}."|$serverIP,$oracleSID";
                }
                else
                {
                    $clusterInfo{$clusterName}->{'SUB_LIST'} = "$serverIP,$oracleSID";
                }
            }
            elsif($nodeType eq 'PHYSICAL_STANDBY')
            {
                if(defined $clusterInfo{$clusterName}->{'STANDBY_LIST'})
                {
                    $clusterInfo{$clusterName}->{'STANDBY_LIST'} = $clusterInfo{$clusterName}->{'STANDBY_LIST'}."|$serverIP,$oracleSID";
                }
                else
                {
                    $clusterInfo{$clusterName}->{'STANDBY_LIST'} = "$serverIP,$oracleSID";
                }
            }
        }

        # Add to Server Config
        $srvConfig{"$serverIP,$oracleSID"}->{'LINE_NUMBER'}     = SRVCFG->input_line_number;
        $srvConfig{"$serverIP,$oracleSID"}->{'CLUSTER_NAME'}    = $clusterName;
        $srvConfig{"$serverIP,$oracleSID"}->{'NODE_TYPE'}       = $nodeType;
        $srvConfig{"$serverIP,$oracleSID"}->{'PRIMARY_IP'}      = $primaryIP;
        $srvConfig{"$serverIP,$oracleSID"}->{'SSH_PORT'}        = $sshPort;
        $srvConfig{"$serverIP,$oracleSID"}->{'LOGIN_USER'}      = $loginUser;
        $srvConfig{"$serverIP,$oracleSID"}->{'LOGIN_PASSWORD'}  = $loginPassword;
        $srvConfig{"$serverIP,$oracleSID"}->{'COMMAND_OPTIONS'} = $commandOptions;
        $srvConfig{"$serverIP,$oracleSID"}->{'CONFIG_FILE'}     = $configFile;
        $srvConfig{"$serverIP,$oracleSID"}->{'ORACLE_HOME'}     = $oracleHome;
    }
    close SRVCFG;

    # Check Cluster Without Main Server
    foreach my $clusterName (keys %clusterInfo)
    {
        die "No Main Server in Cluster [$clusterName]" if(not defined $clusterInfo{$clusterName}->{'MAIN_SERVER'});
    }

    # Check Cluster Without Main Server
    my $prevIP = '';
    foreach my $serverKey (keys %srvConfig)
    {
        my ($serverIP, $oracleSID) = split(/,/, $serverKey);
    }

    printLOG('readConfig', "Completed Read Server Config File");
}


# Open Connections
# -----------------------------------------------------------------------------
sub openConnect
{
    printLOG('openConnect', "Begin Open Remote Connections");
    foreach my $serverKey (keys %srvConfig)
    {
        my ($serverIP, $oracleSID)=split(/,/, $serverKey);
        my $remoteOutput = '';

        if($srvConfig{$serverKey}->{'LOGIN_PASSWORD'} eq '')
        {
            printLOG('openConnect', 'User Equivalence, use System SCP Command for ['.$serverIP.'/'.$oracleSID.']');
            $srvConfig{$serverKey}->{'REMOTE_SCP'} = '';
        }
        else
        {
            printLOG('openConnect', 'Open SCP Connection for ['.$serverIP.'/'.$oracleSID.']');
            $srvConfig{$serverKey}->{'REMOTE_SCP'} = Net::SCP::Expect->new( user     => $srvConfig{$serverKey}->{'LOGIN_USER'}
                                                                          , password => $srvConfig{$serverKey}->{'LOGIN_PASSWORD'}
                                                                          , port     => $srvConfig{$serverKey}->{'SSH_PORT'}
                                                                          , auto_yes => 1
                                                                          );
        }

        printLOG('openConnect', 'Open SSH Connection for ['.$serverIP.'/'.$oracleSID.']');
        if($srvConfig{$serverKey}->{'LOGIN_PASSWORD'} eq '')
        {
            $srvConfig{$serverKey}->{'REMOTE_SSH'} = Net::SSH::Expect->new( host    => $serverIP
                                                                          , port     => $srvConfig{$serverKey}->{'SSH_PORT'}
                                                                          , user    => $srvConfig{$serverKey}->{'LOGIN_USER'}
                                                                          , raw_pty => 1
                                                                          );
            eval {$srvConfig{$serverKey}->{'REMOTE_SSH'}->run_ssh()};

            # Check Login Result
            $srvConfig{$serverKey}->{'REMOTE_ERR'} = $@;
            chomp $srvConfig{$serverKey}->{'REMOTE_ERR'};
            if($srvConfig{$serverKey}->{'REMOTE_ERR'} eq '')
            {
                $remoteOutput = $srvConfig{$serverKey}->{'REMOTE_SSH'}->read_all(3);
            }
            else
            {
                printLOG('openConnect', 'Login Failed with ['.$srvConfig{$serverKey}->{'REMOTE_ERR'}.']');
                $srvConfig{$serverKey}->{'REMOTE_SSH'} = '';
                $srvConfig{$serverKey}->{'REMOTE_SCP'} = '';
                next;
            }
        }
        else
        {
            $srvConfig{$serverKey}->{'REMOTE_SSH'} = Net::SSH::Expect->new( host     => $serverIP
                                                                          , port     => $srvConfig{$serverKey}->{'SSH_PORT'}
                                                                          , password => $srvConfig{$serverKey}->{'LOGIN_PASSWORD'}
                                                                          , user     => $srvConfig{$serverKey}->{'LOGIN_USER'}
                                                                          , raw_pty  => 1
                                                                          );
            eval {$remoteOutput = $srvConfig{$serverKey}->{'REMOTE_SSH'}->login()};

            # Check Login Result
            $srvConfig{$serverKey}->{'REMOTE_ERR'} = $@;
            chomp $srvConfig{$serverKey}->{'REMOTE_ERR'};
            if($srvConfig{$serverKey}->{'REMOTE_ERR'} ne '')
            {
                printLOG('openConnect', 'Login Failed with ['.$srvConfig{$serverKey}->{'REMOTE_ERR'}.']');
                $srvConfig{$serverKey}->{'REMOTE_SSH'} = '';
                $srvConfig{$serverKey}->{'REMOTE_SCP'} = '';
                next;
            }
        }

        # Check Remote Retuning Messages
        if ($remoteOutput =~ m/(fail|error)/mi)
        {
            printLOG('openConnect', 'Login Remote Failed ['.$remoteOutput.']');
        }
        else
        {
            printLOG('openConnect', 'Login Remote Return ['.$remoteOutput.']', 'L');
        }

        # Getting Oracle SID
        if($oracleSID eq '')
        {
            $remoteOutput = $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('echo $ORACLE_SID');
            $remoteOutput =~ s/[\r\n]+.+\z//g;

            die "Cannot Get Oracle SID from Remote for Server [$serverIP] at Line [".$srvConfig{$serverKey}->{LINE_NUMBER}."]" if($remoteOutput eq '');

            printLOG('openConnect', 'Get Oracle SID from Remote ['.$remoteOutput.']');
            $srvConfig{"$serverIP,$remoteOutput"} = $srvConfig{"$serverIP,"};
            $oracleSID = $remoteOutput;
            $serverKey = "$serverIP,$oracleSID";
            delete $srvConfig{"$serverIP,"};
        }

        # Getting Oracle Home
        if($srvConfig{$serverKey}->{'ORACLE_HOME'} eq '')
        {
            $remoteOutput = $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('echo $ORACLE_HOME');
            $remoteOutput =~ s/[\r\n]+.+\z//g;

            die "Cannot Get Oracle Home from Remote for Server [$serverIP] at Line [".$srvConfig{$serverKey}->{LINE_NUMBER}."]" if($remoteOutput eq '');

            printLOG('openConnect', 'Get Oracle Home from Remote ['.$remoteOutput.']');
            $srvConfig{"$serverIP,$oracleSID"}->{'ORACLE_HOME'} = $remoteOutput;
        }

        # Setting Remote ENV. - export
        printLOG('openConnect', 'Setting RAW tty');
        $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("stty raw -echo");
        $remoteOutput = $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("export 2>/dev/null");
        $remoteOutput =~ s/[\s\r\n]+//g;
        if($remoteOutput eq '')
        {
            # Setting Remote ENV. - setenv
            printLOG('openConnect', 'Setting Remote Environments - [setenv]');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("setenv ORACLE_SID ".$oracleSID);
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("setenv ORACLE_HOME ".$srvConfig{$serverKey}->{'ORACLE_HOME'});
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('setenv PATH $ORACLE_HOME/bin:$PATH');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('setenv LIBPATH $ORACLE_HOME/lib32:$ORACLE_HOME/lib');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('setenv SHLIB_PATH $ORACLE_HOME/lib32:$ORACLE_HOME/lib');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('setenv LD_LIBRARY_PATH $ORACLE_HOME/lib32:$ORACLE_HOME/lib');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('setenv PERL5LIB $ORACLE_HOME/perl/lib:$ORACLE_HOME/perl/lib/site_perl');
        }
        else
        {
            printLOG('openConnect', 'Setting Remote Environments - [export]');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("ORACLE_SID=".$oracleSID);
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("ORACLE_HOME=".$srvConfig{$serverKey}->{'ORACLE_HOME'});
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('PATH=$ORACLE_HOME/bin:$PATH');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('LIBPATH=$ORACLE_HOME/lib32:$ORACLE_HOME/lib');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('SHLIB_PATH=$ORACLE_HOME/lib32:$ORACLE_HOME/lib');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('LD_LIBRARY_PATH=$ORACLE_HOME/lib32:$ORACLE_HOME/lib');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('PERL5LIB=$ORACLE_HOME/perl/lib:$ORACLE_HOME/perl/lib/site_perl');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec('export ORACLE_SID ORACLE_HOME PATH LIBPATH SHLIB_PATH LD_LIBRARY_PATH PERL5LIB');
        }


        # Make and Switch to Work Directory
        printLOG('openConnect', 'Make and Switch to Work Directory');
        $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("mkdir /tmp/BTRobot_v".$gENV{'SCRIPT_VERSION'});
        $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("cd /tmp/BTRobot_v".$gENV{'SCRIPT_VERSION'});
        $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("mkdir ".$gFName{'DATA_DIR'});
        $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("mkdir ".$gFName{'CONFIG_DIR'});
        $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("mkdir ".$gFName{'LIB_DIR'});
    }

    printLOG('openConnect', "Completed Open Remote Connections");
}


# Send Script Files
# -----------------------------------------------------------------------------
sub sendScripts
{
    printLOG('sendScripts', "Begin Sending Scripts to Remote");

    my %srvFILEOK;
    foreach my $serverKey (keys %srvConfig)
    {
        my ($serverIP, $oracleSID)=split(/,/, $serverKey);
        my $remoteOutput;

        # Sending File to Remote
        if(exists $srvFILEOK{$serverIP})
        {
            printLOG('sendScripts', 'Skip File Sending');
        }
        elsif($srvConfig{$serverKey}->{'REMOTE_SSH'} eq '')
        {
            printLOG('sendScripts', 'SSH not Connected, Skip File Sending');
        }
        else
        {
            scpFile('runMe.pl', $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}, $srvConfig{$serverKey}->{'REMOTE_SCP'});
            scpFile($gFName{'CONFIG_DIR'}.'/'.$srvConfig{$serverKey}->{'CONFIG_FILE'}, $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'CONFIG_DIR'}.'/'.$gFName{'LIB_CONFIG'} , $srvConfig{$serverKey}->{'REMOTE_SCP'});

            scpFile($gFName{'CONFIG_DIR'}.'/'.$gFName{'SERVER_CONFIG'}, $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'CONFIG_DIR'} , $srvConfig{$serverKey}->{'REMOTE_SCP'});

            scpFile($gFName{'LIB_DIR'}.'/'.$gFName{'LIB_TOOLS'}       , $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'LIB_DIR'}    , $srvConfig{$serverKey}->{'REMOTE_SCP'});
            scpFile($gFName{'LIB_DIR'}.'/'.$gFName{'LIB_DBTOOL'}      , $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'LIB_DIR'}    , $srvConfig{$serverKey}->{'REMOTE_SCP'});
            scpFile($gFName{'LIB_DIR'}.'/'.$gFName{'DG_SCRIPT'}       , $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'LIB_DIR'}    , $srvConfig{$serverKey}->{'REMOTE_SCP'});
            scpFile($gFName{'LIB_DIR'}.'/'.$gFName{'NODE_SCRIPT'}     , $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'LIB_DIR'}    , $srvConfig{$serverKey}->{'REMOTE_SCP'});
            scpFile($gFName{'LIB_DIR'}.'/'.$gFName{'MAIN_SCRIPT'}     , $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'LIB_DIR'}    , $srvConfig{$serverKey}->{'REMOTE_SCP'});

            foreach my $moduleName (keys %gOSCollect)
            {
                if(-f $gFName{'LIB_DIR'}.'/'.$moduleName.'.pm')
                {
                    scpFile($gFName{'LIB_DIR'}.'/'.$moduleName.'.pm', $serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'LIB_DIR'}, $srvConfig{$serverKey}->{'REMOTE_SCP'});
                }
                else
                {
                    printLOG('sendScripts', 'Module File not Exists ['.$gFName{'LIB_DIR'}.'/'.$moduleName.'.pm]');
                }
            }
            $srvFILEOK{$serverIP} = 1;
        }
    }

    printLOG('sendScripts', "Completed Sending Scripts to Remote");
}

# Batch Run Collection Command
# -----------------------------------------------------------------------------
sub runCommand
{
    printLOG('runCommand', "Begin Run Collection Command");

    foreach my $serverKey (keys %srvConfig)
    {
        my ($serverIP, $oracleSID)=split(/,/, $serverKey);

        # Call BTRobot
        if($srvConfig{$serverKey}->{'REMOTE_SSH'} ne '' and $srvConfig{$serverKey}->{'NODE_TYPE'} eq 'PRIMARY_MAIN')
        {
            printLOG('runCommand', 'Call Primary Main Collection Task ['.$serverIP.'/'.$oracleSID.']');
            printLOG('runCommand', 'perl runMe.pl -Q '.$srvConfig{$serverKey}->{'COMMAND_OPTIONS'}.'; echo MAIN_NODE_COMPLETED', 'L');
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->send ('perl runMe.pl -Q '.$srvConfig{$serverKey}->{'COMMAND_OPTIONS'}.'; echo MAIN_NODE_COMPLETED');
        }

        # Open Remote Output Logfile
        my ($sec, $min, $hour, $day, $mon, $year)=(localtime)[0..5];
        $year += 1900;
        $mon  += 1;
        my $logDate = sprintf("%04d%02d%02d%02d%02d%02d", $year, $mon, $day, $hour, $min, $sec);
        printLOG('runCommand', 'Open Logfile for ['.$serverIP.'/'.$oracleSID.']');
        $srvConfig{$serverKey}->{'LOGFILE'} = $gFName{'RESULT_DIR'}.'/'.$serverIP.'_'.$oracleSID.'_'.$logDate.'.log';
        open $srvConfig{$serverKey}->{'SCREEN_OUTPUT'}, '>', $srvConfig{$serverKey}->{'LOGFILE'};
    }

    printLOG('runCommand', "Completed Run Collection Command");
}


# Get Collection Outputs and Result File
# -----------------------------------------------------------------------------
sub waitComplete
{
    # Remove Servers without SSH Connected
    my %srvList = %srvConfig;
    foreach my $serverKey (keys %srvList)
    {
        delete $srvList{$serverKey} if($srvList{$serverKey}->{'REMOTE_SSH'} eq '');
    }

    printLOG('waitComplete', "Begin Remote Log Monitor");
    while(scalar %srvList)
    {
        foreach my $serverKey (keys %srvList)
        {
            my ($serverIP, $oracleSID)=split(/,/, $serverKey);
            while(defined $srvList{$serverKey} and defined (my $serverMesg = $srvList{$serverKey}->{'REMOTE_SSH'}->read_line(0)))
            {
                # Show Message
                my $LOGF = $srvList{$serverKey}->{'SCREEN_OUTPUT'};
                print $LOGF $serverMesg."\n";
                $serverMesg =~ s/\A[\d\:\s]+//;
                printLOG($serverIP, "[$oracleSID] ".$serverMesg);

                # Match Result Line
                if($serverMesg =~ m/\ABETHUNE_SERVER_RESULT\:.*\/(\w+\.zip)\z/)
                {
                    printLOG('waitComplete', 'Get Remote Result File ['.$1.']');
                    $srvConfig{$serverKey}->{'RESULT_FILE'} = $gFName{'RESULT_DIR'}.'/'.$serverIP.'_'.$1;
                    scpFile($serverIP.':/tmp/BTRobot_v'.$gENV{'SCRIPT_VERSION'}.'/'.$gFName{'DATA_DIR'}.'/'.$1, $gFName{'RESULT_DIR'}.'/'.$serverIP.'_'.$1, $srvList{$serverKey}->{'REMOTE_SCP'});
                }
                # Match Result Error
                if($serverMesg =~ m/\ABETHUNE_SERVER_ERROR\:(.+)\z/)
                {
                    printLOG('waitComplete', 'Get Remote Error ['.$1.']');
                    $srvConfig{$serverKey}->{'REMOTE_ERR'} = $1;
                }
                # Match Main Process Completed
                elsif($serverMesg eq "MAIN_NODE_COMPLETED")
                {
                    # Close Remote Logfile and Connections
                    close $srvList{$serverKey}->{'SCREEN_OUTPUT'};

                    # Delete Related Cluster
                    if($srvList{$serverKey}->{'NODE_TYPE'} eq 'PRIMARY_MAIN' and $srvList{$serverKey}->{'CLUSTER_NAME'} ne '')
                    {
                        foreach my $sKey (keys %srvList)
                        {
                            if($sKey ne $serverKey and $srvList{$sKey}->{'CLUSTER_NAME'} eq $srvList{$serverKey}->{'CLUSTER_NAME'})
                            {
                                delete $srvList{$sKey};
                            }
                        }
                    }

                    # Delete Remote Server Config
                    delete $srvList{$serverKey};

                    # Show Servers Remain
                    printLOG('waitComplete', 'Completed Server ['.$serverIP.'/'.$oracleSID.']');
                    showServers(\%srvList);
                }
                # Match DG Needed
                elsif($serverMesg eq 'REQUIRE_DG_DATA' and defined $clusterInfo{$srvList{$serverKey}->{'CLUSTER_NAME'}}->{'STANDBY_LIST'})
                {
                    # Collect PHYSICAL_STANDBY Node in Cluster
                    my @dgList = split(/\|/, $clusterInfo{$srvList{$serverKey}->{'CLUSTER_NAME'}}->{'STANDBY_LIST'});
                    foreach my $sKey (@dgList)
                    {
                        # Get Primary IP/Port
                        if($srvList{$sKey}->{'PRIMARY_IP'} eq '')
                        {
                            $srvList{$sKey}->{'PRIMARY_IP'} = $serverIP;
                        }
                        if($srvList{$serverKey}->{'COMMAND_OPTIONS'} =~ m/-p\s+(\d+)/)
                        {
                            $srvList{$sKey}->{'PRIMARY_PORT'} = $1;
                        }
                        else
                        {
                            $srvList{$sKey}->{'PRIMARY_PORT'} = $gENV{'LISTEN_PORT'};
                        }

                        # Call Collection Script
                        printLOG('waitComplete', 'Call Physical Standby Collection Task ['.$serverIP.']');
                        printLOG('waitComplete', '$ORACLE_HOME/perl/bin/perl '.$gFName{'LIB_DIR'}.'/'.$gFName{'DG_SCRIPT'}.' '.$srvList{$sKey}->{'PRIMARY_IP'}.' '.$srvList{$sKey}->{'PRIMARY_PORT'});
                        $srvList{$sKey}->{'REMOTE_SSH'}->send ('$ORACLE_HOME/perl/bin/perl '.$gFName{'LIB_DIR'}.'/'.$gFName{'DG_SCRIPT'}.' '.$srvList{$sKey}->{'PRIMARY_IP'}.' '.$srvList{$sKey}->{'PRIMARY_PORT'});
                    }
                }
                # Match Sub Needed
                elsif($serverMesg eq 'REQUIRE_SUB_NODE_DATA' and defined $clusterInfo{$srvList{$serverKey}->{'CLUSTER_NAME'}}->{'SUB_LIST'})
                {
                    # Collect PRIMARY_SUB Node in Cluster
                    my @subList = split(/\|/, $clusterInfo{$srvList{$serverKey}->{'CLUSTER_NAME'}}->{'SUB_LIST'});
                    foreach my $sKey (@subList)
                    {
                        # Get Primary IP/Port
                        if($srvList{$sKey}->{'PRIMARY_IP'} eq '')
                        {
                            $srvList{$sKey}->{'PRIMARY_IP'} = $serverIP;
                        }
                        if($srvList{$serverKey}->{'COMMAND_OPTIONS'} =~ m/-p\s+(\d+)/)
                        {
                            $srvList{$sKey}->{'PRIMARY_PORT'} = $1;
                        }
                        else
                        {
                            $srvList{$sKey}->{'PRIMARY_PORT'} = $gENV{'LISTEN_PORT'};
                        }

                        # Call Collection Script
                        printLOG('waitComplete', 'Call Primary Sub Collection Task ['.$serverIP.']');
                        printLOG('waitComplete', '$ORACLE_HOME/perl/bin/perl '.$gFName{'LIB_DIR'}.'/'.$gFName{'NODE_SCRIPT'}.' '.$srvList{$sKey}->{'PRIMARY_IP'}.' '.$srvList{$sKey}->{'PRIMARY_PORT'});
                        $srvList{$sKey}->{'REMOTE_SSH'}->send ('$ORACLE_HOME/perl/bin/perl '.$gFName{'LIB_DIR'}.'/'.$gFName{'NODE_SCRIPT'}.' '.$srvList{$sKey}->{'PRIMARY_IP'}.' '.$srvList{$sKey}->{'PRIMARY_PORT'});
                    }
                }
            }
        }
        sleep 1;
    }
    printLOG('waitComplete', "Compelete Remote Log Monitor");
}


# Show Result
# -----------------------------------------------------------------------------
sub postProcess
{
    printLOG('postProcess', "Begin Post Process");

    # Clean Remote Env.
    printLOG('postProcess', "Remove Remote Scripts File and Close Connections");
    foreach my $serverKey (keys %srvConfig)
    {
        if($srvConfig{$serverKey}->{'REMOTE_SSH'} ne '')
        {
            my $res = $srvConfig{$serverKey}->{'REMOTE_SSH'}->exec("cd /tmp; unalias rm; rm -rf /tmp/BTRobot_v$gENV{'SCRIPT_VERSION'}");
            $srvConfig{$serverKey}->{'REMOTE_SSH'}->close;
        }
    }


    # Make Batch Upload Config File
    # open UPLOADCONF, '>', $gFName{'RESULT_DIR'}.'/'.$gFName{'UPLOAD_CONFIG'};
    # print UPLOADCONF "# Result_ZIP | Result_LOG | System_Name | System_Desc\n";
    # foreach my $serverKey (keys %srvConfig)
    # {
    #     # Modify Result File, Keep only Name
    #     my $fName = $srvConfig{$serverKey}->{'RESULT_FILE'};
    #     if(defined $fName and -f $fName)
    #     {
    #         $fName =~ s@\A.+\/@@;
    #     }
    #     else
    #     {
    #         $srvConfig{$serverKey}->{'RESULT_FILE'} = '';
    #     }

    #     # Modify Logfile, Keep only Name
    #     my $fLog = $srvConfig{$serverKey}->{'LOGFILE'};
    #     if(defined $fLog)
    #     {
    #         $fLog =~ s@\A.+\/@@;
    #     }
    #     else
    #     {
    #         $fLog = '';
    #     }

    #     print UPLOADCONF "$fName | $fLog |  $srvConfig{$serverKey}->{'SYSTEM_NAME'} |  $srvConfig{$serverKey}->{'SYSTEM_DESC'}\n";
    # }
    # close UPLOADCONF;


    # Show Summary Info
    printLOG('postProcess', '');
    printLOG('postProcess', rPad('=', 51, '=').'[ Result Summary ]'.rPad('=', 52, '='));
    printLOG('postProcess', rPad('Bundle Directory: '.$gFName{'RESULT_DIR'}, 60).' '.lPad('Bundle Logfile: '.$gFName{'RESULT_DIR'}.'/'.$gFName{'LOGFILE'}, 60));
    # printLOG('postProcess', 'Upload Config: '.$gFName{'RESULT_DIR'}.'/'.$gFName{'UPLOAD_CONFIG'});
    printLOG('postProcess', '');
    printLOG('postProcess', rPad('Server IP/SID', 25).' '.rPad('Result File', 40).' '.lPad('Result Size', 13).' '.rPad('Detail Log', 40));
    printLOG('postProcess', rPad('-', 25, '-').' '.rPad('-', 40, '-').' '.lPad('-', 13, '-').' '.rPad('-', 40, '-'));
    my ($srvNum, $succNum, $failNum, $allSize) = (0, 0, 0, 0);
    foreach my $serverKey (keys %srvConfig)
    {
        my ($serverIP, $oracleSID)=split(/,/, $serverKey);
        $srvNum ++;

        # Skip Non-Main Server
        if($srvConfig{$serverKey}->{'NODE_TYPE'} ne 'PRIMARY_MAIN')
        {
            next;
        }
        elsif($srvConfig{$serverKey}->{'REMOTE_ERR'} ne '')
        {
            printLOG('postProcess', rPad($serverIP.'/'.$oracleSID, 25).' [Error] '.substr($srvConfig{$serverKey}->{'REMOTE_ERR'}, 0, 87));
            $failNum ++;
        }
        else
        {
            # Modify File Name, Get Size and Keep only Name
            my $fSize = 0;
            my $fName = $srvConfig{$serverKey}->{'RESULT_FILE'};
            my $fLog  = $srvConfig{$serverKey}->{'LOGFILE'};
            $fLog     =~ s@\A.+\/@@;
            if(defined $fName and -f $fName)
            {
                $fSize    = (stat $fName)[7];
                $fName   =~ s@\A.+\/@@;
                $succNum ++;
                $allSize += $fSize;
            }
            else
            {
                $fName    = '';
                $failNum ++;
            }

            # Modify Size Unit
            if($fSize < 1048576)
            {
                $fSize = roundNum($fSize/1024, 2).' KB';
            }
            else
            {
                $fSize = roundNum($fSize/1048576, 2).' MB';
            }

            # Show Result Info
            printLOG('postProcess', rPad($serverIP.'/'.$oracleSID, 25).' '.rPad($fName, 40).' '.lPad($fSize.' ', 13).' '.rPad($fLog, 40));
        }
    }
    # Modify Size Unit
    if($allSize < 1048576)
    {
        $allSize = roundNum($allSize/1024, 2).' KB';
    }
    elsif($allSize < 1073741824)
    {
        $allSize = roundNum($allSize/1048576, 2).' MB';
    }
    else
    {
        $allSize = roundNum($allSize/1073741824, 2).' GB';
    }
    printLOG('postProcess', rPad('-', 25, '-').' '.rPad('-', 40, '-').' '.lPad('-', 13, '-').' '.rPad('-', 40, '-'));
    printLOG('postProcess', '');
    printLOG('postProcess', rPad('Servers: '.$srvNum, 24).rPad('Systems: '.($succNum + $failNum), 24).rPad('Succeed: '.$succNum, 24).rPad('Failed: '.$failNum, 24).'All Size: '.$allSize);
    printLOG('postProcess', rPad('=', 121, '='));


    printLOG('postProcess', "End Post Process");
}



# =============================================================================
# Main Logical Code - Begin
# =============================================================================
logADM('OPEN', "$gFName{'LOGFILE'}");

checkENV;
readConfig;
showServers(\%srvConfig);

openConnect;
sendScripts;
runCommand;

waitComplete;
postProcess;

logADM('CLOSE');
# =============================================================================
# Main Logical Code - End
# =============================================================================
