#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 09/05/17 | Fix bug: ifconfig command not found                    ##
## 2.2.1   | 12/05/17 | Version [2.2.1] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osNIC;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osNIC", "Begin OS NIC Collection");
    my $fNam;


    # Collect NIC Running Informations
    # --------------------------------------------------------------------------
    if($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        # Ethernet adapter 本地连接:
        #
        #    Connection-specific DNS Suffix  . :
        #    Description . . . . . . . . . . . : Intel(R) PRO/1000 MT Desktop Adapter
        #    Physical Address. . . . . . . . . : 08-00-27-A8-F2-59
        #    DHCP Enabled. . . . . . . . . . . : Yes
        #    Autoconfiguration Enabled . . . . : Yes
        #    IP Address. . . . . . . . . . . . : 10.0.2.15
        #    Subnet Mask . . . . . . . . . . . : 255.255.255.0
        #    Default Gateway . . . . . . . . . : 10.0.2.2
        #    DHCP Server . . . . . . . . . . . : 10.0.2.2
        #    DNS Servers . . . . . . . . . . . : 223.5.5.5
        #                                        223.6.6.6
        #    Lease Obtained. . . . . . . . . . : 2016年5月17日 10:17:36
        #    Lease Expires . . . . . . . . . . : 2016年5月18日 10:17:36

        printLOG("osNIC", "Collect NIC Info by [ipconfig /all]");
        my $nName = '';
        my $nInfo = '';
        foreach my $netL (execOS('ipconfig /all', 'ARRAY'))
        {
            if((not defined $netL) or $netL =~ m/\A\s*\z/)
            {
                next;
            }
            elsif($netL =~ m/\A([^\s][^:]+)\:?\s*\z/)
            {
                # Ethernet adapter 本地连接:
                if($nName ne '')
                {
                    printLOG("RD_OS_NIC", "'$nName','$nInfo'");
                }
                $nName = $1;
                $nInfo = '';
                printLOG("osNIC", "Found Network Interface [$nName]");
            }
            elsif($nInfo eq '')
            {
                $nInfo = $netL;
            }
            else
            {
                $nInfo = $nInfo."'||CHR(10)||'".$netL;
            }
        }

        # Send Last NIC Item
        if($nName ne '')
        {
            printLOG("RD_OS_NIC", "'$nName','$nInfo'");
        }
    }
    else
    {
        # Linux:
        # eth1      Link encap:Ethernet  HWaddr 00:16:3E:00:05:0E
        #           inet addr:123.57.189.206  Bcast:123.57.191.255  Mask:255.255.252.0
        #           UP BROADCAST RUNNING MULTICAST  MTU:1500  Metric:1
        #           RX packets:2428412625 errors:0 dropped:0 overruns:0 frame:0
        #           TX packets:137796881 errors:0 dropped:0 overruns:0 carrier:0
        #           collisions:0 txqueuelen:1000
        #           RX bytes:122108135062 (113.7 GiB)  TX bytes:93600928252 (87.1 GiB)
        #           Interrupt:163
        # AIX:
        # en1: flags=7e080863,40<UP,BROADCAST,NOTRAILERS,RUNNING,SIMPLEX,MULTICAST,GROUPRT,64BIT,
        #     CHECKSUM_OFFLOAD,CHECKSUM_SUPPORT,PSEG>
        #         inet 10.216.163.37 netmask 0xffffff00 broadcast 10.216.163.255
        #          tcp_sendspace 131072 tcp_recvspace 65536

        printLOG("osNIC", "Collect NIC Info by [ifconfig -a]");
        my $nName   = '';
        my $nInfo   = '';
        my $cmdPATH = execOS('ls /sbin/ifconfig');
        if ($cmdPATH eq '')
        {
            $cmdPATH = 'ifconfig';
        }
        foreach my $netL (execOS("$cmdPATH -a", 'ARRAY'))
        {
            if((not defined $netL) or $netL =~ m/\A\s*\z/)
            {
                next;
            }
            elsif($netL =~ m/\A([^\s]+)\s+(.*)\z/)
            {
                # eth1      Link encap:Ethernet  HWaddr 00:16:3E:00:05:0E
                if($nName ne '')
                {
                    printLOG("RD_OS_NIC", "'$nName','$nInfo'");
                }
                $nName = $1;
                $nInfo = $2;
                $nName =~ s/:\z//;
            }
            else
            {
                $nInfo = $nInfo."'||CHR(10)||'".$netL;
            }
        }

        # Send Last NIC Item
        if($nName ne '')
        {
            printLOG("RD_OS_NIC", "'$nName','$nInfo'");
        }
    }


    # Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_NIC|COMPLETED");
    printLOG("osNIC", "Complete OS NIC Collection");
}

1;
