#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 19/09/16 | [collectDB] Remove Params of SQL in collectDB          ##
## 1.0.6   | 20/09/16 | Version [1.0.6] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 24/11/16 | [collectDB] Use Different SQL for Diff-Version         ##
## 1.1.2   | 01/12/16 | Version [1.1.2] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 20/12/16 | Add Timestamp with Time Zone Type                      ##
## 1.1.3   | 20/12/16 | Version [1.1.3] Released                               ##
##---------|----------|--------------------------------------------------------##
##         | 17/02/17 | Try Another time when SQL or PLSQL Prepare Failed      ##
## 2.0.0   | 02/03/17 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    # Check Oracle Env
    if(not defined $ENV{'ORACLE_HOME'})
    {
        die "Oracle Home not Set"
    }
    elsif(not defined $ENV{'ORACLE_SID'})
    {
        die "Oracle SID not Set"
    }

    # Set Library
    $ENV{"LD_LIBRARY_PATH"} = $ENV{"ORACLE_HOME"}."/lib32:".$ENV{"ORACLE_HOME"}."/lib";
    $ENV{"SHLIB_PATH"}      = $ENV{"ORACLE_HOME"}."/lib32:".$ENV{"ORACLE_HOME"}."/lib";
    $ENV{"LIBPATH"}         = $ENV{"ORACLE_HOME"}."/lib32:".$ENV{"ORACLE_HOME"}."/lib";

    # Set Perl Library
    foreach(`$ENV{'ORACLE_HOME'}/perl/bin/perl -e 'print join("\\n", \@INC)'`)
    {
        chomp;
        push(@INC, $_);
    }

    # Add Current Library
    unshift(@INC, "./lib") if (-d './lib');
    unshift(@INC, "./conf") if (-d './conf');
    unshift(@INC, "/tmp")  if (-d '/tmp');
}

package DBTools;
require Exporter;
use warnings;
use strict;
use DBI;
use DBI::DBD;
use DBD::Oracle qw(:ora_session_modes);
use PerlIO::encoding;
use Encode;
use utf8;
use BTTools;
use BTConfig;


our @ISA = qw(Exporter);

# Will Import Automaticly
our @EXPORT = qw(connDB queryDB decodeDB collectDB collectPLSQL);

# Cannot be Imported
# our @EXPORT_FAIL = qw(decodeDB);


# Package Variables
our $dbFH;
our $dbError = 'COMPLETED';
our $dbRows  = 0;
our %dbTypes;

our @colName;
our @colType;


################################################################################
##                                                                            ##
## 1. connDB : Login to a Running Instance                                    ##
## -------------------------------------------------------------------------- ##
## Input     -> 1. [String] Type with 'DB' or 'ASM'                           ##
##              2. [String] Connect Username                                  ##
##              3. [String] Connect Password                                  ##
##              4. [String] Connect Service                                   ##
##                                                                            ##
## Output    -> 1 = Success                                                   ##
##              0 = Fail                                                      ##
##                                                                            ##
## Function  -> Tools::printLOG                                               ##
##                                                                            ##
## Parameter -> 1. dbFH                                                       ##
##              2. dbError                                                    ##
##              3. dbTypes                                                    ##
##              4. GlobalVar::gFName                                          ##
################################################################################
sub connDB($$$$)
{
    # Get Arguments
    my ($type, $name, $pswd, $serv) = @_;

    # Open DBI Tracing
    DBI->trace(3, $gFName{'DBI_TRACE_FILE'});
    $dbError = 'COMPLETED';

    # do Disconnect if DB Connection Exists
    if(defined $dbFH)
    {
        printLOG('connDB', "Disconnect Pre-Connected Session", 'L');
        $dbFH->disconnect;
    }

    # ora_session_mode=>2 [SYSDBA], ora_session_mode=>4 [SYSOPER]
    if(uc($name) eq 'SYS')
    {
        $dbFH = DBI->connect( "dbi:Oracle:$serv"
                            , $name
                            , $pswd
                            , { ora_module_name  => 'BTRobot_by_HongyeDBA'
                              , ora_session_mode => ORA_SYSDBA
                              , PrintError       => 0
                              , PrintWarn        => 0});
    }
    else
    {
        $dbFH = DBI->connect( "dbi:Oracle:$serv"
                            , $name
                            , $pswd
                            , { ora_module_name  => 'BTRobot_by_HongyeDBA'
                              , PrintError       => 0
                              , PrintWarn        => 0});
    }

    # Check Connection Errors
    if(defined $DBI::errstr)
    {
        $dbError = "Connect Error :\n".$DBI::errstr;
        return 0;
    }
    elsif($type eq 'DB')   # Setting DB Connection Properties
    {
        printLOG('connDB', "Setting Connection Properties for DB", 'L');

        # Setting [Row Cache]
        $dbFH->{RowCacheSize} = 1000;

        # Setting [LONG]
        $dbFH->{LongReadLen} = 1048576;
        $dbFH->{LongTruncOk} = 1;

        # Setting Date/Timestamp Format
        $dbFH->do("ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD HH24:MI:SS'");
        $dbFH->do("ALTER SESSION SET NLS_TIMESTAMP_FORMAT='YYYY-MM-DD HH24:MI:SS.FF'");
        $dbFH->do("ALTER SESSION SET NLS_TIMESTAMP_TZ_FORMAT='YYYY-MM-DD HH24:MI:SS.FF TZR'");

        # Get Data Type Code
        my $stmtFH = $dbFH->prepare(q{SELECT DBID, NAME, CREATED, TO_TIMESTAMP_TZ('20161212','YYYYMMDD'), TO_TIMESTAMP('20161212','YYYYMMDD') FROM V$DATABASE});
        $stmtFH->execute;
        $dbTypes{'NUMBER'}       = $stmtFH->{'TYPE'}->[0];
        $dbTypes{'VARCHAR2'}     = $stmtFH->{'TYPE'}->[1];
        $dbTypes{'DATE'}         = $stmtFH->{'TYPE'}->[2];
        $dbTypes{'TIMESTAMP_TZ'} = $stmtFH->{'TYPE'}->[3];
        $dbTypes{'TIMESTAMP'} = $stmtFH->{'TYPE'}->[3];
        $stmtFH->finish;
        printLOG('connDB', "Data Type Code for [NUMBER/VARCHAR2/DATE/TIMESTAMP_TZ/TIMESTAMP] is [$dbTypes{'NUMBER'}/$dbTypes{'VARCHAR2'}/$dbTypes{'DATE'}/$dbTypes{'TIMESTAMP_TZ'}/$dbTypes{'TIMESTAMP'}]", 'L');

        # Get Character Set
        if($gENV{'DB_CHARSET'} eq 'NONE')
        {
            $stmtFH = queryDB("SELECT USERENV('LANGUAGE') FROM DUAL");
            $ENV{'NLS_LANG'} = $stmtFH->[0]->[0];
            if($ENV{'NLS_LANG'} =~ m/GB/i)
            {
                $gENV{'DB_CHARSET'} = 'GBK';
            }
            elsif($ENV{'NLS_LANG'} =~ m/ASCII/i)
            {
                $gENV{'DB_CHARSET'} = 'ISO-8859-1';
            }
            else
            {
                $gENV{'DB_CHARSET'} = 'UTF8';
            }
            &connDB('DB', $name, $pswd, $serv);
            printLOG('connDB', "Get DB Character Set [$gENV{'DB_CHARSET'}], Session Reconnected");
        }
    }

    # Connected
    DBI->trace(0);
    printLOG('connDB', "Connected Using [$name/$pswd] on [$serv]", 'L');
    return 1;
}


################################################################################
##                                                                            ##
## 2. queryDB : Query DB and Return Result Array                              ##
## -------------------------------------------------------------------------- ##
## Input     -> [String] SQL Statement to Executed by DB                      ##
##                                                                            ##
## Output    -> [Array Ref.] None when Error Occur                            ##
##                                                                            ##
## Function  -> Tools::printLOG                                               ##
##                                                                            ##
## Parameter -> 1. dbFH                                                       ##
##              2. dbError                                                    ##
##              3. dbRows                                                     ##
##              4. colName                                                    ##
##              5. colType                                                    ##
##              6. GlobalVar::gFName                                          ##
################################################################################
sub queryDB ($)
{
    # Record Begin Time
    my $bTime = time;

    # Initial Variables
    my $sqlResult;
    undef @colName;
    undef @colType;
    $dbError = 'COMPLETED';
    $dbRows  = 0;

    # Get Parameters
    my $sqlSTMT = $_[0];
    printLOG('queryDB', "Query SQL [$sqlSTMT]", 'L');

    # Open DBI Tracing
    DBI->trace(3, $gFName{'DBI_TRACE_FILE'});

    # Check DB Connections
    if(not defined $dbFH)
    {
        $dbError = 'Not Connected';
        return $sqlResult;
    }

    # Prepare for SQL Statement
    printLOG('queryDB', "Preparing ...", 'L');
    my $stmtFH = $dbFH->prepare($sqlSTMT);

    # Check Preparing Error
    if(defined $dbFH->errstr)
    {
        $dbError = "Preparation Error: ".$dbFH->errstr;
        printLOG('queryDB', 'SQL Statement Prepared Fail, do another try');
        &connDB('DB', $gENV{'DB_USER'}, $gENV{'DB_PSWD'}, $gENV{'DB_SERV'});

        # Prepare for SQL Statement
        printLOG('queryDB', "Second Preparing ...", 'L');
        $stmtFH = $dbFH->prepare($sqlSTMT);

        # Check Preparing Error
        if(defined $dbFH->errstr)
        {
            $dbError = "Preparation Error: ".$dbFH->errstr;
            return $sqlResult;
        }
    }

    # Execute for SQL Statement
    printLOG('queryDB', "Executing ...", 'L');
    $stmtFH->execute;

    # Check Execution Error
    if(defined $dbFH->errstr)
    {
        $dbError = "Execution Error: ".$dbFH->errstr;
        return $sqlResult;
    }

    # Write Trace Message, then Close DBI Tracing
    printLOG('queryDB', "Fetching ...", 'L');
    $dbFH->trace_msg('Fetch all data and return (Array Ref)');
    DBI->trace(0);

    # Fetch All for SQL Statement
    $sqlResult = $stmtFH->fetchall_arrayref;
    @colName   = @{$stmtFH->{'NAME'}};
    @colType   = @{$stmtFH->{'TYPE'}};
    $dbRows    = $stmtFH->rows;

    # Check Fetch Error
    if(defined $dbFH->errstr)
    {
        $dbError = "Fetch Error: ".$dbFH->errstr;
        return $sqlResult;
    }

    # Close Statement Handler
    $stmtFH->finish;

    # Show Elapsed Time of Current Collection
    printLOG('queryDB', "Elapsed Time [".(time - $bTime)." seconds]", 'L');

    # Return Result
    return $sqlResult;
}


################################################################################
##                                                                            ##
## 3. decodeDB : Decode DB Data                                               ##
## -------------------------------------------------------------------        ##
## Input     -> [String] Original String to be Decoded                        ##
##                                                                            ##
## Output    -> [String] Decoded String                                       ##
##                                                                            ##
## Function  -> Tools::printLOG                                               ##
##                                                                            ##
## Parameter -> GlobalVar::gENV                                               ##
################################################################################
sub decodeDB ($)
{
    my $origStr = shift;

    if(not defined $origStr or $origStr eq '')
    {
        printLOG('decodeDB', "Empty String in Decoding", 'L');
    }
    elsif($gENV{'DB_CHARSET'} ne 'UTF8')
    {
        # 1. Backup and Re-Set DIE Signal
        my $backupSIG = $SIG{__DIE__};
        $SIG{__DIE__} = sub
        {
            printLOG('decodeDB', 'Prevent Program Die :'.join("\n", @_), 'L');
        };

        # 2. Decode String to Perl Internal Format
        eval
        {
            $origStr = decode($gENV{'DB_CHARSET'}, $origStr);
        }
        or do
        {
            printLOG('decodeDB', "Error in Decode [$origStr], Reason [$@]", 'L');
        };

        # 3. Re-Set DIE Signal
        $SIG{__DIE__} = $backupSIG;
    }

    return $origStr;
}


################################################################################
##                                                                            ##
## 4. collectDB : Collect DB Releated Data                                    ##
## -------------------------------------------------------------------------- ##
## Input     -> [String] Result Name (Used to Loockup SQL Info)               ##
##                                                                            ##
## Output    -> <NONE>                                                        ##
##                                                                            ##
## Function  -> 1. Tools::printLOG                                            ##
##              2. decodeDB                                                   ##
##              3. Tools::addStatus                                           ##
##                                                                            ##
## Parameter -> 1. dbError                                                    ##
##              2. dbRows                                                     ##
##              3. colName                                                    ##
##              4. colType                                                    ##
##              5. GlobalVar::gFName                                          ##
##              6. GlobalVar::gResult                                         ##
################################################################################
sub collectDB ($)
{
    # 1. Get Parameters
    my $resName = shift;

    # 2. Check Status
    if(defined $gResult{$resName}->{'STATUS'} and $gResult{$resName}->{'STATUS'} ne 'ENABLE')
    {
        printLOG('collectDB', "Ignore Collection for [$resName], due to status [$gResult{$resName}->{'STATUS'}]");
        addStatus($resName, 0, "Ignore by Status [$gResult{$resName}->{'STATUS'}]");
        return 1;
    }

    # 3. Get SQL Statement
    my $sqlSTMT;
    if(uc($gENV{'DB_USER'}) eq 'SYS' and defined $gResult{$resName}->{'SQL_SYS'})
    {
        printLOG('collectDB', "Use SYS SQL Statement");
        $sqlSTMT = $gResult{$resName}->{'SQL_SYS'};
    }
    elsif(defined $gResult{$resName}->{'SQL_12.1'} and $gENV{'DB_VERSION'} =~ m/12.1/)
    {
        printLOG('collectDB', "Use SQL Statement for DB Version [12.1]");
        $sqlSTMT = $gResult{$resName}->{'SQL_12.1'};
    }
    elsif(defined $gResult{$resName}->{'SQL_12'} and $gENV{'DB_VERSION'} =~ m/12/)
    {
        printLOG('collectDB', "Use SQL Statement for DB Version [12]");
        $sqlSTMT = $gResult{$resName}->{'SQL_12'};
    }
    elsif(defined $gResult{$resName}->{'SQL_11'} and $gENV{'DB_VERSION'} =~ m/11/)
    {
        printLOG('collectDB', "Use SQL Statement for DB Version [11]");
        $sqlSTMT = $gResult{$resName}->{'SQL_11'};
    }
    elsif(defined $gResult{$resName}->{'SQL_10'} and $gENV{'DB_VERSION'} =~ m/10/)
    {
        printLOG('collectDB', "Use SQL Statement for DB Version [10]");
        $sqlSTMT = $gResult{$resName}->{'SQL_10'};
    }
    elsif(defined $gResult{$resName}->{'SQL'})
    {
        $sqlSTMT = $gResult{$resName}->{'SQL'};
    }
    else
    {
        printLOG('collectDB', "Not a DB Collection Item [$resName]");
        return 1;
    }

    # 4. Replace Variables
    if($gResult{$resName}->{'VALUE'})
    {
        foreach(split(/,/, $gResult{$resName}->{'VALUE'}))
        {
            $sqlSTMT =~ s/\?/$gENV{$_}/;
        }
    }

    # 5. Query DB Data
    printLOG('collectDB', "Collect Data for [$resName]");
    my $sqlResult = queryDB($sqlSTMT);

    # 6. Get Definition for Table Column
    $gResult{$resName}->{'DEFINE'} = '';
    for(my $x = 0; $x <= $#colName; $x ++)
    {
        printLOG('collectDB', "Column [".rPad($colName[$x], 22)."], Type [".rPad($colType[$x], 5)."]", 'L');
        $gResult{$resName}->{'DEFINE'} = "$gResult{$resName}->{'DEFINE'},$colName[$x]";
    }
    if($gResult{$resName}->{'DEFINE'} ne '')
    {
        $gResult{$resName}->{'DEFINE'} = substr($gResult{$resName}->{'DEFINE'}, 1);
    }

    # 7. Write SQL Result to File
    printLOG('collectDB', "Write SQL Result to [$resName]", 'L');
    my $RESF = openResult($resName);
    for(my $x = 0; $x <= $#{$sqlResult}; $x ++)
    {
        my $rowRef = $sqlResult->[$x];

        # Make Row Data
        my $rowLine = '';
        for(my $y = 0; $y <= $#{$rowRef}; $y ++)
        {
            # Append Null
            if((not defined $rowRef->[$y]) or $rowRef->[$y] eq '')
            {
                $rowLine = "$rowLine,NULL";
            }
            # Append Number
            elsif($colType[$y] == $dbTypes{'NUMBER'})
            {
                $rowLine = "$rowLine,$rowRef->[$y]";
            }
            # Append Date/Timestamp
            elsif($colType[$y] == $dbTypes{'DATE'})
            {
                if($rowRef->[$y] =~ m/\A\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\z/)
                {
                    $rowLine = "$rowLine,TO_DATE('$rowRef->[$y]','YYYY-MM-DD HH24:MI:SS')";
                }
                else
                {
                    $rowLine = "$rowLine,TO_TIMESTAMP('$rowRef->[$y]','YYYY-MM-DD HH24:MI:SS.FF')";
                }
            }
            # Append Timestamp With Time Zone
            elsif($colType[$y] == $dbTypes{'TIMESTAMP_TZ'})
            {
                $rowLine = "$rowLine,TO_TIMESTAMP_TZ('$rowRef->[$y]','YYYY-MM-DD HH24:MI:SS.FF TZR')";
            }
            # Append String
            else
            {
                $rowRef->[$y] =~ s/'/''/g;                      # 1. Convert Single Quota, use ['']
                $rowRef->[$y] =~ s/[\r\n]+/'\|\|CHR(10)\|\|'/g; # 2. Convert New Lines, use [||CHR(10)||]
                $rowLine = "$rowLine,'$rowRef->[$y]'";
            }
        }

        # Write Row Data to File
        print $RESF decodeDB(substr($rowLine, 1))."\n";
    }
    close $RESF;

    # 8. Save DB Collection Status
    addStatus($resName, $dbRows, $dbError);
}


################################################################################
##                                                                            ##
## 5. collectPLSQL : Collect AWR SQL Stats                                    ##
## -------------------------------------------------------------------------- ##
## Input     -> [String] PL/SQL Statement                                     ##
##                                                                            ##
## Output    -> [Array] Result Array, None when Error Occur                   ##
##                                                                            ##
## Function  -> 1. Tools::printLOG                                            ##
##              2. decodeDB                                                   ##
##                                                                            ##
## Parameter -> 1. dbFH                                                       ##
##              2. dbError                                                    ##
##              3. dbRows                                                     ##
##              4. GlobalVar::gFName                                          ##
################################################################################
sub collectPLSQL ($)
{

    my $sqlSTMT = $_[0];

    # Initial Variables
    my @sqlResult;
    $dbError = 'COMPLETED';
    $dbRows  = 0;

    # Open DBI Tracing
    DBI->trace(3, $gFName{'DBI_TRACE_FILE'});

    # Set PL/SQL Output Size to Unlimited
    $dbFH->do('CALL DBMS_OUTPUT.ENABLE(NULL)');

    # Prepare for SQL Statement
    my $stmtFH = $dbFH->prepare($sqlSTMT);

    # Check Preparation Error
    if(defined $dbFH->errstr)
    {
        $dbError = "Preparation Error: ".$dbFH->errstr;
        printLOG('collectPLSQL', 'PLSQL Statement Prepared Fail, do another try');
        &connDB('DB', $gENV{'DB_USER'}, $gENV{'DB_PSWD'}, $gENV{'DB_SERV'});

        # Prepare for SQL Statement
        printLOG('collectPLSQL', "Second Preparing ...", 'L');
        $stmtFH = $dbFH->prepare($sqlSTMT);

        # Check Preparing Error
        if(defined $dbFH->errstr)
        {
            $dbError = "Preparation Error: ".$dbFH->errstr;
            return @sqlResult;
        }
    }

    # Execute for SQL Statement
    $stmtFH->execute;

    # Check Execution Error
    if(defined $dbFH->errstr)
    {
        $dbError = "Execution Error: ".$dbFH->errstr;
        return @sqlResult;
    }

    # Close DBI Tracing
    DBI->trace(0);

    # Get Server Output Message
    while (defined(my $resStr = $dbFH->func('dbms_output_get')))
    {
        # '6xvp6nxs4a9n4'
        push(@sqlResult, decodeDB($resStr));

        # 1. Increment Result Count
        $dbRows ++;
    }

    # Return Result
    return @sqlResult;
}

1;
