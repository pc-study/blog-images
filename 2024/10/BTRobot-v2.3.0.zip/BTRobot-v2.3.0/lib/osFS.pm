#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 1.0.1   | 02/06/16 | Version [1.0.1] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
package osFS;
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use utf8;
use BTTools;
use BTConfig;


################################################################################
##                                                                            ##
## Main Function                                                              ##
##                                                                            ##
################################################################################
sub main ()
{
    # Send Begin Message
    # --------------------------------------------------------------------------
    printLOG("osFS", "Begin Disk Collection");

    # Define Variable
    my @dU;
    my @bL;

    # Get Disk Usage Data
    if   ($gENV{'OS_TYPE'} eq "linux"  ) {@dU = execOS('df -m 2>/dev/null', 'ARRAY')}
    elsif($gENV{'OS_TYPE'} eq "solaris") {@dU = execOS('df -k 2>/dev/null', 'ARRAY')}
    elsif($gENV{'OS_TYPE'} eq "aix"    ) {@dU = execOS('df -m 2>/dev/null', 'ARRAY')}
    elsif($gENV{'OS_TYPE'} eq "hpux"   ) {@dU = execOS('bdf   2>/dev/null', 'ARRAY')}

    # Remove Header Information
    shift @dU;

    # Format Body Information (Combine Multi-Line)
    for(my $x = 0; $x <= $#dU; $x ++)
    {
        $dU[$x] =~ s/\r|\n//g;
        if($dU[$x] =~ m/\A([\w\/\-\_]+\s+\d)/)
        {
            push(@bL, $dU[$x]);
        }
        elsif($dU[$x] =~ m/\A([\w\/\-\_]+\z)/)
        {
            push(@bL, $dU[$x].' '.$dU[$x+1]);
            $x ++;
        }
    }

    #print DISKF "FILESYSTEM|TOTALMB|USEDMB|FREEMB|USEDPCT|IUSEDPCT|MOUNT\n";
    if($gENV{'OS_TYPE'} eq 'linux')
    {
        # df -m
        # Filesystem           1M-blocks      Used Available Use% Mounted on

        for(my $x = 0; $x <= $#bL; $x ++)
        {
            my @dL = split(/\s+/, $bL[$x]);

            # Modify Data
            $dL[1] = 0 if ($dL[1] eq '-');
            $dL[2] = 0 if ($dL[2] eq '-');
            $dL[3] = 0 if ($dL[3] eq '-');
            $dL[4] = 0 if ($dL[4] eq '-');
            my $fs = shift @dL;
            my $totMB   = shift @dL;
            my $usedMB  = shift @dL;
            my $freeMB  = shift @dL;
            my $usedPct = shift @dL;
            my $mount   = join(' ', @dL);

            $fs        =~ s/'/''/g;
            $usedPct   =~ s/\%//g;
            $mount     =~ s/'/''/g;
            $totMB     =  roundNum($totMB, 2);
            $usedMB    =  roundNum($usedMB, 2);
            $freeMB    =  roundNum($freeMB, 2);

            printLOG("RD_OS_FS", "'$fs',$totMB,$usedMB,$freeMB,$usedPct,NULL,'$mount'");
        }
    }
    elsif($gENV{'OS_TYPE'} eq 'solaris')
    {
        # df -k
        # Filesystem             size   used  avail capacity  Mounted on
        # /dev/md/dsk/d0    20657289 6846120 13604597    34%    /


        for(my $x = 0; $x <= $#bL; $x ++)
        {
            my @dL = split(/\s+/, $bL[$x]);

            # Modify Data
            $dL[1] = 0 if ($dL[1] eq '-');
            $dL[2] = 0 if ($dL[2] eq '-');
            $dL[3] = 0 if ($dL[3] eq '-');
            $dL[4] = 0 if ($dL[4] eq '-');
            my $fs = shift @dL;
            my $totMB   = shift @dL;
            my $usedMB  = shift @dL;
            my $freeMB  = shift @dL;
            my $usedPct = shift @dL;
            my $mount   = join(' ', @dL);

            $fs        =~ s/'/''/g;
            $usedPct   =~ s/\%//g;
            $mount     =~ s/'/''/g;
            $totMB      = $totMB / 1024;
            $usedMB     = $usedMB / 1024;
            $freeMB     = $freeMB / 1024;
            $totMB      = roundNum($totMB, 2);
            $usedMB     = roundNum($usedMB, 2);
            $freeMB     = roundNum($freeMB, 2);

            printLOG("RD_OS_FS", "'$fs',$totMB,$usedMB,$freeMB,$usedPct,NULL,'$mount'");
        }
    }
    elsif($gENV{'OS_TYPE'} eq 'aix')
    {
        # df -m
        # Filesystem    MB blocks      Free %Used    Iused %Iused Mounted on

        for(my $x = 0; $x <= $#bL; $x ++)
        {
            my @dL = split(/\s+/, $bL[$x]);

            # Modify Data
            $dL[1] = 0 if ($dL[1] eq '-');
            $dL[2] = 0 if ($dL[2] eq '-');
            $dL[3] = 0 if ($dL[3] eq '-');
            $dL[5] = 0 if ($dL[4] eq '-');

            my $fs       = shift @dL;
            my $totMB    = shift @dL;
            my $freeMB   = shift @dL;
            my $usedPct  = shift @dL;
            shift @dL;   # Remove [Iused] Field
            my $iUsedPct = shift @dL;
            my $mount    = join(' ', @dL);

            $fs         =~ s/'/''/g;
            $usedPct    =~ s/\%//g;
            $iUsedPct   =~ s/\%//g;
            $mount      =~ s/'/''/g;
            $totMB      =  roundNum($totMB, 2);
            $freeMB     =  roundNum($freeMB, 2);
            my $usedMB  =  $totMB - $freeMB;

            printLOG("RD_OS_FS", "'$fs',$totMB,$usedMB,$freeMB,$usedPct,$iUsedPct,'$mount'");
        }
    }
    elsif($gENV{'OS_TYPE'} eq 'hpux')
    {
        # bdf
        # Filesystem          kbytes    used   avail %used Mounted on

        for(my $x = 0; $x <= $#bL; $x ++)
        {
            my @dL = split(/\s+/, $bL[$x]);

            my $fs      = shift @dL;
            my $totMB   = shift @dL;
            my $usedMB  = shift @dL;
            my $freeMB  = shift @dL;
            my $usedPct = shift @dL;
            my $mount   = join(' ', @dL);

            $usedPct   =~ s/\%//g;
            $fs        =~ s/'/''/g;
            $mount     =~ s/'/''/g;
            $totMB      = $totMB / 1024;
            $usedMB     = $usedMB / 1024;
            $freeMB     = $freeMB / 1024;
            $totMB      = roundNum($totMB, 2);
            $usedMB     = roundNum($usedMB, 2);
            $freeMB     = roundNum($freeMB, 2);

            printLOG("RD_OS_FS", "'$fs',$totMB,$usedMB,$freeMB,$usedPct,NULL,'$mount'");
        }
    }
    elsif($gENV{'OS_TYPE'} eq 'MSWin32')
    {
        # WMIC LOGICALDISK GET NAME,FREESPACE,SIZE,VOLUMENAME,DESCRIPTION
        # Description   FreeSpace    Name  Size          VolumeName
        # 本地固定磁盘    27003887616  C:    34348736512
        # CD-ROM 磁盘   0            D:    58793984      VBOXADDITIONS_5.
        # 网络连接       54275256320  E:    250140319744  VBOX_windwos
        my $dosCP = execOS('chcp');
        $dosCP =~ s/[^\d]//g;
        printLOG("osFS", "Current Dos Code Page is [$dosCP]");

        foreach (execOS('WMIC LOGICALDISK GET NAME,FREESPACE,SIZE,VOLUMENAME,DESCRIPTION', 'ARRAY'))
        {
            if(m/\A([^\d]+)\s+(\d+)\s+([^\d]+)\s+(\d+)\s+(.*)\z/)
            {
                my $mount  = $3;
                my $fs     = $1;
                if(defined $5 and $5 ne '')
                {
                    $fs    = "$1($5)";
                }
                my $totMB  = $4;
                my $freeMB = $2;

                $fs       =~ s/\s+/ /g;
                $fs       =~ s/\A\s+|\s+\z//g;
                $mount    =~ s/\A\s+|\s+\z//g;
                $totMB     = $totMB  / 1048576;
                $freeMB    = $freeMB / 1048576;
                $totMB     = roundNum($totMB, 2);
                $freeMB    = roundNum($freeMB, 2);

                my $usedMB  = $totMB - $freeMB;
                my $usedPct = 100 * $usedMB / $totMB;
                $usedPct    = roundNum($usedPct, 2);

                printLOG("RD_OS_FS", "'$fs',$totMB,$usedMB,$freeMB,$usedPct,NULL,'$mount'");
            }
            else{
                printLOG("Warn", "Unmatched Logical Disk Line [$_]");
            }
        }
    }

    # 11. Send Completed Tips
    # ------------------------------------------------------------------------------
    printLOG("STATUS", "RD_OS_FS|COMPLETED");
    printLOG("osFS", "Complete Disk Collection");
}

1;
