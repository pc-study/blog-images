#################################################################################
##                                                                             ##
## Yunhe Enmo (Beijing) Information Technology Co., Ltd                        ##
## CopyRight © 2009-2016 enmotech.com, All rights reserved.                    ##
##                                                                             ##
## Contact us:                                                                 ##
## Telephone : 010-59003186                                                    ##
## Email     : bethune@enmotech.com                                            ##
##                                                                             ##
#################################################################################
##         |          |                                                        ##
## Version | Date     | Description                                            ##
##---------|----------|--------------------------------------------------------##
## 2.0.0   | 02/06/16 | Version [2.0.0] Released                               ##
##---------|----------|--------------------------------------------------------##
#################################################################################
BEGIN
{
    unshift(@INC, '.');
    unshift(@INC, './lib') if(-d './lib');
    unshift(@INC, './conf') if(-d './conf');
    unshift(@INC, '/tmp')  if(-d '/tmp');
}
use warnings;
use strict;
use File::Copy;
use BTTools;
use BTConfig;
use IO::Socket;
use IO::Select;


our $bethuneServer = '111.111.111.111';
our $bethunePort   = '8192';
our $bethuneSocket;
our $bethuneSelect;
our $bethuneHandler;


# Get Result Directory
# -----------------------------------------------------------------------------
$gFName{'RESULT_DIR'} = shift @ARGV;
if(not -r $gFName{'RESULT_DIR'}.'/'.$gFName{'UPLOAD_CONFIG'})
{
    die "Cannot Read Upload Config File [$gFName{'RESULT_DIR'}.'/'.$gFName{'UPLOAD_CONFIG'}]";
}
logADM('OPEN', "$gFName{'RESULT_DIR'}/$gFName{'LOGFILE'}");


# Open TCP Connections
# -----------------------------------------------------------------------------
printLOG('autoUpload', "Connect to [$bethuneServer] on Port [$bethunePort]");
$bethuneSocket = IO::Socket::INET->new( PeerAddr => $bethuneServer
                                      , PeerPort => $bethunePort
                                      , Type     => SOCK_STREAM
                                      , Timeout  => 60
                                      , Proto    => 'tcp')
or die "Failed to Connect to Remote Lieten Node [$bethuneServer], Reason: [$@]";

# Set Properties
binmode($bethuneSocket);
$bethuneSocket->autoflush(1);
$bethuneSocket->blocking(1);
$bethuneSelect  = IO::Select->new($bethuneSocket);
$bethuneHandler = ($bethuneSelect->handles)[0];


# Send Login User Mobile and Check
# -----------------------------------------------------------------------------
$bethuneHandler->send('RESULT_INFO:'.$gENV{'UPLOAD_USER'});
$userChecker = $netFH->getline;
if($userChecker eq 'OK')
{
    printLOG('autoUpload', 'User Check Passed')
}
else
{
    printLOG('autoUpload', 'User Check Failed for ['.$gENV{'UPLOAD_USER'}.']')
}


# Read Upload Config File
# -----------------------------------------------------------------------------
printLOG('autoUpload', "Begin Read Upload Config File");
open UPLOADCONF, '<', $gFName{'CONFIG_DIR'}.'/'.$gFName{'SERVER_CONFIG'};
while(<UPLOADCONF>)
{
    chomp;                # Remove Line Terminater
    s/#.*\z//;            # Remove Comments
    next if(m/\A\s*\z/);  # Skip Empty Line
    $_ = $_.'||||';
    my($resultZIP, $resultLOG, $systemName, $systemDesc) = split(/\s*\|\s*/);

    printLOG('autoUpload', "Read Upload Info:", 'L');
    printLOG('autoUpload', "Line Number    : ".SRVCFG->input_line_number, 'L');
    printLOG('autoUpload', "Result ZIP     : ".$resultLOG             , 'L');
    printLOG('autoUpload', "Result LOG     : ".$resultLOG             , 'L');
    printLOG('autoUpload', "System Name    : ".$systemName              , 'L');
    printLOG('autoUpload', "System Desc    : ".$systemDesc              , 'L');

    # Add to Cluster Info
    if($clusterName ne '')
    {
            printLOG('autoUpload', "Add Cluster [$clusterName] [$nodeType] [$serverIP] [$oracleSID]");
            if($nodeType eq 'PRIMARY_MAIN')
            {
                if(defined $clusterInfo{$clusterName}->{'MAIN_SERVER'})    # Check Duplicate Main Server in one Cluster
                {
                    die "Duplicated Main Server in One Cluster at Line [".$srvConfig{$clusterInfo{$clusterName}->{'MAIN_SERVER'}}->{'LINE_NUMBER'}."] and [".UPLOADCONF->input_line_number."]";
                }
                else
                {
                    $clusterInfo{$clusterName}->{'MAIN_SERVER'} = "$serverIP,$oracleSID";
                }
            }
            elsif($nodeType eq 'PRIMARY_SUB')
            {
                if(defined $clusterInfo{$clusterName}->{'SUB_LIST'})
                {
                    $clusterInfo{$clusterName}->{'SUB_LIST'} = $clusterInfo{$clusterName}->{'SUB_LIST'}."|$serverIP,$oracleSID";
                }
                else
                {
                    $clusterInfo{$clusterName}->{'SUB_LIST'} = "$serverIP,$oracleSID";
                }
            }
            elsif($nodeType eq 'PHYSICAL_STANDBY')
            {
                if(defined $clusterInfo{$clusterName}->{'STANDBY_LIST'})
                {
                    $clusterInfo{$clusterName}->{'STANDBY_LIST'} = $clusterInfo{$clusterName}->{'STANDBY_LIST'}."|$serverIP,$oracleSID";
                }
                else
                {
                    $clusterInfo{$clusterName}->{'STANDBY_LIST'} = "$serverIP,$oracleSID";
                }
            }
    }

    # Add to Server Config
    $srvConfig{"$serverIP,$oracleSID"}->{'LINE_NUMBER'}     = UPLOADCONF->input_line_number;
    $srvConfig{"$serverIP,$oracleSID"}->{'CLUSTER_NAME'}    = $clusterName;
    $srvConfig{"$serverIP,$oracleSID"}->{'NODE_TYPE'}       = $nodeType;
    $srvConfig{"$serverIP,$oracleSID"}->{'PRIMARY_IP'}      = $primaryIP;
    $srvConfig{"$serverIP,$oracleSID"}->{'SSH_PORT'}        = $sshPort;
    $srvConfig{"$serverIP,$oracleSID"}->{'LOGIN_USER'}      = $loginUser;
    $srvConfig{"$serverIP,$oracleSID"}->{'LOGIN_PASSWORD'}  = $loginPassword;
    $srvConfig{"$serverIP,$oracleSID"}->{'COMMAND_OPTIONS'} = $commandOptions;
    $srvConfig{"$serverIP,$oracleSID"}->{'CONFIG_FILE'}     = $configFile;
    $srvConfig{"$serverIP,$oracleSID"}->{'ORACLE_HOME'}     = $oracleHome;
    $srvConfig{"$serverIP,$oracleSID"}->{'SYSTEM_NAME'}     = $systemName;
    $srvConfig{"$serverIP,$oracleSID"}->{'SYSTEM_DESC'}     = $systemDesc;
}
close UPLOADCONF;

# Check Cluster Without Main Server
foreach my $clusterName (keys %clusterInfo)
{
    die "No Main Server in Cluster [$clusterName]" if(not defined $clusterInfo{$clusterName}->{'MAIN_SERVER'});
}

# Check Cluster Without Main Server
my $prevIP = '';
foreach my $serverKey (keys %srvConfig)
{
    my ($serverIP, $oracleSID) = split(/,/, $serverKey);
}

printLOG('autoUpload', "Completed Read Upload Config File");




# Sent Default Log and Upload Conf
# -----------------------------------------------------------------------------
logADM('CLOSE');
if(-r $gFName{'RESULT_DIR'}.'/'.$gFName{'LOGFILE'})
